# PaisaPal — AI personal finance for college students

A full-stack, mobile-first money companion for students in India: record money received, track every expense, budget, find wasted spending, save for goals, track side-hustle income, and ask an AI assistant questions about **your own recorded data**.

**Stack:** Next.js 16 (App Router) · React 19 · TypeScript · Tailwind CSS v4 · Recharts · Supabase (PostgreSQL + Auth + row-level security) · Claude API (`@anthropic-ai/sdk`) · Vitest

---

## Features

| Area | What it does |
|---|---|
| **Dashboard** | Balance, received/spent/saved this month, savings rate, today's & this week's spending, remaining budget, safe-to-spend, upcoming bills, alerts, insights, 9 charts |
| **Transactions** | Income + expenses with category/subcategory, merchant, payment method, need/want, essential, recurring, notes. Search, filters (today/week/month/custom, category, amount, merchant, payment, need/want), sort, pagination, edit/duplicate/delete, CSV export |
| **Quick add** | Floating **+ Expense** button, ₹20/50/100/200/500 chips, category chips → save in seconds. Warns if the expense breaks a Don't Spend rule or pushes a budget near its limit |
| **Today / Monthly** | Daily tracker (available, spent, remaining, daily limit, timeline) and month-by-month summaries with history |
| **Budget** | Monthly category budgets + savings target, budget vs actual (under / near / over), projections, copy last month, suggested budget |
| **Where am I wasting money?** | Detects food delivery, café runs, snacks, frequent shopping, cabs, entertainment, many small purchases, impulse buys, overlapping subscriptions — with savings estimates and practical alternatives |
| **Need vs want** | Totals and one-tap reclassification |
| **Don't Spend** | Avoid-lists with date ranges and limits, alerts when you log a matching expense, estimated money saved |
| **Savings & goals** | Savings dashboard, buckets, emergency fund, unlimited goals with required ₹/month/week/day, ETA, contributions |
| **Planner** | "Can I afford it?" calculator, **Start from ₹0** AI planner, scenario simulator (current / cut spending / extra income / combined), "What if?" simulator |
| **Earn** | Side-hustle tracker that keeps **potential** income separate from **actual** income |
| **Subscriptions, bills & recurring** | Renewal reminders, mark-paid (records the expense and moves the due date), recurring burden used in safe-to-spend |
| **AI assistant** | Chat about your data ("How much did I spend on food delivery?", "I have ₹0, how can I reach ₹30,000?") using tool calls that query your records |
| **Insights, health, streaks** | Data-backed insights, measurable financial-health indicators with trends, optional streaks |
| **Reports** | Weekly review and monthly report; export PDF, CSV, Excel |
| **Calendar** | Income, expenses, bills, subscriptions, goal deadlines and savings on a month grid |
| **Settings** | Profile, theme (light/dark/system), alerts, custom categories, JSON backup/import, demo data, delete data |
| **Onboarding** | 7-step setup that creates reminders, goals and an initial budget |

### Data accuracy

Every number is calculated from database records by a pure, unit-tested engine in [`src/lib/finance`](src/lib/finance):

- **Balance** = opening balance + all income − all expenses (lifetime totals come from a SQL function, so they stay exact beyond the 13-month dashboard window).
- **Saved** = received − spent. **Savings rate** = saved ÷ received × 100 (shown as "—" when nothing was received).
- **Refunds** (income with source *Refunds*) reduce spending instead of counting as money received.
- **Goal remaining** = target − saved. **Required monthly** = remaining ÷ months left. Goal progress is driven by contributions, and a DB trigger keeps `goals.current_amount` in sync.
- **Safe-to-spend** = (balance − bills/subscriptions due before month end − savings target still to set aside) ÷ days left, capped by the remaining budget.
- Amounts are summed in integer paise to avoid floating-point drift. Dates are calendar strings in `Asia/Kolkata`.

### AI transparency

- The assistant gets a compact, pre-computed summary of your finances, plus tools (`query_transactions`, `plan_purchase`, `check_affordability`, `what_if`) that compute exact numbers from your records. It never receives a raw dump of your data.
- Answers label numbers as *Recorded*, *Calculated*, *Estimate*, *Your assumption* or *Suggestion*. Potential income is never presented as guaranteed. When there isn't enough data, the assistant says so.
- Plans are computed deterministically by the engine. The AI only explains them and suggests where cuts could come from, so it can't change the numbers.
- Without an `ANTHROPIC_API_KEY`, the assistant still answers common questions with built-in calculations (offline mode).
- This is budgeting help, not professional financial advice.

---

## Getting started

### 1. Install

```bash
npm install
cp .env.example .env.local
```

### 2. Database (choose one)

**Local (Docker):**

```bash
npx supabase start -x studio,imgproxy,mailpit,realtime,storage-api,edge-runtime,logflare,vector,supavisor,postgres-meta
# applies supabase/migrations automatically; copy the printed API URL + anon/publishable key into .env.local
```

**Hosted Supabase:** create a project, then run [`supabase/migrations/0001_init.sql`](supabase/migrations/0001_init.sql) in the SQL editor (or `npx supabase link && npx supabase db push`). Copy the project URL and anon key into `.env.local`.

Auth settings (Supabase dashboard → Authentication):
- **Site URL / Redirect URLs:** add `http://localhost:3000/**` and your production URL `https://your-app.vercel.app/**` (needed for password reset and Google login).
- **Google login (optional):** enable the Google provider with your OAuth client ID/secret.

### 3. AI (optional)

Set `ANTHROPIC_API_KEY` in `.env.local` to enable the AI assistant, AI plan explanations and AI monthly summaries (model: `claude-opus-5-5`, with server-side refusal fallback enabled).

### 4. Run

```bash
npm run dev     # http://localhost:3000
npm test        # finance engine unit tests
npm run lint
npm run build
```

Sign up, complete the onboarding (or skip it), and start adding transactions. To explore first, open **Settings → Load demo data**. Demo rows are flagged `is_demo` and can be removed in one click.

---

## Deployment

- **Vercel:** import the repo, set `NEXT_PUBLIC_SUPABASE_URL`, `NEXT_PUBLIC_SUPABASE_ANON_KEY` and (optionally) `ANTHROPIC_API_KEY`, then deploy. The API routes run as serverless functions, so no separate backend host is needed.
- **Supabase:** hosted Postgres + Auth. Apply the migration and add your Vercel URL to the auth redirect URLs.
- Any Node host (Render, Railway, a VPS) also works: `npm run build && npm start`.

---

## Architecture

```
src/
  app/
    (app)/…            feature pages (client components inside the app shell)
    (auth)/…           login, signup, forgot password
    auth/callback      OAuth / email-link code exchange
    onboarding/        first-time setup wizard
    api/
      snapshot         everything the dashboard needs in one request
      data/[resource]  validated CRUD for transactions, budgets, goals, contributions,
                       subscriptions, reminders, no-spend, earning-sources, categories
      budgets/bulk     replace a month's budget
      pay              mark a bill/subscription paid → records expense + advances date
      onboarding       creates profile, reminders, goals, initial budget
      backup           JSON export / import (merge|replace) / delete all
      demo             load / remove labelled demo data
      ai/{chat,plan,insights}
  lib/
    finance/           pure calculation engine (+ tests)
    server/            auth guard, validation helpers, snapshot loader, AI tools
    supabase/          browser/server clients
    validation.ts      zod schemas (server-side validation for every write)
  proxy.ts             session refresh + route protection (Next 16 "proxy")
supabase/migrations/   schema, indexes, RLS policies, triggers, SQL functions
```

**Security & privacy**
- Every table has row-level security: `user_id = auth.uid()` for select/insert/update/delete. Triggers stop a row from linking to another user's goal or earning source.
- API routes verify the user with Supabase Auth (`getUser()`) and run queries with the user's JWT. They never use a service-role key, and `user_id` always comes from the session, never from the request body.
- Every write is validated with zod on the server. Search terms are sanitised before they go into PostgREST filters.

**Performance**
- One `/api/snapshot` request (cached with SWR) feeds all dashboard calculations. Transaction history is paginated server-side.
- Indexes on `(user_id, date)`, `(user_id, type, date)` and the other per-user lookup columns.

### Schema notes

The tables follow the suggested structure, with a few deliberate choices:
- **Income lives in `transactions`** (`type = 'income'`, `category` = source) instead of a separate `income` table. One ledger avoids double counting and keeps the balance formula simple.
- Extra tables: `goal_contributions` (savings history per goal/bucket), `no_spend_rules`, `categories` (custom categories/sources), `profiles` (the `users` table: name, currency, opening balance, preferences).
- A *Housing* expense category (rent, hostel, electricity, laundry) was added alongside the requested ones.

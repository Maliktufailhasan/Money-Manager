-- PaisaPal: personal finance for college students
-- Every table is owned by a user (user_id = auth.uid()) and protected by RLS.

create extension if not exists pgcrypto;

-- ---------------------------------------------------------------------------
-- profiles (1:1 with auth.users)
-- ---------------------------------------------------------------------------
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  name text not null default '',
  email text,
  currency text not null default 'INR',
  opening_balance numeric(12,2) not null default 0,
  monthly_income_estimate numeric(12,2) not null default 0,
  daily_limit numeric(12,2),
  onboarded boolean not null default false,
  preferences jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

-- custom categories / income sources created by the user
create table if not exists public.categories (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade default auth.uid(),
  kind text not null check (kind in ('expense','income')),
  name text not null check (char_length(name) between 1 and 60),
  subcategories text[] not null default '{}',
  created_at timestamptz not null default now(),
  unique (user_id, kind, name)
);

-- side hustles / earning opportunities (potential vs actual income)
create table if not exists public.earning_sources (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade default auth.uid(),
  source text not null check (char_length(source) between 1 and 80),
  type text not null default 'Other',
  expected_income numeric(12,2) not null default 0 check (expected_income >= 0),
  hours numeric(6,1) not null default 0 check (hours >= 0),
  start_date date,
  status text not null default 'idea' check (status in ('idea','active','paused','stopped')),
  notes text,
  is_demo boolean not null default false,
  created_at timestamptz not null default now()
);

-- all money movements. type = income | expense.
-- income rows use category = income source (Pocket Money, Scholarship, ...)
create table if not exists public.transactions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade default auth.uid(),
  type text not null check (type in ('income','expense')),
  amount numeric(12,2) not null check (amount > 0),
  category text not null,
  subcategory text,
  income_type text,
  description text,
  date date not null default current_date,
  time time,
  merchant text,
  payment_method text,
  need_or_want text check (need_or_want in ('need','want')),
  essential boolean,
  recurring boolean not null default false,
  recurrence text check (recurrence in ('daily','weekly','monthly','yearly','custom')),
  recurrence_days int check (recurrence_days is null or recurrence_days > 0),
  earning_source_id uuid references public.earning_sources(id) on delete set null,
  notes text,
  is_demo boolean not null default false,
  created_at timestamptz not null default now()
);

create table if not exists public.budgets (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade default auth.uid(),
  category text not null,            -- expense category, or 'Savings' for the savings target
  amount numeric(12,2) not null check (amount >= 0),
  month int not null check (month between 1 and 12),
  year int not null check (year between 2000 and 2100),
  is_demo boolean not null default false,
  created_at timestamptz not null default now(),
  unique (user_id, category, month, year)
);

create table if not exists public.goals (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade default auth.uid(),
  name text not null check (char_length(name) between 1 and 80),
  target_amount numeric(12,2) not null check (target_amount > 0),
  current_amount numeric(12,2) not null default 0 check (current_amount >= 0),
  target_date date,
  priority text not null default 'medium' check (priority in ('high','medium','low')),
  category text not null default 'Custom',
  is_emergency boolean not null default false,
  status text not null default 'active' check (status in ('active','completed','paused')),
  notes text,
  is_demo boolean not null default false,
  created_at timestamptz not null default now()
);

-- money moved into / out of a goal (savings bucket); keeps goals.current_amount in sync
create table if not exists public.goal_contributions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade default auth.uid(),
  goal_id uuid not null references public.goals(id) on delete cascade,
  amount numeric(12,2) not null check (amount <> 0),
  date date not null default current_date,
  note text,
  is_demo boolean not null default false,
  created_at timestamptz not null default now()
);

create table if not exists public.subscriptions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade default auth.uid(),
  name text not null check (char_length(name) between 1 and 80),
  amount numeric(12,2) not null check (amount >= 0),
  billing_cycle text not null default 'monthly' check (billing_cycle in ('weekly','monthly','quarterly','yearly')),
  next_payment_date date not null,
  category text not null default 'Technology',
  status text not null default 'active' check (status in ('active','inactive')),
  remind_days_before int not null default 2 check (remind_days_before between 0 and 30),
  notes text,
  is_demo boolean not null default false,
  created_at timestamptz not null default now()
);

-- bills, fees, rent, EMI and other recurring / one-off payments
create table if not exists public.reminders (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade default auth.uid(),
  title text not null check (char_length(title) between 1 and 80),
  amount numeric(12,2) not null default 0 check (amount >= 0),
  due_date date not null,
  recurring text not null default 'none' check (recurring in ('none','weekly','monthly','quarterly','yearly')),
  kind text not null default 'Bill',
  category text not null default 'Other',
  completed boolean not null default false,
  notes text,
  is_demo boolean not null default false,
  created_at timestamptz not null default now()
);

-- "Don't Spend" rules
create table if not exists public.no_spend_rules (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade default auth.uid(),
  title text not null check (char_length(title) between 1 and 80),
  category text not null,
  subcategory text,
  start_date date not null default current_date,
  end_date date not null,
  limit_amount numeric(12,2) not null default 0 check (limit_amount >= 0),
  baseline_monthly numeric(12,2) check (baseline_monthly is null or baseline_monthly >= 0),
  active boolean not null default true,
  is_demo boolean not null default false,
  created_at timestamptz not null default now(),
  check (end_date >= start_date)
);

-- ---------------------------------------------------------------------------
-- indexes
-- ---------------------------------------------------------------------------
create index if not exists transactions_user_date_idx on public.transactions (user_id, date desc, created_at desc);
create index if not exists transactions_user_type_date_idx on public.transactions (user_id, type, date desc);
create index if not exists transactions_user_category_idx on public.transactions (user_id, category);
create index if not exists budgets_user_period_idx on public.budgets (user_id, year, month);
create index if not exists goals_user_idx on public.goals (user_id);
create index if not exists goal_contrib_goal_idx on public.goal_contributions (goal_id, date);
create index if not exists goal_contrib_user_idx on public.goal_contributions (user_id, date);
create index if not exists subscriptions_user_idx on public.subscriptions (user_id, next_payment_date);
create index if not exists reminders_user_idx on public.reminders (user_id, due_date);
create index if not exists no_spend_user_idx on public.no_spend_rules (user_id, end_date);
create index if not exists earning_sources_user_idx on public.earning_sources (user_id);
create index if not exists categories_user_idx on public.categories (user_id, kind);

-- ---------------------------------------------------------------------------
-- row level security: a user can only ever touch their own rows
-- ---------------------------------------------------------------------------
alter table public.profiles enable row level security;
drop policy if exists "own profile select" on public.profiles;
drop policy if exists "own profile update" on public.profiles;
drop policy if exists "own profile insert" on public.profiles;
create policy "own profile select" on public.profiles for select using (id = auth.uid());
create policy "own profile update" on public.profiles for update using (id = auth.uid()) with check (id = auth.uid());
create policy "own profile insert" on public.profiles for insert with check (id = auth.uid());

do $$
declare t text;
begin
  foreach t in array array['categories','earning_sources','transactions','budgets','goals',
                           'goal_contributions','subscriptions','reminders','no_spend_rules']
  loop
    execute format('alter table public.%I enable row level security', t);
    execute format('drop policy if exists "owner all" on public.%I', t);
    execute format('create policy "owner all" on public.%I for all using (user_id = auth.uid()) with check (user_id = auth.uid())', t);
  end loop;
end $$;

-- a goal contribution must point at the caller's own goal
create or replace function public.check_contribution_goal_owner() returns trigger
language plpgsql security invoker set search_path = public as $$
begin
  if not exists (select 1 from public.goals g where g.id = new.goal_id and g.user_id = new.user_id) then
    raise exception 'goal not found';
  end if;
  return new;
end $$;
drop trigger if exists goal_contrib_owner on public.goal_contributions;
create trigger goal_contrib_owner before insert or update on public.goal_contributions
  for each row execute function public.check_contribution_goal_owner();

-- a transaction may only link to the caller's own earning source
create or replace function public.check_tx_earning_owner() returns trigger
language plpgsql security invoker set search_path = public as $$
begin
  if new.earning_source_id is not null and not exists (
    select 1 from public.earning_sources e where e.id = new.earning_source_id and e.user_id = new.user_id) then
    raise exception 'earning source not found';
  end if;
  return new;
end $$;
drop trigger if exists tx_earning_owner on public.transactions;
create trigger tx_earning_owner before insert or update on public.transactions
  for each row execute function public.check_tx_earning_owner();

-- keep goals.current_amount = sum(contributions) (never negative)
create or replace function public.sync_goal_amount() returns trigger
language plpgsql security invoker set search_path = public as $$
declare gid uuid;
begin
  for gid in select unnest(array[
      case when tg_op in ('INSERT','UPDATE') then new.goal_id end,
      case when tg_op in ('UPDATE','DELETE') then old.goal_id end])
  loop
    if gid is not null then
      update public.goals g
         set current_amount = greatest(0, coalesce((select sum(c.amount) from public.goal_contributions c where c.goal_id = gid), 0)),
             status = case
               when g.status = 'paused' then 'paused'
               when coalesce((select sum(c.amount) from public.goal_contributions c where c.goal_id = gid), 0) >= g.target_amount then 'completed'
               else 'active' end
       where g.id = gid;
    end if;
  end loop;
  return null;
end $$;
drop trigger if exists goal_contrib_sync on public.goal_contributions;
create trigger goal_contrib_sync after insert or update or delete on public.goal_contributions
  for each row execute function public.sync_goal_amount();

-- lifetime totals, so the balance is exact even when only recent rows are loaded
create or replace function public.lifetime_totals()
returns table (total_income numeric, total_expense numeric, first_date date, tx_count bigint)
language sql stable security invoker set search_path = public as $$
  select coalesce(sum(amount) filter (where type = 'income'), 0),
         coalesce(sum(amount) filter (where type = 'expense'), 0),
         min(date),
         count(*)
    from public.transactions
   where user_id = auth.uid();
$$;

-- create the profile row when someone signs up
create or replace function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, email, name)
  values (new.id, new.email, coalesce(new.raw_user_meta_data->>'name', new.raw_user_meta_data->>'full_name', ''))
  on conflict (id) do nothing;
  return new;
end $$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
  for each row execute function public.handle_new_user();

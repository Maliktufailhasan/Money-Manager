"use client";
import { Monitor, Moon, Sun } from "lucide-react";
import { useSyncExternalStore } from "react";
import { Segmented } from "./ui";

type Theme = "light" | "dark" | "system";

export function applyTheme(t: Theme) {
  try {
    localStorage.setItem("pp-theme", t);
  } catch {}
  const dark = t === "dark" || (t === "system" && window.matchMedia("(prefers-color-scheme: dark)").matches);
  document.documentElement.dataset.theme = dark ? "dark" : "light";
}

function readTheme(): Theme {
  try {
    return (localStorage.getItem("pp-theme") as Theme) || "system";
  } catch {
    return "system";
  }
}

function subscribe(cb: () => void) {
  const mq = window.matchMedia("(prefers-color-scheme: dark)");
  const onSystem = () => {
    if (readTheme() === "system") applyTheme("system");
    cb();
  };
  mq.addEventListener("change", onSystem);
  window.addEventListener("pp-theme", cb);
  window.addEventListener("storage", cb);
  return () => {
    mq.removeEventListener("change", onSystem);
    window.removeEventListener("pp-theme", cb);
    window.removeEventListener("storage", cb);
  };
}

export function useTheme(): [Theme, (t: Theme) => void] {
  const theme = useSyncExternalStore(subscribe, readTheme, () => "system" as Theme);
  return [
    theme,
    (t) => {
      applyTheme(t);
      window.dispatchEvent(new Event("pp-theme"));
    },
  ];
}

export function ThemeToggle() {
  const [theme, setTheme] = useTheme();
  return (
    <Segmented
      size="sm"
      value={theme}
      onChange={setTheme}
      options={[
        { value: "light", label: <Sun className="size-3.5" aria-label="Light" /> },
        { value: "system", label: <Monitor className="size-3.5" aria-label="System" /> },
        { value: "dark", label: <Moon className="size-3.5" aria-label="Dark" /> },
      ]}
    />
  );
}

"use client";
import { Table2, BarChart3 } from "lucide-react";
import { useState, type ReactNode } from "react";
import {
  Bar, BarChart, CartesianGrid, Cell, Line, LineChart, Pie, PieChart, ResponsiveContainer, Tooltip, XAxis, YAxis, Area, AreaChart, ReferenceLine,
} from "recharts";
import { formatINR } from "@/lib/finance/money";
import { cn, IconButton } from "./ui";

/** Fixed categorical slots — colour follows the entity, never its rank. */
export const SERIES = ["var(--series-1)", "var(--series-2)", "var(--series-3)", "var(--series-4)", "var(--series-5)", "var(--series-6)", "var(--series-7)", "var(--series-8)"];
export const COLORS = { income: "var(--series-1)", expense: "var(--series-2)", saved: "var(--series-3)", other: "var(--muted)" };

const CATEGORY_SLOT: Record<string, number> = { Food: 0, Travel: 1, Education: 2, Personal: 3, Technology: 4, Social: 5, Housing: 6, Other: 7 };
export function categoryColor(name: string): string {
  const slot = CATEGORY_SLOT[name];
  return slot === undefined ? "var(--muted)" : SERIES[slot];
}

const compact = (n: number) => (Math.abs(n) >= 100000 ? `₹${(n / 100000).toFixed(1)}L` : Math.abs(n) >= 1000 ? `₹${(n / 1000).toFixed(n % 1000 === 0 ? 0 : 1)}k` : `₹${n}`);
const axisProps = { tick: { fill: "var(--muted)", fontSize: 11 }, axisLine: false, tickLine: false } as const;

export interface SeriesDef {
  key: string;
  label: string;
  color: string;
}

function TooltipBox({ active, payload, label, series }: { active?: boolean; payload?: { dataKey?: string | number; value?: number; payload?: Record<string, unknown> }[]; label?: string; series?: SeriesDef[] }) {
  if (!active || !payload?.length) return null;
  return (
    <div className="rounded-xl border border-line bg-surface px-3 py-2 text-xs shadow-lg">
      {label && <div className="mb-1 font-medium text-ink">{label}</div>}
      {payload.map((p) => {
        const def = series?.find((s) => s.key === p.dataKey);
        return (
          <div key={String(p.dataKey)} className="flex items-center justify-between gap-4">
            <span className="flex items-center gap-1.5 text-ink-2">
              <span className="size-2 rounded-full" style={{ background: def?.color }} />
              {def?.label ?? p.dataKey}
            </span>
            <span className="tabular font-medium text-ink">{formatINR(Number(p.value))}</span>
          </div>
        );
      })}
    </div>
  );
}

function Legend({ series }: { series: SeriesDef[] }) {
  if (series.length < 2) return null;
  return (
    <div className="mb-2 flex flex-wrap gap-x-4 gap-y-1 text-xs text-ink-2">
      {series.map((s) => (
        <span key={s.key} className="flex items-center gap-1.5">
          <span className="size-2.5 rounded-sm" style={{ background: s.color }} />
          {s.label}
        </span>
      ))}
    </div>
  );
}

/** Wraps a chart with a "table view" toggle so every value is reachable without hover. */
export function ChartBox({ title, hint, children, table, action, className }: { title: string; hint?: ReactNode; children: ReactNode; table?: { columns: string[]; rows: (string | number)[][] }; action?: ReactNode; className?: string }) {
  const [asTable, setAsTable] = useState(false);
  return (
    <section className={cn("rounded-2xl border border-line bg-surface p-4 sm:p-5", className)} aria-label={title}>
      <div className="mb-3 flex items-start justify-between gap-2">
        <div>
          <h2 className="text-sm font-semibold">{title}</h2>
          {hint && <p className="mt-0.5 text-xs text-muted">{hint}</p>}
        </div>
        <div className="flex items-center gap-1">
          {action}
          {table && (
            <IconButton label={asTable ? "Show chart" : "Show table"} onClick={() => setAsTable((v) => !v)}>
              {asTable ? <BarChart3 className="size-4" /> : <Table2 className="size-4" />}
            </IconButton>
          )}
        </div>
      </div>
      {asTable && table ? (
        <div className="max-h-72 overflow-auto">
          <table className="w-full text-sm">
            <thead className="sticky top-0 bg-surface text-left text-xs text-muted">
              <tr>
                {table.columns.map((c, i) => (
                  <th key={c} className={cn("py-1.5 font-medium", i > 0 && "text-right")}>
                    {c}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody className="tabular">
              {table.rows.map((r, i) => (
                <tr key={i} className="border-t border-line">
                  {r.map((v, j) => (
                    <td key={j} className={cn("py-1.5", j > 0 && "text-right")}>
                      {typeof v === "number" ? formatINR(v) : v}
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : (
        children
      )}
    </section>
  );
}

export function BarsChart({ data, xKey, series, height = 220, stacked }: { data: Record<string, unknown>[]; xKey: string; series: SeriesDef[]; height?: number; stacked?: boolean }) {
  return (
    <div>
      <Legend series={series} />
      <div style={{ height }}>
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={data} margin={{ top: 4, right: 4, left: -8, bottom: 0 }} barGap={2} barCategoryGap="22%">
            <CartesianGrid vertical={false} stroke="var(--grid)" />
            <XAxis dataKey={xKey} {...axisProps} interval="preserveStartEnd" minTickGap={12} />
            <YAxis {...axisProps} tickFormatter={compact} width={52} />
            <ReferenceLine y={0} stroke="var(--axis)" />
            <Tooltip cursor={{ fill: "var(--surface-2)" }} content={<TooltipBox series={series} />} />
            {series.map((s) => (
              <Bar key={s.key} dataKey={s.key} fill={s.color} radius={stacked ? 0 : [4, 4, 0, 0]} stackId={stacked ? "a" : undefined} maxBarSize={28} stroke="var(--chart-surface)" strokeWidth={stacked ? 1 : 0} />
            ))}
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}

export function LinesChart({ data, xKey, series, height = 220, area }: { data: Record<string, unknown>[]; xKey: string; series: SeriesDef[]; height?: number; area?: boolean }) {
  const Chart = area ? AreaChart : LineChart;
  return (
    <div>
      <Legend series={series} />
      <div style={{ height }}>
        <ResponsiveContainer width="100%" height="100%">
          <Chart data={data} margin={{ top: 4, right: 8, left: -8, bottom: 0 }}>
            <CartesianGrid vertical={false} stroke="var(--grid)" />
            <XAxis dataKey={xKey} {...axisProps} interval="preserveStartEnd" minTickGap={16} />
            <YAxis {...axisProps} tickFormatter={compact} width={52} />
            <Tooltip cursor={{ stroke: "var(--axis)" }} content={<TooltipBox series={series} />} />
            {series.map((s) =>
              area ? (
                <Area key={s.key} type="monotone" dataKey={s.key} stroke={s.color} fill={s.color} fillOpacity={0.12} strokeWidth={2} dot={false} activeDot={{ r: 4, stroke: "var(--chart-surface)", strokeWidth: 2 }} />
              ) : (
                <Line key={s.key} type="monotone" dataKey={s.key} stroke={s.color} strokeWidth={2} dot={false} activeDot={{ r: 4, stroke: "var(--chart-surface)", strokeWidth: 2 }} />
              ),
            )}
          </Chart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}

/** Donut with a side legend that always shows the amounts (identity never colour-alone). */
export function Donut({ data, height = 200, colorFor = categoryColor, centerLabel, maxSlices = 7 }: { data: { name: string; value: number }[]; height?: number; colorFor?: (name: string, i: number) => string; centerLabel?: ReactNode; maxSlices?: number }) {
  const sorted = [...data].filter((d) => d.value > 0).sort((a, b) => b.value - a.value);
  const head = sorted.slice(0, maxSlices);
  const rest = sorted.slice(maxSlices);
  const slices = rest.length ? [...head, { name: "Everything else", value: rest.reduce((a, b) => a + b.value, 0) }] : head;
  const total = slices.reduce((a, b) => a + b.value, 0);
  if (!total) return <p className="py-8 text-center text-sm text-muted">Nothing to show yet.</p>;
  return (
    <div className="flex flex-col items-center gap-4 sm:flex-row">
      <div className="relative shrink-0" style={{ width: height, height }}>
        <ResponsiveContainer width="100%" height="100%">
          <PieChart>
            <Pie data={slices} dataKey="value" nameKey="name" innerRadius="62%" outerRadius="100%" paddingAngle={1} stroke="var(--chart-surface)" strokeWidth={2} isAnimationActive={false}>
              {slices.map((s, i) => (
                <Cell key={s.name} fill={s.name === "Everything else" ? "var(--muted)" : colorFor(s.name, i)} />
              ))}
            </Pie>
            <Tooltip content={({ active, payload }) => (active && payload?.[0] ? <div className="rounded-xl border border-line bg-surface px-3 py-2 text-xs shadow-lg"><span className="font-medium">{String(payload[0].name)}</span> · <span className="tabular">{formatINR(Number(payload[0].value))}</span> ({Math.round((Number(payload[0].value) / total) * 100)}%)</div> : null)} />
          </PieChart>
        </ResponsiveContainer>
        {centerLabel && <div className="pointer-events-none absolute inset-0 flex flex-col items-center justify-center text-center">{centerLabel}</div>}
      </div>
      <ul className="w-full min-w-0 space-y-1.5 text-sm">
        {slices.map((s, i) => (
          <li key={s.name} className="flex items-center justify-between gap-3">
            <span className="flex min-w-0 items-center gap-2">
              <span className="size-2.5 shrink-0 rounded-sm" style={{ background: s.name === "Everything else" ? "var(--muted)" : colorFor(s.name, i) }} />
              <span className="truncate text-ink-2">{s.name}</span>
            </span>
            <span className="tabular shrink-0 text-ink">
              {formatINR(s.value)} <span className="text-xs text-muted">{Math.round((s.value / total) * 100)}%</span>
            </span>
          </li>
        ))}
      </ul>
    </div>
  );
}

/** Horizontal bars as plain HTML — great for ranked categories on mobile. */
export function RankBars({ items, colorFor }: { items: { name: string; value: number; sub?: string }[]; colorFor?: (name: string) => string }) {
  const max = Math.max(...items.map((i) => i.value), 1);
  if (!items.length) return <p className="py-6 text-center text-sm text-muted">Nothing to show yet.</p>;
  return (
    <ul className="space-y-2.5">
      {items.map((i) => (
        <li key={i.name}>
          <div className="mb-1 flex justify-between gap-2 text-sm">
            <span className="truncate text-ink-2">{i.name}</span>
            <span className="tabular shrink-0">
              {formatINR(i.value)}
              {i.sub && <span className="ml-1 text-xs text-muted">{i.sub}</span>}
            </span>
          </div>
          <div className="h-2 rounded-full bg-surface-2">
            <div className="h-full rounded-full" style={{ width: `${(i.value / max) * 100}%`, background: colorFor ? colorFor(i.name) : "var(--series-1)" }} />
          </div>
        </li>
      ))}
    </ul>
  );
}

"use client";
import { useMemo, useState } from "react";
import { Donut, SERIES } from "@/components/charts";
import { Card, CardTitle, Chip, Money, Segmented, SourceTag, useToast } from "@/components/ui";
import { fmtDate, formatINR, isExpense, monthStart, type PeriodSummary } from "@/lib/finance";
import { db } from "@/lib/client/api";
import type { NeedWant as NW, Transaction } from "@/lib/types";

type Filter = "want" | "unclassified" | "need";
const colorFor = (name: string) => (name === "Needs" ? SERIES[0] : name === "Wants" ? SERIES[1] : "var(--muted)");

export function NeedWant({ txs, month, today }: { txs: Transaction[]; month: PeriodSummary; today: string }) {
  const toast = useToast();
  const [filter, setFilter] = useState<Filter>("want");
  const [limit, setLimit] = useState(15);
  const [busy, setBusy] = useState<string | null>(null);

  const monthTx = useMemo(() => txs.filter((t) => isExpense(t) && t.date >= monthStart(today) && t.date <= today), [txs, today]);
  const list = useMemo(
    () => monthTx.filter((t) => (filter === "unclassified" ? !t.need_or_want : t.need_or_want === filter)).sort((a, b) => (a.date < b.date ? 1 : a.date > b.date ? -1 : b.amount - a.amount)),
    [monthTx, filter],
  );
  const counts = { want: monthTx.filter((t) => t.need_or_want === "want").length, need: monthTx.filter((t) => t.need_or_want === "need").length, unclassified: monthTx.filter((t) => !t.need_or_want).length };

  async function reclassify(t: Transaction, v: NW) {
    setBusy(t.id);
    try {
      await db.update("transactions", t.id, { need_or_want: v, essential: v === "need" });
      toast(`Marked as a ${v}`, "info");
    } catch (e) {
      toast(e instanceof Error ? e.message : "Couldn't update", "bad");
    } finally {
      setBusy(null);
    }
  }

  const classified = month.needs + month.wants;
  return (
    <Card>
      <CardTitle hint="This month's expenses, as you classified them." action={<SourceTag kind="recorded" />}>
        Needs vs wants
      </CardTitle>
      <div className="grid gap-6 lg:grid-cols-2">
        <div>
          <Donut
            data={[
              { name: "Needs", value: month.needs },
              { name: "Wants", value: month.wants },
              { name: "Unclassified", value: month.unclassified },
            ]}
            colorFor={colorFor}
            height={160}
            centerLabel={classified > 0 ? <><span className="text-lg font-semibold tabular">{Math.round((month.wants / classified) * 100)}%</span><span className="text-[11px] text-muted">wants</span></> : undefined}
          />
          <div className="mt-4 grid grid-cols-2 gap-3 text-sm">
            <div className="rounded-xl bg-surface-2 p-3">
              <p className="text-xs text-muted">Essential</p>
              <Money value={month.essential} className="font-semibold" />
            </div>
            <div className="rounded-xl bg-surface-2 p-3">
              <p className="text-xs text-muted">Non-essential</p>
              <Money value={month.nonEssential} className="font-semibold" />
            </div>
          </div>
        </div>
        <div className="min-w-0">
          <div className="mb-3 flex flex-wrap gap-2">
            <Chip active={filter === "want"} onClick={() => setFilter("want")}>Wants ({counts.want})</Chip>
            <Chip active={filter === "unclassified"} onClick={() => setFilter("unclassified")}>Unclassified ({counts.unclassified})</Chip>
            <Chip active={filter === "need"} onClick={() => setFilter("need")}>Needs ({counts.need})</Chip>
          </div>
          {list.length === 0 ? (
            <p className="py-6 text-center text-sm text-muted">No {filter === "unclassified" ? "unclassified" : filter} expenses this month.</p>
          ) : (
            <ul className="divide-y divide-line">
              {list.slice(0, limit).map((t) => (
                <li key={t.id} className="flex items-center gap-3 py-2">
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm">{t.description || t.merchant || t.subcategory || t.category}</p>
                    <p className="truncate text-xs text-muted">
                      {fmtDate(t.date)} · {t.category}
                      {t.subcategory ? ` › ${t.subcategory}` : ""}
                    </p>
                  </div>
                  <span className="shrink-0 text-sm font-medium tabular">{formatINR(t.amount)}</span>
                  <Segmented<NW>
                    size="sm"
                    value={t.need_or_want ?? ("" as NW)}
                    onChange={(v) => busy !== t.id && v !== t.need_or_want && reclassify(t, v)}
                    options={[
                      { value: "need", label: "Need" },
                      { value: "want", label: "Want" },
                    ]}
                    className={busy === t.id ? "opacity-50" : undefined}
                  />
                </li>
              ))}
            </ul>
          )}
          {list.length > limit && (
            <button className="mt-2 text-xs font-medium text-brand hover:underline" onClick={() => setLimit((l) => l + 15)}>
              Show more ({list.length - limit} left)
            </button>
          )}
        </div>
      </div>
    </Card>
  );
}

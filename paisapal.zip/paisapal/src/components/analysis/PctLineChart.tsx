"use client";
import { CartesianGrid, Line, LineChart, ReferenceLine, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { Table2, BarChart3 } from "lucide-react";
import { useState, type ReactNode } from "react";
import { IconButton } from "@/components/ui";

const axisProps = { tick: { fill: "var(--muted)", fontSize: 11 }, axisLine: false, tickLine: false } as const;
export const fmtPct = (v: number | null | undefined) => (v === null || v === undefined || Number.isNaN(v) ? "—" : `${Math.round(v)}%`);

interface Props {
  title: string;
  hint?: ReactNode;
  data: Record<string, unknown>[];
  xKey: string;
  yKey: string;
  label: string;
  color: string;
  /** optional target line (same unit) */
  target?: number;
  targetLabel?: string;
  height?: number;
}

/**
 * Single-measure percentage line chart (the shared LinesChart formats values as ₹).
 * Includes a table view so every value is reachable without hovering.
 */
export function PctLineChart({ title, hint, data, xKey, yKey, label, color, target, targetLabel, height = 180 }: Props) {
  const [asTable, setAsTable] = useState(false);
  const hasValues = data.some((d) => typeof d[yKey] === "number");
  return (
    <section className="rounded-2xl border border-line bg-surface p-4 sm:p-5" aria-label={title}>
      <div className="mb-3 flex items-start justify-between gap-2">
        <div>
          <h2 className="text-sm font-semibold">{title}</h2>
          {hint && <p className="mt-0.5 text-xs text-muted">{hint}</p>}
        </div>
        <IconButton label={asTable ? "Show chart" : "Show table"} onClick={() => setAsTable((v) => !v)}>
          {asTable ? <BarChart3 className="size-4" /> : <Table2 className="size-4" />}
        </IconButton>
      </div>
      {asTable ? (
        <table className="w-full text-sm">
          <thead className="text-left text-xs text-muted">
            <tr>
              <th className="py-1.5 font-medium">Month</th>
              <th className="py-1.5 text-right font-medium">{label}</th>
            </tr>
          </thead>
          <tbody className="tabular">
            {data.map((d) => (
              <tr key={String(d[xKey])} className="border-t border-line">
                <td className="py-1.5">{String(d[xKey])}</td>
                <td className="py-1.5 text-right">{fmtPct(d[yKey] as number | null)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      ) : !hasValues ? (
        <p className="py-8 text-center text-sm text-muted">Not enough data yet.</p>
      ) : (
        <div style={{ height }}>
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={data} margin={{ top: 6, right: 8, left: -14, bottom: 0 }}>
              <CartesianGrid vertical={false} stroke="var(--grid)" />
              <XAxis dataKey={xKey} {...axisProps} interval="preserveStartEnd" minTickGap={12} />
              <YAxis {...axisProps} tickFormatter={(v: number) => `${v}%`} width={44} />
              {target !== undefined && <ReferenceLine y={target} stroke="var(--axis)" strokeDasharray="4 4" label={{ value: targetLabel ?? `Target ${target}%`, fill: "var(--muted)", fontSize: 10, position: "insideTopRight" }} />}
              <Tooltip
                cursor={{ stroke: "var(--axis)" }}
                content={({ active, payload, label: l }) =>
                  active && payload?.length ? (
                    <div className="rounded-xl border border-line bg-surface px-3 py-2 text-xs shadow-lg">
                      <div className="mb-0.5 font-medium text-ink">{String(l)}</div>
                      <span className="text-ink-2">{label}: </span>
                      <span className="tabular font-medium text-ink">{fmtPct(Number(payload[0].value))}</span>
                    </div>
                  ) : null
                }
              />
              <Line type="monotone" dataKey={yKey} stroke={color} strokeWidth={2} connectNulls dot={{ r: 3, fill: color, strokeWidth: 0 }} activeDot={{ r: 5, stroke: "var(--chart-surface)", strokeWidth: 2 }} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      )}
    </section>
  );
}

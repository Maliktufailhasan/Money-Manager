"use client";
import { Lightbulb, PartyPopper, TrendingDown } from "lucide-react";
import { Badge, Card, CardTitle, EmptyState, SourceTag } from "@/components/ui";
import { formatINR, type WasteFinding } from "@/lib/finance";

const SEV = { high: { label: "Big impact", tone: "bad" }, medium: { label: "Worth a look", tone: "warn" }, low: { label: "Small", tone: "neutral" } } as const;

export function WasteCards({ findings }: { findings: WasteFinding[] }) {
  const totalMonthly = findings.reduce((a, f) => a + f.monthlySaving, 0);
  return (
    <Card>
      <CardTitle hint="Patterns from your last 30 days of recorded expenses, with realistic options — not judgement.">Where am I wasting money?</CardTitle>
      {findings.length === 0 ? (
        <EmptyState icon={<PartyPopper className="size-8" />} title="No wasteful patterns in the last 30 days 🎉">
          Nothing stands out. Keep logging and we&apos;ll point out habits worth reviewing.
        </EmptyState>
      ) : (
        <>
          {totalMonthly > 0 && (
            <div className="mb-4 flex items-center gap-3 rounded-xl bg-good-soft p-3 text-sm text-good">
              <TrendingDown className="size-5 shrink-0" aria-hidden />
              <span>
                Small changes below could free up about <strong className="tabular">{formatINR(totalMonthly)}/month</strong> ({formatINR(totalMonthly * 12)}/year). <SourceTag kind="estimate" />
              </span>
            </div>
          )}
          <div className="grid gap-3 md:grid-cols-2">
            {findings.map((f) => (
              <FindingCard key={f.id} f={f} />
            ))}
          </div>
        </>
      )}
    </Card>
  );
}

function FindingCard({ f }: { f: WasteFinding }) {
  const sev = SEV[f.severity];
  const isSubs = f.id === "subscriptions";
  return (
    <div className="flex flex-col gap-3 rounded-2xl border border-line bg-surface-2/40 p-4">
      <div className="flex items-start justify-between gap-2">
        <h3 className="font-medium">{f.title}</h3>
        <Badge tone={sev.tone}>{sev.label}</Badge>
      </div>
      <div className="flex flex-wrap items-baseline gap-x-2 gap-y-1">
        <span className="text-xl font-semibold tabular">{formatINR(f.amount)}</span>
        <span className="text-xs text-muted">{isSubs ? `per month · ${f.count} active` : `${f.count} time${f.count === 1 ? "" : "s"} in 30 days`}</span>
        <SourceTag kind="recorded" />
      </div>
      <p className="text-sm text-ink-2">{f.detail}</p>
      {f.monthlySaving > 0 && (
        <p className="rounded-xl bg-brand-soft px-3 py-2 text-sm text-brand">
          If you reduce this by {f.cutPct}%, you could save approximately <strong className="tabular">{formatINR(f.monthlySaving)}/month</strong> ({formatINR(f.yearlySaving)}/year).
        </p>
      )}
      <div>
        <p className="mb-1 flex items-center gap-1.5 text-xs font-medium text-ink-2">
          <Lightbulb className="size-3.5" aria-hidden /> Try instead
        </p>
        <ul className="list-disc space-y-0.5 pl-5 text-sm text-ink-2">
          {f.alternatives.map((a) => (
            <li key={a}>{a}</li>
          ))}
        </ul>
      </div>
    </div>
  );
}

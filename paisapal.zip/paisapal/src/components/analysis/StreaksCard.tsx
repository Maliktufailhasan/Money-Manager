"use client";
import Link from "next/link";
import { useMemo } from "react";
import { Card, CardTitle, Progress } from "@/components/ui";
import { formatINR, streaks, summarize, monthStart } from "@/lib/finance";
import type { Snapshot } from "@/lib/types";

export function StreaksCard({ s, today }: { s: Snapshot; today: string }) {
  const st = useMemo(() => streaks(s.transactions, s.goals, today, s.profile.daily_limit, s.totals.first_date), [s, today]);
  const saved = useMemo(() => summarize(s.transactions, monthStart(today), today).saved, [s.transactions, today]);

  const tiles: { emoji: string; value: string; label: string }[] = [
    { emoji: "🔥", value: `${st.trackingDays} day${st.trackingDays === 1 ? "" : "s"}`, label: "Expense tracking streak" },
    { emoji: "🧘", value: String(st.noSpendDaysThisMonth), label: "No-spend days this month" },
    { emoji: "📈", value: `${st.savingsMonths} month${st.savingsMonths === 1 ? "" : "s"}`, label: "Savings streak" },
  ];
  if (st.underLimitDays !== null) tiles.push({ emoji: "✅", value: `${st.underLimitDays} day${st.underLimitDays === 1 ? "" : "s"}`, label: "Under daily limit" });

  return (
    <Card>
      <CardTitle
        hint="Small wins from your recorded activity."
        action={
          <Link href="/settings" className="text-xs text-muted hover:text-ink hover:underline">
            Turn off
          </Link>
        }
      >
        Streaks & motivation
      </CardTitle>
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        {tiles.map((t) => (
          <div key={t.label} className="rounded-xl bg-surface-2 p-3">
            <p className="text-lg font-semibold tabular">
              <span aria-hidden>{t.emoji}</span> {t.value}
            </p>
            <p className="text-xs text-muted">{t.label}</p>
          </div>
        ))}
      </div>
      {(saved > 0 || st.milestones.length > 0) && (
        <ul className="mt-4 space-y-2.5">
          {saved > 0 && (
            <li className="text-sm">
              <span aria-hidden>💰</span> <span className="font-medium tabular">{formatINR(saved)}</span> saved this month so far
            </li>
          )}
          {st.milestones.slice(0, 4).map((m) => (
            <li key={m.goal}>
              <p className="mb-1 text-sm">
                <span aria-hidden>{m.pct >= 100 ? "🏆" : "🎯"}</span> {m.pct}% of {m.goal} goal {m.pct >= 100 ? "reached!" : "completed"}
              </p>
              <Progress value={m.pct} tone={m.pct >= 100 ? "good" : "brand"} label={`${m.goal} progress`} />
            </li>
          ))}
        </ul>
      )}
    </Card>
  );
}

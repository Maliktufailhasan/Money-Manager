"use client";
import type { MonthlyReport } from "@/lib/finance";
import type { Transaction } from "@/lib/types";

/** Trigger a browser download for a Blob via a temporary object URL. */
export function downloadBlob(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.rel = "noopener";
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

export function reportFilename(r: MonthlyReport, ext: string) {
  return `paisapal-report-${r.year}-${String(r.month).padStart(2, "0")}.${ext}`;
}

const r2 = (n: number) => Math.round(n * 100) / 100;

interface SummaryRow {
  label: string;
  value: number | string;
}

/** Plain summary lines shared by every export format. Values are raw numbers (INR). */
export function summaryRows(r: MonthlyReport): SummaryRow[] {
  const s = r.summary;
  return [
    { label: "Month", value: r.label },
    { label: "Money received", value: r2(s.received) },
    { label: "Refunds", value: r2(s.refunds) },
    { label: "Total spent (net of refunds)", value: r2(s.spent) },
    { label: "Saved", value: r2(s.saved) },
    { label: "Savings rate (%)", value: s.savingsRate === null ? "n/a" : r2(s.savingsRate) },
    { label: "Number of expenses", value: s.expenseCount },
    { label: "Needs", value: r2(s.needs) },
    { label: "Wants", value: r2(s.wants) },
    { label: "Unclassified", value: r2(s.unclassified) },
    { label: "Essential", value: r2(s.essential) },
    { label: "Non-essential", value: r2(s.nonEssential) },
    { label: "Previous month spent", value: r2(r.previous.spent) },
    { label: "Previous month received", value: r2(r.previous.received) },
    { label: "Subscriptions (monthly)", value: r2(r.subscriptionsMonthly) },
    { label: "Subscriptions (annual)", value: r2(r.subscriptionsMonthly * 12) },
    { label: "Recurring expenses (monthly)", value: r2(r.recurringMonthly) },
    { label: "Total budget", value: r.budget.hasBudget ? r2(r.budget.totalBudget) : "No budget" },
  ];
}

const txRow = (t: Transaction) => [t.date, t.type, t.category, t.subcategory ?? "", t.description ?? "", t.merchant ?? "", t.payment_method ?? "", t.need_or_want ?? "", r2(t.amount)];
const TX_HEAD = ["Date", "Type", "Category", "Subcategory", "Description", "Merchant", "Payment method", "Need/Want", "Amount (INR)"];

// ---------------------------------------------------------------------------
// CSV
// ---------------------------------------------------------------------------

export function csvEscape(v: unknown): string {
  if (v === null || v === undefined) return "";
  let s = String(v);
  // neutralise spreadsheet formula injection
  if (/^[=+\-@\t\r]/.test(s) && typeof v === "string") s = `'${s}`;
  return /[",\n\r]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
}

const csvLine = (cells: unknown[]) => cells.map(csvEscape).join(",");

export function exportCSV(r: MonthlyReport, txs: Transaction[]) {
  const lines: string[] = [];
  lines.push(csvLine([`PaisaPal monthly report - ${r.label}`]));
  lines.push("");
  lines.push(csvLine(["Summary", "Value"]));
  for (const row of summaryRows(r)) lines.push(csvLine([row.label, row.value]));
  lines.push("");
  lines.push(csvLine(["Category", "Spent (INR)", "Transactions", "Share (%)"]));
  for (const c of r.summary.byCategory) lines.push(csvLine([c.name, r2(c.amount), c.count, c.share ?? ""]));
  lines.push("");
  lines.push(csvLine(["Budget category", "Budget (INR)", "Spent (INR)", "Remaining (INR)", "Used (%)", "Status"]));
  for (const b of r.budget.rows) lines.push(csvLine([b.category, r2(b.budget), r2(b.spent), r2(b.remaining), b.usedPct ?? "", b.state]));
  lines.push("");
  lines.push(csvLine(TX_HEAD));
  for (const t of txs) lines.push(csvLine(txRow(t)));
  // BOM so Excel opens UTF-8 (₹, Hindi names) correctly
  downloadBlob(new Blob(["﻿" + lines.join("\r\n")], { type: "text/csv;charset=utf-8" }), reportFilename(r, "csv"));
}

// ---------------------------------------------------------------------------
// Excel
// ---------------------------------------------------------------------------

export async function exportExcel(r: MonthlyReport, txs: Transaction[]) {
  const ExcelJS = (await import("exceljs")).default;
  const wb = new ExcelJS.Workbook();
  wb.creator = "PaisaPal";
  wb.created = new Date();
  const money = "#,##0.00";

  const summary = wb.addWorksheet("Summary");
  summary.columns = [
    { header: "Item", key: "label", width: 34 },
    { header: "Value", key: "value", width: 20 },
  ];
  summaryRows(r).forEach((row) => summary.addRow(row));
  summary.getColumn("value").numFmt = money;

  const cats = wb.addWorksheet("Categories");
  cats.columns = [
    { header: "Category", key: "name", width: 22 },
    { header: "Spent (INR)", key: "amount", width: 16, style: { numFmt: money } },
    { header: "Transactions", key: "count", width: 14 },
    { header: "Share (%)", key: "share", width: 12 },
  ];
  r.summary.byCategory.forEach((c) => cats.addRow({ name: c.name, amount: c.amount, count: c.count, share: c.share }));

  const tx = wb.addWorksheet("Transactions");
  tx.columns = TX_HEAD.map((h, i) => ({ header: h, key: `c${i}`, width: [12, 9, 14, 16, 28, 18, 16, 11, 14][i], style: i === 8 ? { numFmt: money } : undefined }));
  txs.forEach((t) => tx.addRow(txRow(t)));

  const bud = wb.addWorksheet("Budget");
  bud.columns = [
    { header: "Category", key: "category", width: 20 },
    { header: "Budget (INR)", key: "budget", width: 14, style: { numFmt: money } },
    { header: "Spent (INR)", key: "spent", width: 14, style: { numFmt: money } },
    { header: "Remaining (INR)", key: "remaining", width: 16, style: { numFmt: money } },
    { header: "Used (%)", key: "usedPct", width: 10 },
    { header: "Status", key: "state", width: 12 },
  ];
  r.budget.rows.forEach((b) => bud.addRow(b));

  for (const ws of [summary, cats, tx, bud]) {
    ws.getRow(1).font = { bold: true };
    ws.views = [{ state: "frozen", ySplit: 1 }];
  }

  const buf = await wb.xlsx.writeBuffer();
  downloadBlob(new Blob([buf], { type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" }), reportFilename(r, "xlsx"));
}

// ---------------------------------------------------------------------------
// PDF (jsPDF's built-in font has no ₹ glyph, so amounts are written as "Rs 1,234")
// ---------------------------------------------------------------------------

const rs = (n: number) => `${n < 0 ? "-" : ""}Rs ${Math.round(Math.abs(n)).toLocaleString("en-IN")}`;
/** Replace characters the standard PDF fonts cannot render. */
const pdfText = (s: string) =>
  s
    .replace(/₹\s?/g, "Rs ")
    .replace(/[—–]/g, "-")
    .replace(/→/g, ">")
    .replace(/×/g, "x")
    .replace(/[‘’]/g, "'")
    .replace(/[“”]/g, '"')
    .replace(/…/g, "...")
    .replace(/[^\x20-\x7E\xA0-\xFF\n]/g, "");

export async function exportPDF(r: MonthlyReport, txs: Transaction[]) {
  const { jsPDF } = await import("jspdf");
  const autoTable = (await import("jspdf-autotable")).default;
  const doc = new jsPDF({ unit: "pt", format: "a4" });
  const W = doc.internal.pageSize.getWidth();
  const M = 40;
  let y = 48;
  const lastY = () => (doc as unknown as { lastAutoTable?: { finalY: number } }).lastAutoTable?.finalY ?? y;
  const ensure = (h: number) => {
    if (y + h > doc.internal.pageSize.getHeight() - 40) {
      doc.addPage();
      y = 48;
    }
  };
  const heading = (t: string) => {
    ensure(40);
    doc.setFont("helvetica", "bold");
    doc.setFontSize(12);
    doc.text(pdfText(t), M, y);
    y += 8;
  };
  const table = (head: string[], body: (string | number)[][], alignRight: number[] = []) => {
    autoTable(doc, {
      startY: y,
      head: [head],
      body: body.map((row) => row.map((c) => (typeof c === "string" ? pdfText(c) : c))),
      margin: { left: M, right: M },
      styles: { fontSize: 9, cellPadding: 4 },
      headStyles: { fillColor: [79, 70, 229] },
      columnStyles: Object.fromEntries(alignRight.map((i) => [i, { halign: "right" as const }])),
    });
    y = lastY() + 22;
  };
  const bullets = (items: string[]) => {
    doc.setFont("helvetica", "normal");
    doc.setFontSize(10);
    for (const it of items) {
      const lines = doc.splitTextToSize(`- ${pdfText(it)}`, W - 2 * M) as string[];
      ensure(lines.length * 13 + 4);
      y += 6;
      doc.text(lines, M, y + 6);
      y += lines.length * 13;
    }
    y += 16;
  };

  doc.setFont("helvetica", "bold");
  doc.setFontSize(18);
  doc.text(`Monthly report - ${r.label}`, M, y);
  y += 16;
  doc.setFont("helvetica", "normal");
  doc.setFontSize(9);
  doc.setTextColor(110);
  doc.text("PaisaPal - figures are calculated from your recorded transactions. Amounts in Indian Rupees (Rs).", M, y);
  doc.setTextColor(0);
  y += 24;

  const s = r.summary;
  heading("Summary");
  table(
    ["Item", "Amount"],
    [
      ["Money received", rs(s.received)],
      ["Total spent", rs(s.spent)],
      ["Saved", rs(s.saved)],
      ["Savings rate", s.savingsRate === null ? "n/a" : `${Math.round(s.savingsRate)}%`],
      ["Needs / Wants / Unclassified", `${rs(s.needs)} / ${rs(s.wants)} / ${rs(s.unclassified)}`],
      ["Previous month spent", rs(r.previous.spent)],
      ["Subscriptions", `${rs(r.subscriptionsMonthly)}/month (${rs(r.subscriptionsMonthly * 12)}/year)`],
      ["Recurring expenses", `${rs(r.recurringMonthly)}/month`],
    ],
    [1],
  );

  if (s.byCategory.length) {
    heading("Spending by category");
    table(["Category", "Spent", "Count", "Share"], s.byCategory.map((c) => [c.name, rs(c.amount), c.count, c.share === null ? "" : `${Math.round(c.share)}%`]), [1, 2, 3]);
  }
  if (s.bySource.length) {
    heading("Income sources");
    table(["Source", "Received", "Count"], s.bySource.map((c) => [c.name, rs(c.amount), c.count]), [1, 2]);
  }
  if (r.budget.rows.length) {
    heading("Budget performance");
    table(["Category", "Budget", "Spent", "Remaining", "Status"], r.budget.rows.map((b) => [b.category, b.budget ? rs(b.budget) : "-", rs(b.spent), b.budget ? rs(b.remaining) : "-", b.state]), [1, 2, 3]);
  }
  if (r.goals.length) {
    heading("Goal progress");
    table(["Goal", "Saved", "Target", "Added this month", "Progress"], r.goals.map((g) => [g.name, rs(g.saved), rs(g.target), rs(g.addedThisMonth), `${Math.round(g.pct)}% (${g.status})`]), [1, 2, 3]);
  }
  if (s.largestExpenses.length) {
    heading("Largest expenses");
    table(["Date", "Description", "Category", "Amount"], s.largestExpenses.map((t) => [t.date, t.description || t.merchant || t.subcategory || "", t.category, rs(t.amount)]), [3]);
  }
  if (r.insights.length) {
    heading("Insights");
    bullets(r.insights.map((i) => `${i.text} [${i.basis}]`));
  }
  heading("Suggested adjustments for next month");
  bullets(r.adjustments);

  if (txs.length) {
    heading(`All transactions (${txs.length})`);
    table(["Date", "Type", "Category", "Description", "Method", "Amount"], txs.map((t) => [t.date, t.type, t.subcategory ? `${t.category} > ${t.subcategory}` : t.category, t.description || t.merchant || "", t.payment_method ?? "", rs(t.amount)]), [5]);
  }

  downloadBlob(doc.output("blob"), reportFilename(r, "pdf"));
}

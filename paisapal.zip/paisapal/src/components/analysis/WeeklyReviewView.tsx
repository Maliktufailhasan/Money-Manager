"use client";
import { ArrowDownRight, ArrowUpRight, ChevronLeft, ChevronRight, Lightbulb } from "lucide-react";
import { useMemo, useState } from "react";
import { BarsChart, ChartBox, COLORS } from "@/components/charts";
import { Card, IconButton, Money, SourceTag, cn } from "@/components/ui";
import { addDays, dailySeries, formatINR, weekStart, weeklyReview, weekdayShort } from "@/lib/finance";
import type { Snapshot } from "@/lib/types";

export function WeeklyReviewView({ s, today }: { s: Snapshot; today: string }) {
  const thisWeek = weekStart(today);
  const [anchor, setAnchor] = useState(thisWeek);
  const earliest = weekStart(s.totals.first_date && s.totals.first_date > s.windowStart ? s.totals.first_date : s.windowStart);
  const w = useMemo(() => weeklyReview(s, anchor, today), [s, anchor, today]);
  const days = useMemo(() => dailySeries(s.transactions, w.from, w.to > today ? today : w.to).map((d) => ({ ...d, label: `${weekdayShort(d.key)} ${d.label}` })), [s.transactions, w.from, w.to, today]);
  const isCurrent = anchor === thisWeek;
  const sm = w.summary;
  const hasData = sm.expenseCount + sm.incomeCount > 0;

  const rows: { label: string; value: React.ReactNode; tone?: string }[] = [
    { label: "Money received", value: <Money value={sm.received} /> },
    { label: "Money spent", value: <Money value={sm.spent} /> },
    { label: "Saved", value: <Money value={sm.saved} sign />, tone: sm.saved >= 0 ? "text-good" : "text-bad" },
    { label: "Top category", value: w.topCategory ? <>{w.topCategory.name} · <Money value={w.topCategory.amount} /></> : "—" },
    { label: "Unnecessary spending (wants)", value: <Money value={w.unnecessary} /> },
    { label: "Budget status", value: w.budgetStatus, tone: w.budgetStatus.startsWith("Over") ? "text-bad" : w.budgetStatus.startsWith("Near") ? "text-warn" : undefined },
    { label: "Goal progress", value: <Money value={w.goalProgress} sign />, tone: w.goalProgress > 0 ? "text-good" : undefined },
  ];

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between gap-2">
        <IconButton label="Previous week" onClick={() => setAnchor(addDays(anchor, -7))} disabled={anchor <= earliest} className="disabled:opacity-40">
          <ChevronLeft className="size-5" />
        </IconButton>
        <div className="text-center">
          <p className="font-medium">{w.label}</p>
          <p className="text-xs text-muted">{isCurrent ? "This week (so far)" : anchor === addDays(thisWeek, -7) ? "Last week" : "Week review"}</p>
        </div>
        <IconButton label="Next week" onClick={() => setAnchor(addDays(anchor, 7))} disabled={isCurrent} className="disabled:opacity-40">
          <ChevronRight className="size-5" />
        </IconButton>
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        <Card>
          <div className="mb-3 flex items-center justify-between">
            <h2 className="text-xs font-semibold tracking-widest text-muted">WEEKLY REVIEW</h2>
            <SourceTag kind="recorded" />
          </div>
          {!hasData && <p className="mb-3 rounded-xl bg-surface-2 p-3 text-sm text-muted">Nothing recorded this week.</p>}
          <dl className="divide-y divide-line">
            {rows.map((r) => (
              <div key={r.label} className="flex items-baseline justify-between gap-3 py-2 text-sm">
                <dt className="text-ink-2">{r.label}</dt>
                <dd className={cn("text-right font-medium tabular", r.tone)}>{r.value}</dd>
              </div>
            ))}
          </dl>
          <div className="mt-3 flex gap-2 rounded-xl bg-brand-soft p-3 text-sm text-brand">
            <Lightbulb className="mt-0.5 size-4 shrink-0" aria-hidden />
            <p>
              <span className="font-medium">Suggestion: </span>
              {w.suggestion}
            </p>
          </div>
        </Card>

        <div className="space-y-4">
          <Card>
            <h2 className="mb-3 text-sm font-semibold">Compared with the previous week</h2>
            <div className="grid grid-cols-3 gap-2">
              <Delta label="Received" now={sm.received} before={w.previous.received} goodWhenUp />
              <Delta label="Spent" now={sm.spent} before={w.previous.spent} />
              <Delta label="Saved" now={sm.saved} before={w.previous.saved} goodWhenUp />
            </div>
          </Card>
          <ChartBox title="Spending by day" table={{ columns: ["Day", "Spent"], rows: days.map((d) => [d.label, d.expense]) }}>
            <BarsChart data={days} xKey="label" series={[{ key: "expense", label: "Spent", color: COLORS.expense }]} height={170} />
          </ChartBox>
        </div>
      </div>
    </div>
  );
}

export function Delta({ label, now, before, goodWhenUp }: { label: string; now: number; before: number; goodWhenUp?: boolean }) {
  const diff = now - before;
  const up = diff > 0;
  const good = diff === 0 ? null : up === !!goodWhenUp;
  const Icon = up ? ArrowUpRight : ArrowDownRight;
  return (
    <div className="rounded-xl bg-surface-2 p-3">
      <p className="text-xs text-muted">{label}</p>
      <p className="font-semibold tabular">{formatINR(now)}</p>
      <p className={cn("mt-0.5 flex items-center gap-0.5 text-xs tabular", good === true && "text-good", good === false && "text-bad", good === null && "text-muted")}>
        {diff !== 0 && <Icon className="size-3.5" aria-hidden />}
        {diff === 0 ? "No change" : `${formatINR(Math.abs(diff))} ${up ? "more" : "less"}`}
      </p>
      <p className="text-[11px] text-muted">was {formatINR(before)}</p>
    </div>
  );
}

"use client";
import { Bot, RotateCcw, SendHorizonal, User, WifiOff } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { Markdown } from "@/components/Markdown";
import { Badge, Button, cn } from "@/components/ui";
import { api } from "@/lib/client/api";

export const SUGGESTIONS = [
  "Where did I spend the most this month?",
  "How much did I spend on food?",
  "How much did I save this month?",
  "Why am I unable to save money?",
  "How can I save ₹5,000 this month?",
  "Can I afford a ₹20,000 phone?",
  "How long will it take me to buy a bike?",
  "What expenses should I reduce?",
  "How much should I spend per day?",
  "How much can I spend this weekend?",
  "What was my biggest unnecessary expense?",
  "How much did I spend on food delivery?",
  "Compare my spending with last month.",
  "Create a plan to save ₹50,000.",
  "I have ₹0. How can I reach ₹30,000?",
  "Give me a 6-month plan to buy a laptop.",
];

interface Msg {
  role: "user" | "assistant";
  content: string;
  mode?: "ai" | "offline";
}

const KEY = "pp-assistant-chat-v1";
const MAX_TURNS = 12;

function load(): Msg[] {
  try {
    const raw = sessionStorage.getItem(KEY);
    const parsed: unknown = raw ? JSON.parse(raw) : [];
    if (!Array.isArray(parsed)) return [];
    return parsed.filter((m): m is Msg => !!m && typeof m === "object" && (m.role === "user" || m.role === "assistant") && typeof m.content === "string");
  } catch {
    return [];
  }
}

/** Chat UI. Mounted client-side only (after data loads) so sessionStorage can seed the initial state. */
export function Chat({ resetSignal }: { resetSignal: number }) {
  const [messages, setMessages] = useState<Msg[]>(load);
  const [input, setInput] = useState("");
  const [pending, setPending] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const endRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);
  const [lastReset, setLastReset] = useState(resetSignal);

  // "New chat" from the header (state adjusted during render, not in an effect)
  if (resetSignal !== lastReset) {
    setLastReset(resetSignal);
    setMessages([]);
    setError(null);
    setInput("");
  }

  useEffect(() => {
    try {
      if (messages.length) sessionStorage.setItem(KEY, JSON.stringify(messages));
      else sessionStorage.removeItem(KEY);
    } catch {}
  }, [messages]);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: "smooth", block: "end" });
  }, [messages.length, pending, error]);

  async function ask(history: Msg[]) {
    setPending(true);
    setError(null);
    try {
      const payload = history.slice(-MAX_TURNS).map(({ role, content }) => ({ role, content: content.slice(0, 4000) }));
      while (payload.length && payload[0].role !== "user") payload.shift();
      const r = await api<{ text: string; mode: "ai" | "offline" }>("/api/ai/chat", { method: "POST", json: { messages: payload } });
      setMessages([...history, { role: "assistant", content: r.text, mode: r.mode }]);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Something went wrong");
    } finally {
      setPending(false);
    }
  }

  function send(text: string) {
    const q = text.trim();
    if (!q || pending) return;
    const next: Msg[] = [...messages, { role: "user", content: q }];
    setMessages(next);
    setInput("");
    if (inputRef.current) inputRef.current.style.height = "";
    void ask(next);
  }

  const lastMode = [...messages].reverse().find((m) => m.role === "assistant")?.mode;
  const empty = messages.length === 0;

  return (
    <div className="flex min-h-[calc(100dvh-16rem)] flex-col lg:min-h-[calc(100dvh-12rem)]">
      <div className="flex-1 space-y-4 pb-4" aria-live="polite">
        {empty && (
          <div className="rounded-2xl border border-line bg-surface p-4 sm:p-5">
            <div className="mb-3 flex items-center gap-2">
              <span className="flex size-8 items-center justify-center rounded-xl bg-brand-soft text-brand">
                <Bot className="size-4" />
              </span>
              <div>
                <p className="text-sm font-medium">Ask me anything about your money</p>
                <p className="text-xs text-muted">I answer using your recorded transactions, budgets and goals.</p>
              </div>
            </div>
            <div className="flex flex-wrap gap-2">
              {SUGGESTIONS.map((q) => (
                <button key={q} type="button" onClick={() => send(q)} className="rounded-full border border-line bg-surface px-3 py-1.5 text-left text-xs text-ink-2 transition-colors hover:border-brand hover:bg-brand-soft hover:text-brand">
                  {q}
                </button>
              ))}
            </div>
          </div>
        )}

        {messages.map((m, i) => (
          <Bubble key={i} msg={m} />
        ))}

        {pending && (
          <div className="flex items-start gap-2">
            <Avatar role="assistant" />
            <div className="rounded-2xl rounded-tl-md border border-line bg-surface px-4 py-3" role="status" aria-label="Assistant is thinking">
              <span className="flex gap-1">
                {[0, 150, 300].map((d) => (
                  <span key={d} className="size-2 animate-bounce rounded-full bg-muted" style={{ animationDelay: `${d}ms` }} />
                ))}
              </span>
            </div>
          </div>
        )}

        {error && !pending && (
          <div className="ml-9 rounded-xl border border-bad/30 bg-bad-soft p-3 text-sm text-bad">
            <p>Couldn&apos;t get an answer: {error}</p>
            <Button variant="secondary" size="sm" className="mt-2" onClick={() => ask(messages)}>
              <RotateCcw className="size-3.5" aria-hidden /> Retry
            </Button>
          </div>
        )}
        <div ref={endRef} />
      </div>

      {/* input: above the mobile bottom nav + floating button; leaves room for the floating button on desktop */}
      <div className="sticky bottom-36 z-20 -mx-1 rounded-2xl bg-bg/90 px-1 pt-2 pb-1 backdrop-blur lg:bottom-4 lg:pr-40">
        {!empty && (
          <div className="mb-2 [scrollbar-width:none] flex gap-2 overflow-x-auto pb-1">
            {SUGGESTIONS.map((q) => (
              <button key={q} type="button" disabled={pending} onClick={() => send(q)} className="shrink-0 rounded-full border border-line bg-surface px-3 py-1 text-xs whitespace-nowrap text-ink-2 hover:bg-surface-2 disabled:opacity-50">
                {q}
              </button>
            ))}
          </div>
        )}
        <form
          onSubmit={(e) => {
            e.preventDefault();
            send(input);
          }}
          className="flex items-end gap-2 rounded-2xl border border-line bg-surface p-2 shadow-sm focus-within:border-brand"
        >
          <label htmlFor="chat-input" className="sr-only">
            Your question
          </label>
          <textarea
            id="chat-input"
            ref={inputRef}
            rows={1}
            value={input}
            maxLength={4000}
            placeholder="Ask about your spending, savings or goals…"
            onChange={(e) => {
              setInput(e.target.value);
              e.target.style.height = "auto";
              e.target.style.height = `${Math.min(e.target.scrollHeight, 128)}px`;
            }}
            onKeyDown={(e) => {
              if (e.key === "Enter" && !e.shiftKey && !e.nativeEvent.isComposing) {
                e.preventDefault();
                send(input);
              }
            }}
            className="max-h-32 min-h-9 flex-1 resize-none bg-transparent px-2 py-2 text-sm text-ink placeholder:text-muted focus:outline-none"
          />
          <Button type="submit" size="sm" className="h-9 w-9 shrink-0 px-0" disabled={!input.trim() || pending} aria-label="Send">
            <SendHorizonal className="size-4" />
          </Button>
        </form>
        <div className="mt-1.5 flex flex-wrap items-center justify-between gap-2 px-1 text-[11px] text-muted">
          <span>Budgeting help, not professional financial advice. Answers use your recorded data.</span>
          {lastMode === "offline" && (
            <Badge tone="warn">
              <WifiOff className="size-3" aria-hidden /> Offline mode
            </Badge>
          )}
        </div>
      </div>
    </div>
  );
}

function Avatar({ role }: { role: Msg["role"] }) {
  return (
    <span className={cn("mt-0.5 flex size-7 shrink-0 items-center justify-center rounded-full", role === "assistant" ? "bg-brand-soft text-brand" : "bg-surface-2 text-ink-2")} aria-hidden>
      {role === "assistant" ? <Bot className="size-4" /> : <User className="size-4" />}
    </span>
  );
}

function Bubble({ msg }: { msg: Msg }) {
  if (msg.role === "user") {
    return (
      <div className="flex justify-end gap-2">
        <div className="max-w-[85%] rounded-2xl rounded-tr-md bg-brand px-4 py-2.5 text-sm whitespace-pre-wrap text-brand-ink sm:max-w-[75%]">{msg.content}</div>
      </div>
    );
  }
  return (
    <div className="flex items-start gap-2">
      <Avatar role="assistant" />
      <div className="max-w-[92%] min-w-0 rounded-2xl rounded-tl-md border border-line bg-surface px-4 py-3 text-sm sm:max-w-[80%]">
        <Markdown text={msg.content} />
        {msg.mode === "offline" && (
          <p className="mt-2 flex items-center gap-1 border-t border-line pt-2 text-[11px] text-muted">
            <WifiOff className="size-3" aria-hidden /> Calculated directly from your data (AI unavailable)
          </p>
        )}
      </div>
    </div>
  );
}

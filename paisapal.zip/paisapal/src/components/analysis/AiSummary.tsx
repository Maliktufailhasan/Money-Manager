"use client";
import { Sparkles } from "lucide-react";
import { useState } from "react";
import { Markdown } from "@/components/Markdown";
import { Button, SourceTag } from "@/components/ui";
import { api, ApiError } from "@/lib/client/api";

/** Asks the server for an AI-written summary of this month (grounded in computed context). */
export function AiSummary({ disabled }: { disabled?: boolean }) {
  const [text, setText] = useState<string | null>(null);
  const [err, setErr] = useState<{ msg: string; notConfigured: boolean } | null>(null);
  const [loading, setLoading] = useState(false);

  async function run() {
    setLoading(true);
    setErr(null);
    try {
      const r = await api<{ text: string }>("/api/ai/insights", { method: "POST" });
      setText(r.text);
    } catch (e) {
      const notConfigured = e instanceof ApiError && e.status === 503;
      setErr({ msg: e instanceof Error ? e.message : "Something went wrong", notConfigured });
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="mt-4 border-t border-line pt-4">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <p className="text-xs text-muted">Want a written summary with suggested adjustments?</p>
        <Button variant="soft" size="sm" onClick={run} loading={loading} disabled={disabled}>
          <Sparkles className="size-4" aria-hidden /> {text ? "Regenerate" : "Generate AI summary"}
        </Button>
      </div>
      {err && (
        <div className="mt-3 rounded-xl bg-warn-soft p-3 text-sm text-warn">
          {err.notConfigured ? (
            <>
              <p className="font-medium">AI summaries aren&apos;t set up on this server.</p>
              <p className="mt-0.5 opacity-90">The insights above are calculated without AI and are still accurate. You can also ask questions on the AI Assistant page, which answers from your data in offline mode.</p>
            </>
          ) : (
            <p>{err.msg}</p>
          )}
        </div>
      )}
      {text && (
        <div className="mt-3 rounded-xl border border-line bg-surface-2/50 p-4 text-sm">
          <div className="mb-2 flex items-center gap-2">
            <SourceTag kind="ai" />
            <span className="text-xs text-muted">AI-written from your recorded data — double-check before acting.</span>
          </div>
          <Markdown text={text} />
        </div>
      )}
    </div>
  );
}

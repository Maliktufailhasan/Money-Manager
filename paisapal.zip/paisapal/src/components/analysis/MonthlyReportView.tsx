"use client";
import { ChevronLeft, ChevronRight, FileDown, FileSpreadsheet, FileText, Lightbulb } from "lucide-react";
import { useMemo, useState } from "react";
import { BarsChart, ChartBox, COLORS, Donut, RankBars, SERIES, categoryColor } from "@/components/charts";
import { Badge, Button, Card, CardTitle, IconButton, Money, Progress, SourceTag, Stat, cn, useToast } from "@/components/ui";
import { dailySeries, fmtDate, formatINR, isoFromYM, monthEnd, monthStart, monthlyReport, txInRange, ym, type BudgetState } from "@/lib/finance";
import type { Snapshot } from "@/lib/types";
import { Delta } from "./WeeklyReviewView";
import { exportCSV, exportExcel, exportPDF } from "./exporters";

const STATE: Record<BudgetState, { label: string; tone: "good" | "warn" | "bad" | "neutral" }> = {
  under: { label: "On track", tone: "good" },
  near: { label: "Near limit", tone: "warn" },
  over: { label: "Over", tone: "bad" },
  unbudgeted: { label: "No budget", tone: "neutral" },
};

export function MonthlyReportView({ s, today }: { s: Snapshot; today: string }) {
  const toast = useToast();
  const [cur, setCur] = useState(() => ym(today));
  const [busy, setBusy] = useState<"pdf" | "csv" | "xlsx" | null>(null);
  const from = isoFromYM(cur.year, cur.month, 1);
  const to = monthEnd(from);
  const earliest = monthStart(s.totals.first_date && s.totals.first_date > s.windowStart ? s.totals.first_date : s.windowStart);
  const isCurrent = from === monthStart(today);

  const r = useMemo(() => monthlyReport(s, cur.year, cur.month, today), [s, cur, today]);
  const monthTx = useMemo(() => txInRange(s.transactions, from, to).sort((a, b) => (a.date < b.date ? -1 : a.date > b.date ? 1 : 0)), [s.transactions, from, to]);
  const daily = useMemo(() => dailySeries(s.transactions, from, to > today ? today : to).map((d) => ({ ...d })), [s.transactions, from, to, today]);
  const recurringTx = monthTx.filter((t) => t.type === "expense" && t.recurring);
  const activeSubs = s.subscriptions.filter((x) => x.status === "active");
  const sm = r.summary;
  const hasData = monthTx.length > 0;

  const shift = (n: number) => {
    const t = (cur.year * 12 + cur.month - 1) + n;
    setCur({ year: Math.floor(t / 12), month: (t % 12) + 1 });
  };

  async function doExport(kind: "pdf" | "csv" | "xlsx") {
    setBusy(kind);
    try {
      if (kind === "csv") exportCSV(r, monthTx);
      else if (kind === "xlsx") await exportExcel(r, monthTx);
      else await exportPDF(r, monthTx);
      toast(`${kind.toUpperCase()} downloaded`);
    } catch (e) {
      console.error(e);
      toast(e instanceof Error ? `Export failed: ${e.message}` : "Export failed", "bad");
    } finally {
      setBusy(null);
    }
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between gap-2">
        <IconButton label="Previous month" onClick={() => shift(-1)} disabled={from <= earliest} className="disabled:opacity-40">
          <ChevronLeft className="size-5" />
        </IconButton>
        <div className="text-center">
          <p className="font-medium">{r.label}</p>
          <p className="text-xs text-muted">{isCurrent ? "This month (so far)" : "Monthly report"}</p>
        </div>
        <IconButton label="Next month" onClick={() => shift(1)} disabled={isCurrent} className="disabled:opacity-40">
          <ChevronRight className="size-5" />
        </IconButton>
      </div>

      <div className="flex flex-wrap items-center gap-2">
        <span className="mr-1 text-xs text-muted">Export:</span>
        <Button variant="secondary" size="sm" onClick={() => doExport("pdf")} loading={busy === "pdf"} disabled={!!busy || !hasData}>
          <FileText className="size-4" aria-hidden /> PDF
        </Button>
        <Button variant="secondary" size="sm" onClick={() => doExport("csv")} loading={busy === "csv"} disabled={!!busy || !hasData}>
          <FileDown className="size-4" aria-hidden /> CSV
        </Button>
        <Button variant="secondary" size="sm" onClick={() => doExport("xlsx")} loading={busy === "xlsx"} disabled={!!busy || !hasData}>
          <FileSpreadsheet className="size-4" aria-hidden /> Excel
        </Button>
      </div>

      {!hasData ? (
        <Card>
          <p className="py-6 text-center text-sm text-muted">Nothing recorded in {r.label}.</p>
        </Card>
      ) : (
        <>
          <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
            <Stat label="Income" value={<Money value={sm.received} />} sub={`${sm.incomeCount} entries`} />
            <Stat label="Expenses" value={<Money value={sm.spent} />} sub={`${sm.expenseCount} expenses${sm.refunds ? ` · ${formatINR(sm.refunds)} refunds` : ""}`} />
            <Stat label="Savings" value={<Money value={sm.saved} sign />} tone={sm.saved >= 0 ? "good" : "bad"} sub={sm.savingsRate === null ? "No income recorded" : `${Math.round(sm.savingsRate)}% of income`} />
            <Stat label="Biggest category" value={r.highest?.name ?? "—"} sub={r.highest ? formatINR(r.highest.amount) : undefined} />
          </div>

          <Card>
            <CardTitle hint="Compared with the previous month.">Month over month</CardTitle>
            <div className="grid grid-cols-3 gap-2">
              <Delta label="Income" now={sm.received} before={r.previous.received} goodWhenUp />
              <Delta label="Expenses" now={sm.spent} before={r.previous.spent} />
              <Delta label="Saved" now={sm.saved} before={r.previous.saved} goodWhenUp />
            </div>
          </Card>

          <ChartBox title="Spending trend" hint="Daily spending this month." table={{ columns: ["Day", "Spent", "Received"], rows: daily.map((d) => [d.label, d.expense, d.income]) }}>
            <BarsChart data={daily} xKey="label" series={[{ key: "expense", label: "Spent", color: COLORS.expense }]} height={200} />
          </ChartBox>

          <div className="grid gap-4 lg:grid-cols-2">
            <Card>
              <CardTitle action={<SourceTag kind="recorded" />}>Top spending categories</CardTitle>
              <Donut data={sm.byCategory.map((c) => ({ name: c.name, value: c.amount }))} height={160} />
            </Card>
            <Card>
              <CardTitle action={<SourceTag kind="recorded" />}>Income sources</CardTitle>
              <RankBars items={sm.bySource.map((c) => ({ name: c.name, value: c.amount, sub: `${c.count}×` }))} colorFor={() => COLORS.income} />
            </Card>
            <Card>
              <CardTitle>Largest transactions</CardTitle>
              <ul className="divide-y divide-line">
                {sm.largestExpenses.map((t) => (
                  <li key={t.id} className="flex items-center justify-between gap-3 py-2 text-sm">
                    <div className="min-w-0">
                      <p className="truncate">{t.description || t.merchant || t.subcategory || t.category}</p>
                      <p className="text-xs text-muted">
                        {fmtDate(t.date)} · {t.category}
                      </p>
                    </div>
                    <Money value={t.amount} className="shrink-0 font-medium" />
                  </li>
                ))}
              </ul>
            </Card>
            <Card>
              <CardTitle hint="As classified when recorded.">Needs vs wants</CardTitle>
              <RankBars
                items={[
                  { name: "Needs", value: sm.needs },
                  { name: "Wants", value: sm.wants },
                  { name: "Unclassified", value: sm.unclassified },
                ].filter((x) => x.value > 0)}
                colorFor={(n) => (n === "Needs" ? SERIES[0] : n === "Wants" ? SERIES[1] : "var(--muted)")}
              />
              <p className="mt-3 text-xs text-muted">
                Essential {formatINR(sm.essential)} · Non-essential {formatINR(sm.nonEssential)}
              </p>
            </Card>
          </div>

          <Card>
            <CardTitle hint={r.budget.hasBudget ? `${formatINR(r.budget.totalSpent)} spent of ${formatINR(r.budget.totalBudget)} budgeted` : "No budget was set for this month."}>Budget performance</CardTitle>
            {r.budget.rows.length ? (
              <div className="-mx-1 overflow-x-auto">
                <table className="w-full min-w-[480px] text-sm">
                  <thead className="text-left text-xs text-muted">
                    <tr>
                      <th className="px-1 py-1.5 font-medium">Category</th>
                      <th className="px-1 py-1.5 text-right font-medium">Budget</th>
                      <th className="px-1 py-1.5 text-right font-medium">Spent</th>
                      <th className="px-1 py-1.5 text-right font-medium">Left</th>
                      <th className="px-1 py-1.5 text-right font-medium">Status</th>
                    </tr>
                  </thead>
                  <tbody className="tabular">
                    {r.budget.rows.map((b) => (
                      <tr key={b.category} className="border-t border-line">
                        <td className="px-1 py-2">
                          <span className="flex items-center gap-2">
                            <span className="size-2.5 rounded-sm" style={{ background: categoryColor(b.category) }} />
                            {b.category}
                          </span>
                        </td>
                        <td className="px-1 py-2 text-right">{b.budget ? formatINR(b.budget) : "—"}</td>
                        <td className="px-1 py-2 text-right">{formatINR(b.spent)}</td>
                        <td className={cn("px-1 py-2 text-right", b.budget && b.remaining < 0 && "text-bad")}>{b.budget ? formatINR(b.remaining) : "—"}</td>
                        <td className="px-1 py-2 text-right">
                          <Badge tone={STATE[b.state].tone}>
                            {STATE[b.state].label}
                            {b.usedPct !== null && ` · ${Math.round(b.usedPct)}%`}
                          </Badge>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <p className="text-sm text-muted">No expenses to compare.</p>
            )}
          </Card>

          <div className="grid gap-4 lg:grid-cols-2">
            <Card>
              <CardTitle>Goal progress</CardTitle>
              {r.goals.length === 0 ? (
                <p className="text-sm text-muted">No goals yet.</p>
              ) : (
                <ul className="space-y-3">
                  {r.goals.map((g) => (
                    <li key={g.name}>
                      <div className="mb-1 flex justify-between gap-2 text-sm">
                        <span className="truncate">{g.name}</span>
                        <span className="shrink-0 text-xs text-muted tabular">
                          {formatINR(g.saved)} / {formatINR(g.target)}
                        </span>
                      </div>
                      <Progress value={g.pct} tone={g.pct >= 100 ? "good" : "brand"} label={`${g.name} progress`} />
                      <p className="mt-1 text-xs text-muted">
                        {Math.round(g.pct)}% · {g.addedThisMonth ? `${formatINR(g.addedThisMonth, { sign: true })} this month` : "nothing added this month"} · {g.status}
                      </p>
                    </li>
                  ))}
                </ul>
              )}
            </Card>
            <Card>
              <CardTitle hint="Current active subscriptions and recurring bills.">Subscriptions & recurring</CardTitle>
              <div className="grid grid-cols-2 gap-3">
                <div className="rounded-xl bg-surface-2 p-3">
                  <p className="text-xs text-muted">Subscriptions</p>
                  <p className="font-semibold tabular">{formatINR(r.subscriptionsMonthly)}/mo</p>
                  <p className="text-xs text-muted tabular">{formatINR(r.subscriptionsMonthly * 12)}/year</p>
                </div>
                <div className="rounded-xl bg-surface-2 p-3">
                  <p className="text-xs text-muted">All recurring</p>
                  <p className="font-semibold tabular">{formatINR(r.recurringMonthly)}/mo</p>
                  <p className="text-xs text-muted tabular">{formatINR(r.recurringMonthly * 12)}/year</p>
                </div>
              </div>
              {activeSubs.length > 0 && <p className="mt-3 text-xs text-muted">{activeSubs.map((x) => x.name).join(" · ")}</p>}
              {recurringTx.length > 0 && (
                <>
                  <p className="mt-4 mb-1 text-xs font-medium text-ink-2">Recurring expenses recorded this month ({formatINR(sm.recurringSpent)})</p>
                  <ul className="divide-y divide-line">
                    {recurringTx.slice(0, 8).map((t) => (
                      <li key={t.id} className="flex justify-between gap-2 py-1.5 text-sm">
                        <span className="truncate">{t.description || t.merchant || t.subcategory || t.category}</span>
                        <Money value={t.amount} className="shrink-0" />
                      </li>
                    ))}
                  </ul>
                </>
              )}
            </Card>
          </div>

          <Card>
            <CardTitle hint="Calculated from your records up to the end of this month.">Insights</CardTitle>
            {r.insights.length ? (
              <ul className="space-y-2">
                {r.insights.map((i) => (
                  <li key={i.id} className="flex items-start justify-between gap-3 text-sm">
                    <span>{i.text}</span>
                    <SourceTag kind={i.basis} />
                  </li>
                ))}
              </ul>
            ) : (
              <p className="text-sm text-muted">No insights for this month.</p>
            )}
          </Card>

          <Card>
            <CardTitle>Suggested adjustments for next month</CardTitle>
            <ul className="space-y-2">
              {r.adjustments.map((a) => (
                <li key={a} className="flex gap-2 text-sm">
                  <Lightbulb className="mt-0.5 size-4 shrink-0 text-brand" aria-hidden />
                  <span>{a}</span>
                </li>
              ))}
            </ul>
          </Card>
        </>
      )}
    </div>
  );
}

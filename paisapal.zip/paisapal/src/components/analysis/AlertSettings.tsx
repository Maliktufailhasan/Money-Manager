"use client";
import { useState } from "react";
import { Button, Field, MoneyInput, Toggle, useToast } from "@/components/ui";
import { updateProfile } from "@/lib/client/api";
import type { AlertKind, Profile } from "@/lib/types";

export const ALERT_KINDS: { kind: AlertKind; label: string; description: string }[] = [
  { kind: "daily_limit", label: "Daily limit", description: "When today's spending goes over your daily target." },
  { kind: "budget", label: "Budget limits", description: "When a category reaches 80% or goes over budget." },
  { kind: "unusual", label: "Unusual spending", description: "When today is much higher than your usual daily spend." },
  { kind: "upcoming_payment", label: "Upcoming payments", description: "Bills and reminders due in the next 3 days." },
  { kind: "subscription_renewal", label: "Subscription renewals", description: "Before a subscription renews." },
  { kind: "goal_behind", label: "Goals falling behind", description: "When a goal's pace won't meet its target date." },
  { kind: "low_balance", label: "Low balance", description: "When your balance drops below your threshold." },
  { kind: "no_savings", label: "No savings this month", description: "Late in the month with nothing saved yet." },
  { kind: "large_transaction", label: "Large transactions", description: "When a big expense is recorded." },
  { kind: "no_spend", label: "Don't-spend rules", description: "When you break a no-spend challenge limit." },
];

export function AlertSettings({ profile }: { profile: Profile }) {
  const toast = useToast();
  const prefs = profile.preferences ?? {};
  const [local, setLocal] = useState<Partial<Record<AlertKind, boolean>>>({});
  const [low, setLow] = useState(String(prefs.low_balance_threshold ?? 1000));
  const [big, setBig] = useState(String(prefs.large_txn_threshold ?? 2000));
  const [saving, setSaving] = useState(false);

  const isOn = (k: AlertKind) => local[k] ?? (prefs.alerts?.[k] !== false);

  async function toggle(kind: AlertKind, value: boolean) {
    setLocal((l) => ({ ...l, [kind]: value }));
    try {
      await updateProfile({ preferences: { alerts: { ...(prefs.alerts ?? {}), ...local, [kind]: value } } });
      toast(`${value ? "Enabled" : "Turned off"} ${ALERT_KINDS.find((a) => a.kind === kind)?.label.toLowerCase()} alerts`, "info");
    } catch (e) {
      setLocal((l) => ({ ...l, [kind]: !value }));
      toast(e instanceof Error ? e.message : "Couldn't save", "bad");
    }
  }

  async function saveThresholds(e: React.FormEvent) {
    e.preventDefault();
    const lowN = Number(low);
    const bigN = Number(big);
    if (!Number.isFinite(lowN) || lowN < 0 || !Number.isFinite(bigN) || bigN <= 0) {
      toast("Enter valid amounts", "warn");
      return;
    }
    setSaving(true);
    try {
      await updateProfile({ preferences: { low_balance_threshold: lowN, large_txn_threshold: bigN } });
      toast("Thresholds saved");
    } catch (err) {
      toast(err instanceof Error ? err.message : "Couldn't save", "bad");
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="space-y-5">
      <div className="grid gap-x-8 gap-y-1 sm:grid-cols-2">
        {ALERT_KINDS.map((a) => (
          <Toggle key={a.kind} checked={isOn(a.kind)} onChange={(v) => toggle(a.kind, v)} label={a.label} description={a.description} />
        ))}
      </div>
      <form onSubmit={saveThresholds} className="grid items-end gap-3 border-t border-line pt-4 sm:grid-cols-[1fr_1fr_auto]">
        <Field label="Low balance threshold" hint="Alert when balance falls below this.">
          {(id) => <MoneyInput id={id} value={low} onChange={setLow} />}
        </Field>
        <Field label="Large transaction threshold" hint="Alert for expenses at or above this.">
          {(id) => <MoneyInput id={id} value={big} onChange={setBig} />}
        </Field>
        <Button type="submit" loading={saving} className="sm:mb-5">
          Save
        </Button>
      </form>
    </div>
  );
}

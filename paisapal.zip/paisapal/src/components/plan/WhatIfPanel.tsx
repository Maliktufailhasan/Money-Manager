"use client";
import { CalendarPlus, Coffee, Coins, PiggyBank, Scissors, type LucideIcon } from "lucide-react";
import { useMemo, useState, type ReactNode } from "react";
import { addDays, fmtDate, formatINR, goalMetrics, goalsMonthlyCommitment, whatIf, type FinancialPosition, type GoalMetrics, type WhatIf, type WhatIfResult } from "@/lib/finance";
import type { Snapshot } from "@/lib/types";
import { Badge, Card, Field, Input, MoneyInput, Select, SourceTag } from "@/components/ui";
import { categoryAverages, snackDailyAverage } from "./calc";
import { monthsLabel, num, str } from "./shared";

export function WhatIfPanel({ s, position, today }: { s: Snapshot; position: FinancialPosition; today: string }) {
  const metrics = useMemo(
    () =>
      s.goals
        .filter((g) => g.status === "active")
        .map((g) => goalMetrics(g, s.contributions, today, Math.max(0, position.savingCapacity - goalsMonthlyCommitment(s.goals, today, g.id))))
        .filter((m) => m.remaining > 0),
    [s, today, position.savingCapacity],
  );
  const { avg, monthsUsed } = useMemo(() => categoryAverages(s, today), [s, today]);
  const cats = [...avg.entries()].filter(([, v]) => v > 0).sort((a, b) => b[1] - a[1]);
  const snackAvg = useMemo(() => snackDailyAverage(s, today), [s, today]);
  const datedGoals = metrics.filter((m) => m.goal.target_date && (m.monthsLeft ?? 0) > 0);

  const [mainId, setMainId] = useState(metrics[0]?.goal.id ?? "");
  const [stop, setStop] = useState(str(snackAvg > 0 ? Math.round(snackAvg) : 100));
  const [save, setSave] = useState("50");
  const [earn, setEarn] = useState("3000");
  const [cat, setCat] = useState(cats[0]?.[0] ?? "");
  const [pct, setPct] = useState("20");
  const [delayId, setDelayId] = useState(datedGoals[0]?.goal.id ?? "");
  const [delay, setDelay] = useState("2");

  const main = metrics.find((m) => m.goal.id === mainId);
  const delayGoal = datedGoals.find((m) => m.goal.id === delayId);
  const catMonthly = avg.get(cat) ?? 0;

  return (
    <div className="space-y-4">
      <Card className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <h2 className="text-sm font-semibold">What if?</h2>
          <p className="text-xs text-muted">Small changes add up. See what each habit is worth per month and per year.</p>
        </div>
        {metrics.length > 0 && (
          <Field label="Show impact on" className="sm:w-64">
            {(id) => (
              <Select id={id} value={mainId} onChange={(e) => setMainId(e.target.value)}>
                {metrics.map((m) => (
                  <option key={m.goal.id} value={m.goal.id}>
                    {m.goal.name} ({formatINR(m.remaining)} left)
                  </option>
                ))}
              </Select>
            )}
          </Field>
        )}
      </Card>

      <div className="grid gap-4 md:grid-cols-2">
        <Preset
          icon={Coffee}
          title={`Stop spending ${formatINR(num(stop))}/day on snacks`}
          hint={snackAvg > 0 ? `You spent ~${formatINR(snackAvg)}/day on snacks & tea/coffee in the last 30 days.` : "No snack spending recorded in the last 30 days — using ₹100 as an example."}
          tag={snackAvg > 0 ? "recorded" : "assumption"}
          input={<MoneyInput aria-label="Daily amount" value={stop} onChange={setStop} />}
          w={{ kind: "stop_daily", amount: num(stop) }}
          main={main}
          today={today}
        />
        <Preset icon={PiggyBank} title={`Save ${formatINR(num(save))}/day`} hint="Put a fixed amount aside every day." tag="assumption" input={<MoneyInput aria-label="Daily saving" value={save} onChange={setSave} />} w={{ kind: "save_daily", amount: num(save) }} main={main} today={today} />
        <Preset
          icon={Coins}
          title={`Earn ${formatINR(num(earn))} extra/month`}
          hint="Tutoring, freelancing, a part-time gig… Not guaranteed until earned."
          tag="assumption"
          input={<MoneyInput aria-label="Extra monthly income" value={earn} onChange={setEarn} />}
          w={{ kind: "earn_monthly", amount: num(earn) }}
          main={main}
          today={today}
        />
        {cats.length > 0 ? (
          <Preset
            icon={Scissors}
            title={`Reduce ${cat || "a category"} by ${num(pct)}%`}
            hint={`Based on your ${monthsUsed}-month average for ${cat}: ${formatINR(catMonthly)}/month.`}
            tag="recorded"
            input={
              <div className="grid grid-cols-[1fr_6rem] gap-2">
                <Select aria-label="Category" value={cat} onChange={(e) => setCat(e.target.value)}>
                  {cats.map(([c, v]) => (
                    <option key={c} value={c}>
                      {c} ({formatINR(v)}/mo)
                    </option>
                  ))}
                </Select>
                <div className="relative">
                  <Input aria-label="Percent" type="number" min={1} max={100} value={pct} onChange={(e) => setPct(e.target.value)} className="pr-7" />
                  <span className="pointer-events-none absolute inset-y-0 right-3 flex items-center text-sm text-muted">%</span>
                </div>
              </div>
            }
            w={{ kind: "reduce_category", category: cat, percent: Math.min(100, Math.max(0, num(pct))), categoryMonthly: catMonthly }}
            main={main}
            today={today}
          />
        ) : (
          <Card className="text-sm text-muted">
            <p className="mb-1 flex items-center gap-2 font-medium text-ink">
              <Scissors className="size-4" /> Reduce a category
            </p>
            Needs at least one complete month of recorded expenses to know your category averages.
          </Card>
        )}
        {delayGoal ? (
          <Preset
            icon={CalendarPlus}
            title={`Delay ${delayGoal.goal.name} by ${num(delay)} months`}
            hint={`Due ${fmtDate(delayGoal.goal.target_date!, { year: true })} · ${formatINR(delayGoal.remaining)} left`}
            tag="calculated"
            input={
              <div className="grid grid-cols-[1fr_6rem] gap-2">
                <Select aria-label="Goal to delay" value={delayId} onChange={(e) => setDelayId(e.target.value)}>
                  {datedGoals.map((m) => (
                    <option key={m.goal.id} value={m.goal.id}>
                      {m.goal.name}
                    </option>
                  ))}
                </Select>
                <Input aria-label="Months" type="number" min={1} max={60} value={delay} onChange={(e) => setDelay(e.target.value)} />
              </div>
            }
            w={{ kind: "delay_goal", months: Math.max(0, num(delay)), remaining: delayGoal.remaining, monthsLeft: delayGoal.monthsLeft ?? 0 }}
            today={today}
          />
        ) : (
          <Card className="text-sm text-muted">
            <p className="mb-1 flex items-center gap-2 font-medium text-ink">
              <CalendarPlus className="size-4" /> Delay a goal
            </p>
            Add a target date to a goal to see how pushing it back lowers your monthly saving.
          </Card>
        )}
      </div>
    </div>
  );
}

function Preset({ icon: Icon, title, hint, tag, input, w, main, today }: { today: string; icon: LucideIcon; title: string; hint: string; tag: "recorded" | "assumption" | "calculated"; input: ReactNode; w: WhatIf; main?: GoalMetrics }) {
  const r: WhatIfResult = whatIf(w, main && w.kind !== "delay_goal" ? main.remaining : undefined);
  // impact on the chosen goal: current monthly pace (goal pace or free capacity) + this change
  let impact: { before: number | null; after: number; date: string } | null = null;
  if (main && w.kind !== "delay_goal" && r.monthly > 0) {
    const base = main.recentPace > 0 ? main.recentPace : main.etaMonths && main.etaMonths > 0 ? main.remaining / main.etaMonths : 0;
    const after = Math.ceil((main.remaining / (base + r.monthly)) * 10) / 10;
    impact = { before: main.etaMonths, after, date: addDays(today, Math.ceil(after * 30.4375)) };
  }
  return (
    <Card className="flex flex-col gap-3">
      <div className="flex items-start justify-between gap-2">
        <p className="flex items-center gap-2 text-sm font-semibold">
          <Icon className="size-4 shrink-0 text-brand" /> {title}
        </p>
        <SourceTag kind={tag} />
      </div>
      <p className="-mt-1 text-xs text-muted">{hint}</p>
      {input}
      <div className="grid grid-cols-2 gap-2 text-center">
        <div className="rounded-xl bg-good-soft px-2 py-2">
          <p className="text-xs text-good">{w.kind === "delay_goal" ? "Frees up" : "Per month"}</p>
          <p className="font-semibold text-good tabular">{formatINR(r.monthly)}</p>
        </div>
        <div className="rounded-xl bg-good-soft px-2 py-2">
          <p className="text-xs text-good">Per year</p>
          <p className="font-semibold text-good tabular">{formatINR(r.yearly)}</p>
        </div>
      </div>
      <ul className="space-y-0.5 text-xs text-ink-2 tabular">
        {r.lines.map((l) => (
          <li key={l}>{l}</li>
        ))}
      </ul>
      {impact && main && (
        <div className="mt-auto rounded-xl border border-line px-3 py-2 text-xs">
          <span className="font-medium">{main.goal.name}:</span>{" "}
          {impact.before !== null ? (
            <>
              {monthsLabel(impact.before)} → <span className="font-semibold text-good">{monthsLabel(impact.after)}</span>
            </>
          ) : (
            <>
              reachable in <span className="font-semibold text-good">{monthsLabel(impact.after)}</span>
            </>
          )}{" "}
          <Badge tone="good">by {fmtDate(impact.date, { year: true })}</Badge>
        </div>
      )}
    </Card>
  );
}

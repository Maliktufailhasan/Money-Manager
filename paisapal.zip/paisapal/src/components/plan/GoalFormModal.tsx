"use client";
import { useState } from "react";
import { GOAL_CATEGORIES } from "@/lib/constants";
import { db } from "@/lib/client/api";
import { addMonths } from "@/lib/finance";
import type { Goal } from "@/lib/types";
import { Button, Chip, Field, Input, MoneyInput, Modal, Select, Textarea, Toggle, useToast } from "@/components/ui";
import { num, str } from "./shared";

export interface GoalPreset {
  name?: string;
  target_amount?: number;
  current_amount?: number;
  target_date?: string | null;
  category?: string;
  is_emergency?: boolean;
  notes?: string;
}

const chipName = (cat: string) => (cat === "Emergency Fund" ? "Emergency Fund" : cat === "Custom" ? "" : cat === "Trip" ? "Trip" : `New ${cat}`);

/**
 * Create / edit a goal. Mount it only while open (state is initialised from
 * props on mount), e.g. `{open && <GoalFormModal … />}`.
 */
export function GoalFormModal({ goal, preset, today, onClose, onSaved }: { goal?: Goal; preset?: GoalPreset; today: string; onClose: () => void; onSaved?: (g: Goal) => void }) {
  const toast = useToast();
  const src = goal ?? preset ?? {};
  const [name, setName] = useState(src.name ?? "");
  const [target, setTarget] = useState(str(src.target_amount));
  const [current, setCurrent] = useState(goal ? "" : str(preset?.current_amount));
  const [date, setDate] = useState(src.target_date ?? "");
  const [priority, setPriority] = useState<Goal["priority"]>(goal?.priority ?? "medium");
  const [category, setCategory] = useState(src.category ?? "Custom");
  const [notes, setNotes] = useState(src.notes ?? "");
  const [emergency, setEmergency] = useState(src.is_emergency ?? false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const pick = (cat: string) => {
    // only replace the name if the user hasn't typed their own
    if (!name.trim() || name === chipName(category)) setName(chipName(cat));
    setCategory(cat);
    if (cat === "Emergency Fund") setEmergency(true);
    else if (category === "Emergency Fund") setEmergency(false);
  };

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    const t = num(target);
    const c = num(current);
    if (!name.trim()) return setError("Give your goal a name.");
    if (t <= 0) return setError("Enter a target amount above ₹0.");
    if (!goal && c > t) return setError("Current savings can't be more than the target.");
    if (date && !goal && date < today) return setError("Pick a target date in the future.");
    setError(null);
    setSaving(true);
    try {
      const body = {
        name: name.trim(),
        target_amount: t,
        target_date: date || null,
        priority,
        category,
        is_emergency: emergency,
        notes: notes.trim() || null,
        ...(goal ? {} : { current_amount: c }),
      };
      const saved = goal ? await db.update<Goal>("goals", goal.id, body) : await db.create<Goal>("goals", body);
      toast(goal ? "Goal updated" : "Goal created 🎯");
      onSaved?.(saved);
      onClose();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Couldn't save the goal.");
    } finally {
      setSaving(false);
    }
  };

  return (
    <Modal
      open
      onClose={onClose}
      title={goal ? "Edit goal" : "New goal"}
      footer={
        <>
          <Button variant="ghost" type="button" onClick={onClose}>
            Cancel
          </Button>
          <Button type="submit" form="goal-form" loading={saving}>
            {goal ? "Save changes" : "Create goal"}
          </Button>
        </>
      }
    >
      <form id="goal-form" onSubmit={submit} className="space-y-4">
        <div>
          <p className="mb-2 text-xs font-medium text-ink-2">What are you saving for?</p>
          <div className="flex flex-wrap gap-1.5">
            {GOAL_CATEGORIES.map((c) => (
              <Chip key={c} active={category === c} onClick={() => pick(c)}>
                {c}
              </Chip>
            ))}
          </div>
        </div>
        <Field label="Goal name">{(id) => <Input id={id} value={name} onChange={(e) => setName(e.target.value)} placeholder="e.g. New Phone" maxLength={80} required />}</Field>
        <div className="grid grid-cols-2 gap-3">
          <Field label="Target amount">{(id) => <MoneyInput id={id} value={target} onChange={setTarget} placeholder="25000" required />}</Field>
          {goal ? (
            <Field label="Saved so far" hint="Change via Add money / Withdraw">
              {(id) => <Input id={id} value={`₹${goal.current_amount.toLocaleString("en-IN")}`} disabled readOnly />}
            </Field>
          ) : (
            <Field label="Already saved" hint="Optional">
              {(id) => <MoneyInput id={id} value={current} onChange={setCurrent} placeholder="0" />}
            </Field>
          )}
        </div>
        <div className="grid grid-cols-2 gap-3">
          <Field label="Target date" hint="Optional">
            {(id) => <Input id={id} type="date" value={date} min={goal ? undefined : today} onChange={(e) => setDate(e.target.value)} />}
          </Field>
          <Field label="Priority">
            {(id) => (
              <Select id={id} value={priority} onChange={(e) => setPriority(e.target.value as Goal["priority"])}>
                <option value="high">High</option>
                <option value="medium">Medium</option>
                <option value="low">Low</option>
              </Select>
            )}
          </Field>
        </div>
        <div className="flex flex-wrap gap-1.5">
          {[3, 6, 12].map((m) => (
            <Chip key={m} onClick={() => setDate(addMonths(today, m))} active={date === addMonths(today, m)}>
              In {m} months
            </Chip>
          ))}
        </div>
        <Field label="Notes" hint="Optional">
          {(id) => <Textarea id={id} value={notes} onChange={(e) => setNotes(e.target.value)} maxLength={500} placeholder="Model, link, why it matters…" />}
        </Field>
        <Toggle checked={emergency} onChange={setEmergency} label="This is my emergency fund" description="Money kept aside for surprises — shown on the Savings page." />
        {error && <p className="text-sm text-bad">{error}</p>}
      </form>
    </Modal>
  );
}

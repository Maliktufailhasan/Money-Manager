import { addDays, addMonths, monthEnd, monthStart, monthlyFactor, round2, spentOn, subscriptionMonthlyCost, sum, summarize } from "@/lib/finance";
import type { Snapshot } from "@/lib/types";

/**
 * Average monthly spend per expense category over the last `months` complete
 * months that have data (months before the first transaction are skipped).
 */
export function categoryAverages(s: Snapshot, today: string, months = 3): { avg: Map<string, number>; monthsUsed: number } {
  const first = s.totals.first_date ? monthStart(s.totals.first_date) : null;
  const totals = new Map<string, number>();
  let used = 0;
  if (first) {
    for (let i = 1; i <= months; i++) {
      const m = addMonths(monthStart(today), -i);
      if (m < first) break;
      used++;
      for (const c of summarize(s.transactions, m, monthEnd(m)).byCategory) totals.set(c.name, (totals.get(c.name) ?? 0) + c.amount);
    }
  }
  const avg = new Map<string, number>();
  if (used) for (const [k, v] of totals) avg.set(k, round2(v / used));
  return { avg, monthsUsed: used };
}

/** Monthly cost of active subscriptions and recurring bills, by category. */
export function recurringByCategory(s: Snapshot): Map<string, number> {
  const out = new Map<string, number>();
  for (const sub of s.subscriptions.filter((x) => x.status === "active")) out.set(sub.category, (out.get(sub.category) ?? 0) + subscriptionMonthlyCost(sub));
  for (const r of s.reminders.filter((x) => x.recurring !== "none" && !x.completed)) out.set(r.category, (out.get(r.category) ?? 0) + r.amount * monthlyFactor(r.recurring));
  for (const [k, v] of out) out.set(k, round2(v));
  return out;
}

/** Average daily spend on snacks + tea/coffee over the last 30 days (0 if none). */
export function snackDailyAverage(s: Snapshot, today: string): number {
  const total = spentOn(s.transactions, addDays(today, -29), today, (t) => t.category === "Food" && ["Snacks", "Tea/Coffee"].includes(t.subcategory ?? ""));
  return round2(total / 30);
}

/** Expected monthly income from earning sources that aren't stopped (an assumption). */
export function trackedExtraIncome(s: Snapshot): number {
  return sum(s.earningSources.filter((e) => e.status !== "stopped").map((e) => e.expected_income));
}

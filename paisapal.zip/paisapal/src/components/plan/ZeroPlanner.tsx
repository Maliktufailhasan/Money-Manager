"use client";
import { ArrowDown, Bot, Lightbulb, Save, Wand2 } from "lucide-react";
import { useState } from "react";
import { GOAL_CATEGORIES } from "@/lib/constants";
import { api, db } from "@/lib/client/api";
import { addMonths, fmtDate, formatINR, type WasteFinding, type ZeroPlan } from "@/lib/finance";
import { Markdown } from "@/components/Markdown";
import { Badge, Button, Card, CardTitle, Chip, Field, Input, MoneyInput, SourceTag, cn, useToast } from "@/components/ui";
import { num } from "./shared";

interface PlanResponse {
  plan: ZeroPlan;
  cuts: WasteFinding[];
  narrative: string | null;
  mode: "ai" | "offline";
  aiError: string | null;
  position: { basis: string; dataQuality: string };
}

const FEAS: Record<ZeroPlan["feasibility"], { label: string; tone: "good" | "warn" | "bad" | "brand"; text: string }> = {
  comfortable: { label: "Comfortable", tone: "good", text: "Your current savings already cover this pace." },
  needs_cuts: { label: "Needs spending cuts", tone: "brand", text: "Doable by trimming some non-essential spending." },
  needs_income: { label: "Needs extra income", tone: "warn", text: "Needs extra income — within what your earning sources could bring in." },
  stretch: { label: "Stretch", tone: "bad", text: "Needs more extra income than you currently track. Consider a longer timeline." },
};

function guessCategory(item: string): string {
  const w = item.toLowerCase();
  const hit = GOAL_CATEGORIES.find((c) => c !== "Custom" && w.includes(c.toLowerCase()));
  if (hit) return hit;
  if (/iphone|mobile|smartphone/.test(w)) return "Phone";
  if (/macbook|notebook/.test(w)) return "Laptop";
  if (/scooty|scooter|cycle/.test(w)) return "Bike";
  if (/earbuds|airpods|headset/.test(w)) return "Headphones";
  return "Custom";
}

export interface ZeroInitial {
  item?: string;
  price?: string;
  months?: string;
  start?: string;
}

export function ZeroPlanner({ today, initial }: { today: string; initial: ZeroInitial }) {
  const toast = useToast();
  const [item, setItem] = useState(initial.item ?? "");
  const [price, setPrice] = useState(initial.price ?? "");
  const [months, setMonths] = useState(initial.months ?? "6");
  const [start, setStart] = useState(initial.start ?? "0");
  const [res, setRes] = useState<PlanResponse | null>(null);
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const prefilled = Boolean(initial.item && initial.price);

  const generate = async (e?: React.FormEvent) => {
    e?.preventDefault();
    const p = num(price);
    const m = Math.round(num(months));
    if (!item.trim()) return setError("What do you want to buy?");
    if (p <= 0) return setError("Enter the price.");
    if (m < 1 || m > 120) return setError("Months must be between 1 and 120.");
    if (num(start) >= p) return setError("You already have enough for this — no plan needed! 🎉");
    setError(null);
    setLoading(true);
    try {
      const r = await api<PlanResponse>("/api/ai/plan", { method: "POST", json: { item: item.trim(), price: p, months: m, startingAmount: num(start) } });
      setRes(r);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Couldn't build the plan.");
    } finally {
      setLoading(false);
    }
  };

  const saveGoal = async () => {
    if (!res) return;
    const { plan } = res;
    setSaving(true);
    try {
      await db.create("goals", {
        name: plan.item,
        target_amount: plan.price,
        current_amount: plan.totals.starting,
        target_date: addMonths(today, plan.months),
        priority: "medium",
        category: guessCategory(plan.item),
        is_emergency: false,
        notes: `Plan: ${plan.steps[7]?.value ?? ""}`.slice(0, 500),
      });
      toast("Saved as a goal 🎯 — find it on the Goals page.");
    } catch (err) {
      toast(err instanceof Error ? err.message : "Couldn't save the goal.", "bad");
    } finally {
      setSaving(false);
    }
  };

  const plan = res?.plan;
  const f = plan ? FEAS[plan.feasibility] : null;

  return (
    <div className="space-y-4">
      <Card>
        <CardTitle hint="Tell us what you want and by when — we'll build a step-by-step plan from your real numbers.">Start from ₹0</CardTitle>
        <form onSubmit={generate} className="space-y-3">
          <div className="grid gap-3 sm:grid-cols-4">
            <Field label="Item" className="sm:col-span-2">
              {(id) => <Input id={id} value={item} onChange={(e) => setItem(e.target.value)} placeholder="e.g. Laptop" maxLength={80} />}
            </Field>
            <Field label="Price">{(id) => <MoneyInput id={id} value={price} onChange={setPrice} placeholder="42000" />}</Field>
            <Field label="Months">{(id) => <Input id={id} type="number" inputMode="numeric" min={1} max={120} value={months} onChange={(e) => setMonths(e.target.value)} />}</Field>
          </div>
          <div className="grid gap-3 sm:grid-cols-4">
            <Field label="Starting amount" hint="Money you already have for this" className="sm:col-span-2">
              {(id) => <MoneyInput id={id} value={start} onChange={setStart} />}
            </Field>
            <div className="flex flex-wrap items-end gap-1.5 sm:col-span-2">
              {[3, 6, 9, 12].map((m) => (
                <Chip key={m} active={num(months) === m} onClick={() => setMonths(String(m))}>
                  {m} months
                </Chip>
              ))}
            </div>
          </div>
          {prefilled && !res && <p className="text-xs text-brand">Prefilled from your goal — tap “Make my plan”.</p>}
          {error && <p className="text-sm text-bad">{error}</p>}
          <div className="flex justify-end">
            <Button type="submit" loading={loading}>
              <Wand2 className="size-4" /> {res ? "Rebuild plan" : "Make my plan"}
            </Button>
          </div>
        </form>
      </Card>

      {plan && f && res && (
        <div className="grid gap-4 lg:grid-cols-[minmax(0,1fr)_minmax(0,1fr)] lg:items-start">
          <div className="space-y-4">
            <Card>
              <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
                <h2 className="text-sm font-semibold">
                  {plan.item} · {formatINR(plan.price)} in {plan.months} month{plan.months > 1 ? "s" : ""}
                </h2>
                <Badge tone={f.tone}>{f.label}</Badge>
              </div>
              <p className="mb-4 text-sm text-ink-2">{f.text}</p>
              <ol className="relative">
                {plan.steps.map((st, i) => (
                  <li key={st.label}>
                    <div className="flex gap-3">
                      <span className={cn("flex size-7 shrink-0 items-center justify-center rounded-full text-xs font-semibold", i === plan.steps.length - 1 ? "bg-brand text-brand-ink" : "bg-brand-soft text-brand")}>{i + 1}</span>
                      <div className="min-w-0 pb-1">
                        <p className="text-xs font-medium uppercase tracking-wide text-muted">{st.label}</p>
                        <p className="text-sm font-medium">{st.value}</p>
                        {st.note && <p className="text-xs text-muted">{st.note}</p>}
                      </div>
                    </div>
                    {i < plan.steps.length - 1 && <ArrowDown className="my-1 ml-1.5 size-4 text-muted" aria-hidden />}
                  </li>
                ))}
              </ol>
            </Card>
          </div>

          <div className="space-y-4">
            <Card>
              <CardTitle action={<SourceTag kind="calculated" />}>Where the money comes from</CardTitle>
              <table className="w-full text-sm">
                <tbody className="tabular">
                  {plan.totals.starting > 0 && <TotRow label="Starting amount" value={plan.totals.starting} />}
                  <TotRow label="Savings" value={plan.totals.savings} sub={`${formatINR(plan.savingPart)}/mo`} />
                  <TotRow label="Expense reduction" value={plan.totals.reduction} sub={`${formatINR(plan.reduction)}/mo`} />
                  <TotRow label="Extra income" value={plan.totals.income} sub={`${formatINR(plan.extraIncome)}/mo · not guaranteed`} warn={plan.totals.income > 0} />
                  <tr className="border-t-2 border-line font-semibold">
                    <td className="py-2">Total</td>
                    <td className="py-2 text-right">{formatINR(plan.totals.total)}</td>
                  </tr>
                </tbody>
              </table>
              <p className="mt-2 rounded-xl bg-surface-2 px-3 py-2 text-xs text-ink-2 tabular">
                {[plan.totals.starting > 0 && `${formatINR(plan.totals.starting)} Starting`, `${formatINR(plan.totals.savings)} Savings`, `${formatINR(plan.totals.reduction)} Expense Reduction`, `${formatINR(plan.totals.income)} Extra Income`].filter(Boolean).join(" + ")} = {formatINR(plan.totals.total)}
              </p>
              <div className="mt-3 grid grid-cols-3 gap-2 text-center">
                <Mini label="Per month" value={plan.requiredMonthly} />
                <Mini label="Per week" value={plan.weekly} />
                <Mini label="Per day" value={plan.daily} />
              </div>
              <p className="mt-2 text-xs text-muted">Target date: {fmtDate(addMonths(today, plan.months), { year: true })}</p>
            </Card>

            {res.cuts.length > 0 && (plan.reduction > 0 || plan.gap > 0) && (
              <Card>
                <CardTitle hint="From your last 30 days of spending" action={<SourceTag kind="recorded" />}>
                  Where the cut can come from
                </CardTitle>
                <ul className="space-y-2.5">
                  {res.cuts.map((c) => (
                    <li key={c.id} className="flex items-start justify-between gap-3 text-sm">
                      <div className="min-w-0">
                        <p className="font-medium">{c.title}</p>
                        <p className="text-xs text-muted">
                          {formatINR(c.amount)} in {c.count} purchases · cut {c.cutPct}%
                        </p>
                      </div>
                      <span className="shrink-0 text-good tabular">~{formatINR(c.monthlySaving)}/mo</span>
                    </li>
                  ))}
                </ul>
              </Card>
            )}

            <Card>
              <CardTitle>Assumptions</CardTitle>
              <ul className="list-disc space-y-1 pl-5 text-xs text-ink-2">
                {plan.assumptions.map((a) => (
                  <li key={a}>{a}</li>
                ))}
              </ul>
            </Card>

            <Card>
              <CardTitle action={res.narrative ? <SourceTag kind="ai" /> : undefined}>
                <span className="inline-flex items-center gap-1.5">
                  <Bot className="size-4" /> Coach&apos;s notes
                </span>
              </CardTitle>
              {res.narrative ? (
                <>
                  <Markdown text={res.narrative} className="text-sm" />
                  <p className="mt-3 text-xs text-muted">AI suggestion — the numbers above are calculated from your data; the advice is a starting point, not a guarantee.</p>
                </>
              ) : (
                <p className="flex gap-2 text-sm text-muted">
                  <Lightbulb className="mt-0.5 size-4 shrink-0" />
                  {res.aiError ? `AI explanation unavailable right now (${res.aiError}). The plan above is fully calculated from your data.` : "AI explanations are off (offline mode). The plan above is fully calculated from your data."}
                </p>
              )}
            </Card>

            <Button className="w-full" onClick={saveGoal} loading={saving}>
              <Save className="size-4" /> Save as goal
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}

function TotRow({ label, value, sub, warn }: { label: string; value: number; sub?: string; warn?: boolean }) {
  return (
    <tr className="border-t border-line first:border-t-0">
      <td className="py-2">
        {label}
        {sub && <span className={cn("block text-xs", warn ? "text-warn" : "text-muted")}>{sub}</span>}
      </td>
      <td className="py-2 text-right">{formatINR(value)}</td>
    </tr>
  );
}

function Mini({ label, value }: { label: string; value: number }) {
  return (
    <div className="rounded-xl bg-surface-2 px-2 py-2.5">
      <p className="text-xs text-muted">{label}</p>
      <p className="text-sm font-semibold tabular">{formatINR(value)}</p>
    </div>
  );
}

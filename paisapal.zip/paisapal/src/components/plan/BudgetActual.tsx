"use client";
import { AlertTriangle, PiggyBank } from "lucide-react";
import { budgetReport, formatINR, type BudgetRow } from "@/lib/finance";
import { categoryColor } from "@/components/charts";
import { Badge, Card, CardTitle, EmptyState, Progress, SourceTag, Stat, cn } from "@/components/ui";
import { BUDGET_STATE } from "./shared";

type Report = ReturnType<typeof budgetReport>;

function alertLines(rows: BudgetRow[], isCurrent: boolean): { text: string; tone: "warn" | "bad" }[] {
  const out: { text: string; tone: "warn" | "bad" }[] = [];
  const period = isCurrent ? "this month" : "that month";
  for (const r of rows) {
    if (r.state === "over") out.push({ text: `🚨 You went ${formatINR(r.spent - r.budget)} over your ${r.category.toLowerCase()} budget ${period}.`, tone: "bad" });
    else if (r.state === "near" && r.usedPct !== null) out.push({ text: `⚠️ You have used ${Math.round(r.usedPct)}% of your ${r.category.toLowerCase()} budget ${period}.`, tone: "warn" });
    else if (isCurrent && r.state === "under" && r.budget > 0 && r.projected > r.budget)
      out.push({ text: `📈 At this pace you'll spend about ${formatINR(r.projected)} on ${r.category.toLowerCase()} — ${formatINR(r.projected - r.budget)} more than planned.`, tone: "warn" });
  }
  return out;
}

export function BudgetActual({ report, isCurrent, isFuture, monthLabel }: { report: Report; isCurrent: boolean; isFuture: boolean; monthLabel: string }) {
  const alerts = isFuture ? [] : alertLines(report.rows, isCurrent);
  const savingsPct = report.savingsTarget ? Math.max(0, (report.saved / report.savingsTarget) * 100) : 0;

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <Stat label="Total budget" value={formatINR(report.totalBudget)} sub={report.hasBudget ? `${report.rows.filter((r) => r.state !== "unbudgeted").length} categories` : "Not set"} />
        <Stat label="Spent" value={formatINR(report.totalSpent)} sub={report.usedPct !== null ? `${Math.round(report.usedPct)}% of budget` : "Recorded"} tone={report.usedPct !== null && report.usedPct > 100 ? "bad" : undefined} />
        <Stat label="Remaining" value={formatINR(report.remaining)} tone={report.remaining < 0 ? "bad" : "good"} sub={report.remaining < 0 ? "Over budget" : "Left to spend"} />
        <Stat
          label="Saved vs target"
          value={formatINR(report.saved)}
          tone={report.saved < 0 ? "bad" : report.savingsTarget && report.saved >= report.savingsTarget ? "good" : undefined}
          sub={report.savingsTarget ? `Target ${formatINR(report.savingsTarget)}` : "No savings target"}
          icon={<PiggyBank className="size-4" />}
        />
      </div>

      {report.savingsTarget ? (
        <Card className="py-3 sm:py-4">
          <div className="mb-1.5 flex justify-between text-sm">
            <span className="text-ink-2">Savings target progress</span>
            <span className="tabular">
              {formatINR(Math.max(0, report.saved))} / {formatINR(report.savingsTarget)}
            </span>
          </div>
          <Progress value={savingsPct} tone={savingsPct >= 100 ? "good" : "brand"} label="Savings target progress" />
          <p className="mt-1.5 text-xs text-muted">Saved = money received − money spent in {monthLabel}.</p>
        </Card>
      ) : null}

      {alerts.length > 0 && (
        <Card className="space-y-1.5 py-3 sm:py-4">
          {alerts.map((a) => (
            <p key={a.text} className={cn("flex gap-2 text-sm", a.tone === "bad" ? "text-bad" : "text-warn")}>
              {a.text}
            </p>
          ))}
        </Card>
      )}

      <Card>
        <CardTitle hint={isCurrent ? "Projected = month-end spend if you keep today's daily pace." : undefined} action={<SourceTag kind="recorded" />}>
          Budget vs actual
        </CardTitle>
        {isFuture ? (
          <EmptyState title="Nothing spent yet">Plan this month above — progress shows up here once the month starts.</EmptyState>
        ) : report.rows.length === 0 ? (
          <EmptyState icon={<AlertTriangle className="size-8" />} title="No budget or spending for this month">
            Set a budget above, or record expenses to compare.
          </EmptyState>
        ) : (
          <ul className="space-y-4">
            {report.rows.map((r) => {
              const st = BUDGET_STATE[r.state];
              return (
                <li key={r.category}>
                  <div className="mb-1.5 flex items-center justify-between gap-2">
                    <span className="flex min-w-0 items-center gap-2 text-sm font-medium">
                      <span className="size-2.5 shrink-0 rounded-sm" style={{ background: categoryColor(r.category) }} />
                      <span className="truncate">{r.category}</span>
                    </span>
                    <Badge tone={st.tone}>{st.label}</Badge>
                  </div>
                  <Progress value={r.state === "unbudgeted" ? 100 : (r.usedPct ?? 0)} tone={st.bar} label={`${r.category} budget used`} className={r.state === "unbudgeted" ? "opacity-40" : undefined} />
                  <div className="mt-1 flex flex-wrap justify-between gap-x-3 text-xs text-muted">
                    <span className="tabular">
                      {formatINR(r.spent)} spent{r.budget > 0 && ` of ${formatINR(r.budget)}`}
                      {r.usedPct !== null && ` · ${Math.round(r.usedPct)}%`}
                    </span>
                    <span className="tabular">
                      {r.state === "unbudgeted" ? "No budget set" : r.remaining >= 0 ? `${formatINR(r.remaining)} left` : `${formatINR(-r.remaining)} over`}
                      {isCurrent && r.projected !== r.spent && ` · projected ${formatINR(r.projected)}`}
                    </span>
                  </div>
                </li>
              );
            })}
          </ul>
        )}
      </Card>
    </div>
  );
}

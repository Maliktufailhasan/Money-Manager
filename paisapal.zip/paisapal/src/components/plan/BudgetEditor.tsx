"use client";
import { Copy, Save, Sparkles, Undo2 } from "lucide-react";
import { useMemo, useState } from "react";
import { api, refreshAll } from "@/lib/client/api";
import { expenseCategories } from "@/lib/client/categories";
import { SAVINGS_BUDGET, addMonths, budgetsFor, formatINR, isoFromYM, rolloverBudget, round2, suggestBudget, sum, ym, type FinancialPosition } from "@/lib/finance";
import type { Snapshot } from "@/lib/types";
import { categoryColor } from "@/components/charts";
import { Badge, Button, Card, CardTitle, MoneyInput, SourceTag, cn, useToast } from "@/components/ui";
import { categoryAverages, recurringByCategory } from "./calc";
import { num, str } from "./shared";

type Draft = Record<string, string>;

function draftFrom(lines: { category: string; amount: number }[]): Draft {
  return Object.fromEntries(lines.map((l) => [l.category, str(l.amount)]));
}

/**
 * Editable budget for one month. Mount with `key={year-month}` so the draft
 * resets when switching months.
 */
export function BudgetEditor({ s, position, today, year, month }: { s: Snapshot; position: FinancialPosition; today: string; year: number; month: number }) {
  const toast = useToast();
  const saved = useMemo(() => budgetsFor(s.budgets, year, month), [s.budgets, year, month]);
  const [draft, setDraft] = useState<Draft>(() => draftFrom(saved));
  const [suggested, setSuggested] = useState(false);
  const [busy, setBusy] = useState(false);

  const { avg, monthsUsed } = useMemo(() => categoryAverages(s, today), [s, today]);
  const categories = useMemo(() => {
    const base = Object.keys(expenseCategories(s.categories));
    const extra = [...saved.map((b) => b.category), ...Object.keys(draft)].filter((c) => c !== SAVINGS_BUDGET && !base.includes(c));
    return [...base, ...Array.from(new Set(extra))];
  }, [s.categories, saved, draft]);

  const setOne = (cat: string, v: string) => setDraft((d) => ({ ...d, [cat]: v }));

  const incomeEstimate = Number(s.profile.monthly_income_estimate || 0);
  const income = incomeEstimate > 0 ? incomeEstimate : position.avgMonthlyIncome;
  const incomeBasis = incomeEstimate > 0 ? "your monthly income estimate (Settings)" : position.basis;
  const expenseTotal = round2(sum(categories.map((c) => num(draft[c]))));
  const savingsTarget = num(draft[SAVINGS_BUDGET]);
  const planned = round2(expenseTotal + savingsTarget);
  const unallocated = round2(income - planned);

  const savedDraft = draftFrom(saved);
  const keys = new Set([...Object.keys(savedDraft), ...Object.keys(draft)]);
  const dirty = [...keys].some((k) => num(savedDraft[k]) !== num(draft[k]));

  const prev = ym(addMonths(isoFromYM(year, month), -1));
  const copyLast = () => {
    const lines = rolloverBudget(s.budgets, prev.year, prev.month);
    if (!lines.length) return toast("No budget was set last month to copy.", "warn");
    setDraft(draftFrom(lines));
    setSuggested(false);
    toast("Copied last month's budget — review and save.", "info");
  };

  const suggest = () => {
    if (income <= 0) return toast("Add your monthly income in Settings (or record some income) so we can suggest a budget.", "warn");
    const rec = recurringByCategory(s);
    const discretionary = ["Food", "Travel", "Education", "Personal", "Social", "Technology", "Other"];
    // fixed costs: recurring bills, plus the usual spend in categories the suggestion doesn't size itself (e.g. Housing)
    const fixed = new Map(rec);
    for (const [cat, a] of avg) if (!discretionary.includes(cat)) fixed.set(cat, Math.max(fixed.get(cat) ?? 0, a));
    const lines = suggestBudget({
      income,
      typicalFood: avg.get("Food") || undefined,
      typicalTravel: avg.get("Travel") || undefined,
      recurring: [...fixed.entries()].filter(([, a]) => a > 0).map(([category, amount]) => ({ category, amount: Math.round(amount) })),
    });
    setDraft(draftFrom(lines));
    setSuggested(true);
  };

  const save = async () => {
    const lines = Object.entries(draft)
      .map(([category, v]) => ({ category, amount: round2(num(v)) }))
      .filter((l) => l.amount > 0);
    setBusy(true);
    try {
      await api("/api/budgets/bulk", { method: "PUT", json: { year, month, lines } });
      await refreshAll();
      setSuggested(false);
      toast(lines.length ? "Budget saved ✅" : "Budget cleared");
    } catch (e) {
      toast(e instanceof Error ? e.message : "Couldn't save the budget.", "bad");
    } finally {
      setBusy(false);
    }
  };

  return (
    <Card>
      <CardTitle
        hint={monthsUsed ? `Hints show your average spend over the last ${monthsUsed} month${monthsUsed > 1 ? "s" : ""}.` : "Record a few weeks of expenses to see your typical spend per category."}
        action={suggested ? <SourceTag kind="calculated" /> : undefined}
      >
        Plan your budget
      </CardTitle>

      <div className="mb-4 flex flex-wrap gap-2">
        <Button variant="secondary" size="sm" onClick={copyLast}>
          <Copy className="size-3.5" /> Copy last month
        </Button>
        <Button variant="soft" size="sm" onClick={suggest}>
          <Sparkles className="size-3.5" /> Suggest a budget
        </Button>
        {dirty && (
          <Button variant="ghost" size="sm" onClick={() => {
              setDraft(savedDraft);
              setSuggested(false);
            }}
          >
            <Undo2 className="size-3.5" /> Undo changes
          </Button>
        )}
      </div>
      {suggested && (
        <p className="mb-3 rounded-xl bg-brand-soft px-3 py-2 text-xs text-brand">
          Suggested from {formatINR(income)}/month income{avg.size ? " and your recent spending" : ""}. Leftover money goes to Savings. Adjust anything, then save.
        </p>
      )}

      <ul className="divide-y divide-line">
        {categories.map((c) => {
          const typical = avg.get(c);
          return (
            <li key={c} className="flex items-center gap-3 py-2">
              <span className="size-2.5 shrink-0 rounded-sm" style={{ background: categoryColor(c) }} />
              <div className="min-w-0 flex-1">
                <p className="truncate text-sm">{c}</p>
                {typical ? <p className="text-xs text-muted">usually {formatINR(typical)}/mo</p> : null}
              </div>
              <div className="w-32 shrink-0 sm:w-40">
                <MoneyInput aria-label={`${c} budget`} value={draft[c] ?? ""} onChange={(v) => setOne(c, v)} placeholder="0" />
              </div>
            </li>
          );
        })}
        <li className="flex items-center gap-3 py-2">
          <span className="size-2.5 shrink-0 rounded-sm" style={{ background: "var(--series-3)" }} />
          <div className="min-w-0 flex-1">
            <p className="text-sm font-medium">Savings target</p>
            <p className="text-xs text-muted">what you plan to keep this month</p>
          </div>
          <div className="w-32 shrink-0 sm:w-40">
            <MoneyInput aria-label="Savings target" value={draft[SAVINGS_BUDGET] ?? ""} onChange={(v) => setOne(SAVINGS_BUDGET, v)} placeholder="0" />
          </div>
        </li>
      </ul>

      <div className="mt-4 space-y-1.5 rounded-xl bg-surface-2 p-3 text-sm">
        <div className="flex justify-between gap-2">
          <span className="text-ink-2">Spending budget</span>
          <span className="tabular">{formatINR(expenseTotal)}</span>
        </div>
        <div className="flex justify-between gap-2">
          <span className="text-ink-2">+ Savings target</span>
          <span className="tabular">{formatINR(savingsTarget)}</span>
        </div>
        <div className="flex justify-between gap-2 border-t border-line pt-1.5 font-medium">
          <span>Planned total</span>
          <span className="tabular">{formatINR(planned)}</span>
        </div>
        <div className="flex justify-between gap-2">
          <span className="text-ink-2">
            Monthly income {position.isEstimate && incomeEstimate <= 0 && <Badge tone="warn">Estimate</Badge>}
          </span>
          <span className="tabular">{income > 0 ? formatINR(income) : "—"}</span>
        </div>
        <div className={cn("flex justify-between gap-2 font-semibold", unallocated < 0 ? "text-bad" : "text-good")}>
          <span>{unallocated < 0 ? "Over-planned by" : "Unallocated"}</span>
          <span className="tabular">{income > 0 ? formatINR(Math.abs(unallocated)) : "—"}</span>
        </div>
        <p className="pt-1 text-xs text-muted">
          {income > 0 ? `Income from ${incomeBasis}` : "No income known yet — set a monthly income estimate in Settings."}
          {income > 0 && unallocated > 0 && " Tip: move unallocated money into your savings target."}
        </p>
      </div>

      <div className="mt-4 flex justify-end">
        <Button onClick={save} loading={busy} disabled={!dirty}>
          <Save className="size-4" /> Save budget
        </Button>
      </div>
    </Card>
  );
}

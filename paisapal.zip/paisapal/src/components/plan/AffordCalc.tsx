"use client";
import { CheckCircle2, CircleAlert, XCircle } from "lucide-react";
import { useMemo, useState } from "react";
import { affordability, fmtDate, formatINR, type FinancialPosition } from "@/lib/finance";
import type { Snapshot } from "@/lib/types";
import { Badge, Card, CardTitle, Chip, Field, Input, MoneyInput, SourceTag, Stat, cn } from "@/components/ui";
import { trackedExtraIncome } from "./calc";
import { ScenarioBars, ScenarioCards } from "./ScenarioViews";
import { num, str } from "./shared";

export function AffordCalc({ s, position, today, balance }: { s: Snapshot; position: FinancialPosition; today: string; balance: number }) {
  const extraDefault = trackedExtraIncome(s);
  const [item, setItem] = useState("");
  const [price, setPrice] = useState("");
  const [current, setCurrent] = useState("0");
  const [income, setIncome] = useState(str(Math.round(position.avgMonthlyIncome)));
  const [expenses, setExpenses] = useState(str(Math.round(position.avgMonthlyExpense)));
  const [months, setMonths] = useState("6");
  const [cut, setCut] = useState(str(Math.round(position.reducibleMonthly * 0.3)));
  const [extra, setExtra] = useState(str(extraDefault));

  const result = useMemo(
    () =>
      num(price) > 0
        ? affordability(
            { price: num(price), currentMoney: num(current), monthlyIncome: num(income), monthlyExpenses: num(expenses), targetMonths: num(months) || null, reduction: num(cut), extraIncome: num(extra) },
            today,
          )
        : null,
    [price, current, income, expenses, months, cut, extra, today],
  );
  const tm = num(months) || null;
  const good = result && ["affordable_now", "on_track"].includes(result.verdict);
  const bad = result && result.verdict === "unrealistic";
  const VerdictIcon = good ? CheckCircle2 : bad ? XCircle : CircleAlert;

  return (
    <div className="grid gap-4 lg:grid-cols-[minmax(0,0.9fr)_minmax(0,1.1fr)] lg:items-start">
      <Card>
        <CardTitle hint="Change anything — results update instantly.">Can I afford it?</CardTitle>
        <div className="space-y-3">
          <div className="grid grid-cols-2 gap-3">
            <Field label="Item">{(id) => <Input id={id} value={item} onChange={(e) => setItem(e.target.value)} placeholder="e.g. Headphones" />}</Field>
            <Field label="Price">{(id) => <MoneyInput id={id} value={price} onChange={setPrice} placeholder="5000" />}</Field>
          </div>
          <Field label="Money already set aside for it" hint={balance > 0 ? undefined : "Your balance is ₹0 or below."}>
            {(id) => <MoneyInput id={id} value={current} onChange={setCurrent} />}
          </Field>
          {balance > 0 && (
            <Chip onClick={() => setCurrent(str(Math.round(balance)))} active={num(current) === Math.round(balance)}>
              Use my whole balance ({formatINR(balance)})
            </Chip>
          )}
          <div className="rounded-xl bg-surface-2 p-3">
            <div className="mb-2 flex flex-wrap items-center gap-1.5 text-xs text-muted">
              Prefilled from your data {position.isEstimate ? <SourceTag kind="estimate" /> : <SourceTag kind="calculated" />}
            </div>
            <div className="grid grid-cols-2 gap-3">
              <Field label="Monthly income">{(id) => <MoneyInput id={id} value={income} onChange={setIncome} />}</Field>
              <Field label="Monthly expenses">{(id) => <MoneyInput id={id} value={expenses} onChange={setExpenses} />}</Field>
            </div>
            <p className="mt-2 text-xs text-muted">{position.basis}</p>
          </div>
          <Field label="Target (months)">{(id) => <Input id={id} type="number" inputMode="numeric" min={1} max={120} value={months} onChange={(e) => setMonths(e.target.value)} />}</Field>
          <div className="flex flex-wrap gap-1.5">
            {[1, 3, 6, 12].map((m) => (
              <Chip key={m} active={num(months) === m} onClick={() => setMonths(String(m))}>
                {m} month{m > 1 ? "s" : ""}
              </Chip>
            ))}
          </div>
          <div className="grid grid-cols-2 gap-3">
            <Field label="Spending cut / month" hint={position.reducibleMonthly > 0 ? `30% of ~${formatINR(position.reducibleMonthly)} non-essential` : "No non-essential spend recorded"}>
              {(id) => <MoneyInput id={id} value={cut} onChange={setCut} />}
            </Field>
            <Field label="Extra income / month" hint={<span className="text-warn">Assumption — not guaranteed</span>}>
              {(id) => <MoneyInput id={id} value={extra} onChange={setExtra} />}
            </Field>
          </div>
          {extraDefault > 0 && <p className="text-xs text-muted">Extra income prefilled from your Earn tracker ({formatINR(extraDefault)}/month expected).</p>}
        </div>
      </Card>

      {!result ? (
        <Card className="flex min-h-48 items-center justify-center text-center text-sm text-muted">Enter a price to see whether — and when — you can afford it.</Card>
      ) : (
        <div className="space-y-4">
          <Card className={cn(good ? "border-good/40" : bad ? "border-bad/40" : "border-warn/40")}>
            <div className="flex items-start gap-3">
              <VerdictIcon className={cn("mt-0.5 size-6 shrink-0", good ? "text-good" : bad ? "text-bad" : "text-warn")} />
              <div>
                <p className="font-semibold">{item.trim() ? `${item.trim()} · ${formatINR(num(price))}` : formatINR(num(price))}</p>
                <p className="text-sm text-ink-2">{result.verdictText}</p>
                <div className="mt-1 flex gap-1.5">
                  <SourceTag kind="calculated" />
                  {position.isEstimate && <Badge tone="warn">Estimate</Badge>}
                </div>
              </div>
            </div>
          </Card>
          <div className="grid grid-cols-2 gap-3">
            <Stat label="Still needed" value={formatINR(result.required)} sub={`${formatINR(num(price))} − ${formatINR(num(current))}`} />
            <Stat label="You save now" value={formatINR(result.currentMonthlySaving)} sub="per month (income − expenses)" tone={result.currentMonthlySaving < 0 ? "bad" : undefined} />
          </div>
          {result.monthlyNeeded !== null && !result.alreadyAffordable && (
            <Card>
              <CardTitle hint={tm ? `To buy it within ${tm} month${tm > 1 ? "s" : ""}` : undefined}>Savings required</CardTitle>
              <div className="grid grid-cols-3 gap-2 text-center">
                {[
                  ["Monthly", result.monthlyNeeded],
                  ["Weekly", result.weeklyNeeded],
                  ["Daily", result.dailyNeeded],
                ].map(([l, v]) => (
                  <div key={String(l)} className="rounded-xl bg-surface-2 px-2 py-3">
                    <p className="text-xs text-muted">{l}</p>
                    <p className="font-semibold tabular">{formatINR(Number(v))}</p>
                  </div>
                ))}
              </div>
              {result.scenarios[0].date && <p className="mt-3 text-sm text-ink-2">Estimated purchase date at your current saving rate: <span className="font-medium">{fmtDate(result.scenarios[0].date, { year: true })}</span></p>}
            </Card>
          )}
          {!result.alreadyAffordable && (
            <>
              <ScenarioCards scenarios={result.scenarios} />
              <Card>
                <CardTitle>Time to buy it</CardTitle>
                <ScenarioBars scenarios={result.scenarios} targetMonths={tm} />
              </Card>
            </>
          )}
        </div>
      )}
    </div>
  );
}

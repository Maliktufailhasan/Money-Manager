import type { BudgetState, GoalStatus } from "@/lib/finance";
import type { Goal } from "@/lib/types";

/** Parse a numeric text input; empty or invalid input becomes 0. */
export function num(s: string | null | undefined): number {
  const n = parseFloat(String(s ?? "").replace(/,/g, ""));
  return Number.isFinite(n) ? n : 0;
}

/** Format a number for a MoneyInput value (no thousands separators). */
export function str(n: number | null | undefined): string {
  if (n === null || n === undefined || !Number.isFinite(n)) return "";
  return String(Math.round(n * 100) / 100);
}

type Tone = "neutral" | "good" | "warn" | "bad" | "brand";

export const GOAL_STATUS: Record<GoalStatus, { label: string; tone: Tone }> = {
  completed: { label: "Completed", tone: "good" },
  on_track: { label: "On track", tone: "good" },
  behind: { label: "Behind", tone: "warn" },
  overdue: { label: "Overdue", tone: "bad" },
  no_deadline: { label: "No deadline", tone: "neutral" },
  paused: { label: "Paused", tone: "neutral" },
};

export const PRIORITY: Record<Goal["priority"], { label: string; tone: Tone }> = {
  high: { label: "High priority", tone: "bad" },
  medium: { label: "Medium priority", tone: "warn" },
  low: { label: "Low priority", tone: "neutral" },
};

export const BUDGET_STATE: Record<BudgetState, { label: string; tone: Tone; bar: "good" | "warn" | "bad" | "brand" }> = {
  under: { label: "Under budget", tone: "good", bar: "good" },
  near: { label: "Near limit", tone: "warn", bar: "warn" },
  over: { label: "Over budget", tone: "bad", bar: "bad" },
  unbudgeted: { label: "Unbudgeted", tone: "neutral", bar: "brand" },
};

/** Human "x months" label for fractional months. */
export function monthsLabel(m: number | null): string {
  if (m === null) return "Never at this rate";
  if (m === 0) return "Now";
  if (m < 1) return `~${Math.max(1, Math.round(m * 30.4375))} days`;
  const r = Math.round(m * 10) / 10;
  return `${r} month${r === 1 ? "" : "s"}`;
}

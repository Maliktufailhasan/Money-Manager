"use client";
import { useState } from "react";
import { db } from "@/lib/client/api";
import { formatINR } from "@/lib/finance";
import type { Goal } from "@/lib/types";
import { Button, Chip, Field, Input, MoneyInput, Modal, useToast } from "@/components/ui";
import { num } from "./shared";

/** Add money to / withdraw money from a goal. Mount only while open. */
export function ContributionModal({ goal, mode, today, onClose }: { goal: Goal; mode: "add" | "withdraw"; today: string; onClose: () => void }) {
  const toast = useToast();
  const [amount, setAmount] = useState("");
  const [date, setDate] = useState(today);
  const [note, setNote] = useState("");
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const remaining = Math.max(0, goal.target_amount - goal.current_amount);
  const withdraw = mode === "withdraw";

  const quick = withdraw ? [goal.current_amount] : [100, 500, 1000, remaining].filter((v, i, a) => v > 0 && a.indexOf(v) === i);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    const a = num(amount);
    if (a <= 0) return setError("Enter an amount above ₹0.");
    if (withdraw && a > goal.current_amount) return setError(`You can withdraw at most ${formatINR(goal.current_amount)} — that's all that's saved in this goal.`);
    if (date > today) return setError("The date can't be in the future.");
    setError(null);
    setSaving(true);
    try {
      await db.create("contributions", { goal_id: goal.id, amount: withdraw ? -a : a, date, note: note.trim() || null });
      if (!withdraw && goal.current_amount + a >= goal.target_amount) toast(`🎉 ${goal.name} is fully funded!`);
      else toast(withdraw ? `Withdrew ${formatINR(a)} from ${goal.name}` : `Added ${formatINR(a)} to ${goal.name}`);
      onClose();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Couldn't save.");
    } finally {
      setSaving(false);
    }
  };

  return (
    <Modal
      open
      onClose={onClose}
      title={withdraw ? `Withdraw from ${goal.name}` : `Add money to ${goal.name}`}
      footer={
        <>
          <Button variant="ghost" type="button" onClick={onClose}>
            Cancel
          </Button>
          <Button type="submit" form="contrib-form" loading={saving} variant={withdraw ? "danger" : "primary"}>
            {withdraw ? "Withdraw" : "Add money"}
          </Button>
        </>
      }
    >
      <form id="contrib-form" onSubmit={submit} className="space-y-4">
        <p className="text-sm text-muted">
          Saved <span className="tabular font-medium text-ink">{formatINR(goal.current_amount)}</span> of {formatINR(goal.target_amount)}
          {!withdraw && remaining > 0 && <> · {formatINR(remaining)} to go</>}
        </p>
        <Field label="Amount">{(id) => <MoneyInput id={id} value={amount} onChange={setAmount} placeholder="0" autoFocus />}</Field>
        {quick.length > 0 && (
          <div className="flex flex-wrap gap-1.5">
            {quick.map((q, i) => (
              <Chip key={q} active={num(amount) === q} onClick={() => setAmount(String(q))}>
                {withdraw ? `All (${formatINR(q)})` : i === quick.length - 1 && q === remaining && remaining > 0 ? `Remaining ${formatINR(q)}` : formatINR(q)}
              </Chip>
            ))}
          </div>
        )}
        <div className="grid grid-cols-2 gap-3">
          <Field label="Date">{(id) => <Input id={id} type="date" value={date} max={today} onChange={(e) => setDate(e.target.value)} />}</Field>
          <Field label="Note" hint="Optional">
            {(id) => <Input id={id} value={note} onChange={(e) => setNote(e.target.value)} maxLength={200} placeholder={withdraw ? "Why?" : "e.g. from pocket money"} />}
          </Field>
        </div>
        <p className="text-xs text-muted">This moves money into a goal bucket — it doesn&apos;t change your balance. Your balance only changes when you record income or expenses.</p>
        {error && <p className="text-sm text-bad">{error}</p>}
      </form>
    </Modal>
  );
}

"use client";
import { fmtDate, formatINR, type Scenario } from "@/lib/finance";
import { Badge, cn } from "@/components/ui";
import { monthsLabel } from "./shared";

const LETTER: Record<Scenario["key"], string> = { current: "A", reduce: "B", income: "C", combined: "D" };

export function ScenarioCards({ scenarios, lettered }: { scenarios: Scenario[]; lettered?: boolean }) {
  return (
    <div className="grid gap-3 sm:grid-cols-2">
      {scenarios.map((sc) => (
        <div key={sc.key} className={cn("rounded-2xl border p-3.5", sc.meetsTarget ? "border-good/40 bg-good-soft/40" : "border-line bg-surface")}>
          <div className="mb-1 flex items-start justify-between gap-2">
            <p className="text-sm font-semibold">
              {lettered && <span className="mr-1 text-muted">{LETTER[sc.key]}.</span>}
              {sc.name}
            </p>
            <div className="flex flex-wrap justify-end gap-1">
              {sc.speculative && <Badge tone="warn">Not guaranteed</Badge>}
              {sc.meetsTarget === true && <Badge tone="good">Meets target</Badge>}
              {sc.meetsTarget === false && <Badge tone="bad">Misses target</Badge>}
            </div>
          </div>
          <p className="text-xs text-muted">{sc.description}</p>
          <div className="mt-2 flex items-end justify-between gap-2">
            <div>
              <p className="text-lg font-semibold tabular">{monthsLabel(sc.months)}</p>
              <p className="text-xs text-muted">{sc.date ? `around ${fmtDate(sc.date, { year: true })}` : "you're not saving at this rate"}</p>
            </div>
            <p className="text-right text-xs text-muted">
              saving
              <br />
              <span className="tabular text-sm font-medium text-ink">{formatINR(sc.monthlySaving)}/mo</span>
            </p>
          </div>
        </div>
      ))}
    </div>
  );
}

/** Horizontal bars: time to goal under each scenario (shorter is better). */
export function ScenarioBars({ scenarios, targetMonths }: { scenarios: Scenario[]; targetMonths: number | null }) {
  const finite = scenarios.map((s) => s.months).filter((m): m is number => m !== null);
  const max = Math.max(targetMonths ?? 0, ...finite, 1);
  const colors: Record<Scenario["key"], string> = { current: "var(--series-1)", reduce: "var(--series-3)", income: "var(--series-5)", combined: "var(--series-6)" };
  return (
    <div className="space-y-3">
      <ul className="space-y-2.5">
        {scenarios.map((sc) => (
          <li key={sc.key}>
            <div className="mb-1 flex justify-between gap-2 text-sm">
              <span className="truncate text-ink-2">
                {LETTER[sc.key]}. {sc.name}
                {sc.speculative && <span className="ml-1 text-xs text-warn">*</span>}
              </span>
              <span className="tabular shrink-0 font-medium">{monthsLabel(sc.months)}</span>
            </div>
            <div className="relative h-3 rounded-full bg-surface-2">
              {sc.months !== null && <div className="h-full rounded-full" style={{ width: `${Math.max(2, (sc.months / max) * 100)}%`, background: colors[sc.key] }} />}
              {targetMonths ? <div className="absolute inset-y-[-3px] w-0.5 rounded bg-ink" style={{ left: `${Math.min(100, (targetMonths / max) * 100)}%` }} aria-hidden /> : null}
            </div>
          </li>
        ))}
      </ul>
      <p className="text-xs text-muted">
        {targetMonths ? `Black line = your target (${monthsLabel(targetMonths)}). ` : ""}Shorter bar = you reach the goal sooner. * relies on extra income that isn&apos;t guaranteed.
      </p>
    </div>
  );
}

"use client";
import { useState, type ReactNode } from "react";
import type { Goal } from "@/lib/types";
import { ContributionModal } from "./ContributionModal";
import { GoalFormModal, type GoalPreset } from "./GoalFormModal";

/** Shared create/edit/add-money/withdraw modals for goal screens. */
export function useGoalModals(today: string): {
  newGoal: (preset?: GoalPreset) => void;
  editGoal: (g: Goal) => void;
  addMoney: (g: Goal) => void;
  withdraw: (g: Goal) => void;
  modals: ReactNode;
} {
  const [form, setForm] = useState<{ goal?: Goal; preset?: GoalPreset; n: number } | null>(null);
  const [contrib, setContrib] = useState<{ goal: Goal; mode: "add" | "withdraw" } | null>(null);
  const modals = (
    <>
      {form && <GoalFormModal key={form.n} goal={form.goal} preset={form.preset} today={today} onClose={() => setForm(null)} />}
      {contrib && <ContributionModal key={`${contrib.goal.id}-${contrib.mode}`} goal={contrib.goal} mode={contrib.mode} today={today} onClose={() => setContrib(null)} />}
    </>
  );
  return {
    newGoal: (preset) => setForm({ preset, n: Date.now() }),
    editGoal: (goal) => setForm({ goal, n: Date.now() }),
    addMoney: (goal) => setContrib({ goal, mode: "add" }),
    withdraw: (goal) => setContrib({ goal, mode: "withdraw" }),
    modals,
  };
}

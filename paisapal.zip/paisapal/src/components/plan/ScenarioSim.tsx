"use client";
import { useMemo, useState } from "react";
import { affordability, formatINR, monthsBetween, type FinancialPosition } from "@/lib/finance";
import type { Snapshot } from "@/lib/types";
import { Badge, Card, CardTitle, Field, Input, MoneyInput, Select, SourceTag } from "@/components/ui";
import { trackedExtraIncome } from "./calc";
import { ScenarioBars, ScenarioCards } from "./ScenarioViews";
import { num, str } from "./shared";

export function ScenarioSim({ s, position, today }: { s: Snapshot; position: FinancialPosition; today: string }) {
  const goals = s.goals.filter((g) => g.status !== "completed" && g.target_amount > g.current_amount);
  const [goalId, setGoalId] = useState<string>(goals[0]?.id ?? "custom");
  const [amount, setAmount] = useState("");
  const [date, setDate] = useState("");
  const [cutPct, setCutPct] = useState(30);
  const [extra, setExtra] = useState(() => {
    const tracked = trackedExtraIncome(s);
    return tracked > 0 ? str(tracked) : "2000";
  });

  const goal = goals.find((g) => g.id === goalId);
  const price = goal ? goal.target_amount : num(amount);
  const saved = goal ? goal.current_amount : 0;
  const targetDate = goal ? goal.target_date : date || null;
  const targetMonths = targetDate && targetDate > today ? Math.round(monthsBetween(today, targetDate) * 10) / 10 : null;
  const reduction = Math.round((position.reducibleMonthly * cutPct) / 100);

  const result = useMemo(
    () =>
      price > 0
        ? affordability({ price, currentMoney: saved, monthlyIncome: position.avgMonthlyIncome, monthlyExpenses: position.avgMonthlyExpense, targetMonths, reduction, extraIncome: num(extra) }, today)
        : null,
    [price, saved, position.avgMonthlyIncome, position.avgMonthlyExpense, targetMonths, reduction, extra, today],
  );
  const scenarios = result?.scenarios.map((sc) => (sc.key === "current" ? { ...sc, name: "Current lifestyle" } : sc.key === "reduce" ? { ...sc, name: "Reduce spending" } : sc.key === "income" ? { ...sc, name: "Increase income" } : sc));

  return (
    <div className="grid gap-4 lg:grid-cols-[minmax(0,0.8fr)_minmax(0,1.2fr)] lg:items-start">
      <Card>
        <CardTitle hint="Compare how fast you reach a goal under four lifestyles.">Scenario simulator</CardTitle>
        <div className="space-y-3">
          <Field label="Goal">
            {(id) => (
              <Select id={id} value={goalId} onChange={(e) => setGoalId(e.target.value)}>
                {goals.map((g) => (
                  <option key={g.id} value={g.id}>
                    {g.name} ({formatINR(g.target_amount - g.current_amount)} left)
                  </option>
                ))}
                <option value="custom">Custom amount…</option>
              </Select>
            )}
          </Field>
          {!goal && (
            <div className="grid grid-cols-2 gap-3">
              <Field label="Amount needed">{(id) => <MoneyInput id={id} value={amount} onChange={setAmount} placeholder="20000" />}</Field>
              <Field label="Target date" hint="Optional">
                {(id) => <Input id={id} type="date" min={today} value={date} onChange={(e) => setDate(e.target.value)} />}
              </Field>
            </div>
          )}
          <div className="rounded-xl bg-surface-2 p-3 text-xs text-ink-2">
            <div className="mb-1 flex items-center gap-1.5">
              Your averages {position.isEstimate ? <SourceTag kind="estimate" /> : <SourceTag kind="calculated" />}
            </div>
            Income {formatINR(position.avgMonthlyIncome)}/mo · Expenses {formatINR(position.avgMonthlyExpense)}/mo · Non-essential {formatINR(position.reducibleMonthly)}/mo
            <p className="mt-1 text-muted">{position.basis}</p>
          </div>
          <Field label={`B · Cut non-essential spending by ${cutPct}%`} hint={position.reducibleMonthly > 0 ? `= ${formatINR(reduction)}/month less spending` : "No non-essential spending recorded yet, so cuts add nothing."}>
            {(id) => <input id={id} type="range" min={0} max={100} step={5} value={cutPct} onChange={(e) => setCutPct(Number(e.target.value))} className="w-full accent-brand" />}
          </Field>
          <Field label="C · Extra income per month" hint={<span className="text-warn">Assumption — not guaranteed</span>}>
            {(id) => <MoneyInput id={id} value={extra} onChange={setExtra} />}
          </Field>
        </div>
      </Card>

      {!result || !scenarios ? (
        <Card className="flex min-h-48 items-center justify-center text-center text-sm text-muted">{goals.length ? "Pick a goal to compare scenarios." : "Enter an amount to compare scenarios — or create a goal first."}</Card>
      ) : (
        <div className="space-y-4">
          <Card>
            <CardTitle hint={`${formatINR(result.required)} still needed${targetMonths ? ` · target in ${targetMonths} months` : ""}`} action={<Badge tone="brand">Time to goal</Badge>}>
              Comparison
            </CardTitle>
            <ScenarioBars scenarios={scenarios} targetMonths={targetMonths} />
          </Card>
          <ScenarioCards scenarios={scenarios} lettered />
        </div>
      )}
    </div>
  );
}

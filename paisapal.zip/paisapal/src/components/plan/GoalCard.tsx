"use client";
import { CalendarClock, CheckCircle2, ChevronDown, ChevronUp, Minus, Pause, Pencil, Play, Plus, Trash2, Wand2 } from "lucide-react";
import Link from "next/link";
import { useState } from "react";
import { db } from "@/lib/client/api";
import { fmtDate, formatINR, type GoalMetrics } from "@/lib/finance";
import type { GoalContribution } from "@/lib/types";
import { Badge, Button, Card, IconButton, Progress, confirmAction, cn, useToast } from "@/components/ui";
import { GOAL_STATUS, PRIORITY, monthsLabel } from "./shared";

export function plannerHref(m: GoalMetrics): string {
  const months = m.monthsLeft && m.monthsLeft >= 1 ? Math.ceil(m.monthsLeft) : 6;
  const q = new URLSearchParams({ item: m.goal.name, price: String(m.goal.target_amount), months: String(months), start: String(m.goal.current_amount) });
  return `/planner?${q.toString()}`;
}

export function GoalCard({
  m,
  contributions,
  onAdd,
  onWithdraw,
  onEdit,
}: {
  m: GoalMetrics;
  contributions: GoalContribution[];
  onAdd: () => void;
  onWithdraw: () => void;
  onEdit: () => void;
}) {
  const toast = useToast();
  const [open, setOpen] = useState(false);
  const [busy, setBusy] = useState<string | null>(null);
  const g = m.goal;
  const st = GOAL_STATUS[m.status];
  const pr = PRIORITY[g.priority];
  const history = contributions.filter((c) => c.goal_id === g.id).sort((a, b) => (b.date === a.date ? b.created_at.localeCompare(a.created_at) : b.date.localeCompare(a.date)));
  const done = m.status === "completed";

  const run = async (key: string, fn: () => Promise<unknown>, msg: string) => {
    setBusy(key);
    try {
      await fn();
      toast(msg);
    } catch (e) {
      toast(e instanceof Error ? e.message : "Something went wrong", "bad");
    } finally {
      setBusy(null);
    }
  };

  const remove = () => {
    if (!confirmAction(`Delete "${g.name}"? Its contribution history will be removed too. This can't be undone.`)) return;
    void run("delete", () => db.remove("goals", g.id), "Goal deleted");
  };

  return (
    <Card className={cn("flex flex-col gap-3", g.status === "paused" && "opacity-80")}>
      <div className="flex items-start justify-between gap-2">
        <div className="min-w-0">
          <h3 className="truncate font-semibold">{g.name}</h3>
          <p className="text-xs text-muted">
            {g.category}
            {g.is_emergency && " · Emergency fund"}
          </p>
        </div>
        <IconButton label="Edit goal" onClick={onEdit}>
          <Pencil className="size-4" />
        </IconButton>
      </div>

      <div className="flex flex-wrap gap-1.5">
        <Badge tone={st.tone}>{st.label}</Badge>
        <Badge tone={pr.tone}>{pr.label}</Badge>
      </div>

      <div>
        <div className="mb-1.5 flex items-end justify-between gap-2">
          <span className="text-lg font-semibold tabular">{formatINR(g.current_amount)}</span>
          <span className="text-sm text-muted tabular">
            of {formatINR(g.target_amount)} · {Math.round(m.progressPct)}%
          </span>
        </div>
        <Progress value={m.progressPct} tone={done ? "good" : m.status === "behind" || m.status === "overdue" ? "warn" : "brand"} label={`${g.name} progress`} />
      </div>

      <dl className="grid grid-cols-2 gap-x-3 gap-y-2 text-sm">
        <div>
          <dt className="text-xs text-muted">Remaining</dt>
          <dd className="tabular font-medium">{formatINR(m.remaining)}</dd>
        </div>
        <div>
          <dt className="text-xs text-muted">Target date</dt>
          <dd className="font-medium">
            {g.target_date ? fmtDate(g.target_date, { year: true }) : "Not set"}
            {m.daysLeft !== null && m.daysLeft >= 0 && !done && <span className="ml-1 text-xs font-normal text-muted">({m.daysLeft}d left)</span>}
          </dd>
        </div>
        {m.requiredMonthly !== null && !done && (
          <div className="col-span-2 rounded-xl bg-surface-2 px-3 py-2">
            <dt className="text-xs text-muted">Required saving</dt>
            <dd className="tabular">
              <span className="font-semibold">{formatINR(m.requiredMonthly)}/month</span>
              <span className="text-xs text-muted">
                {" "}
                · {formatINR(m.requiredWeekly)}/week · {formatINR(m.requiredDaily)}/day
              </span>
            </dd>
          </div>
        )}
        {!done && (
          <div className="col-span-2 flex items-start gap-1.5 text-xs text-muted">
            <CalendarClock className="mt-0.5 size-3.5 shrink-0" />
            {m.etaDate && m.etaMonths !== null ? (
              <span>
                ETA {fmtDate(m.etaDate, { year: true })} ({monthsLabel(m.etaMonths)}) — based on your {m.etaBasis === "goal pace" ? `recent pace of ${formatINR(m.recentPace)}/month into this goal` : "free monthly saving capacity"}.
              </span>
            ) : (
              <span>No ETA yet — add money to this goal to see when you&apos;ll get there.</span>
            )}
          </div>
        )}
      </dl>

      {g.notes && <p className="text-xs text-ink-2">{g.notes}</p>}

      <div className="mt-auto flex flex-wrap gap-2">
        {!done && (
          <Button size="sm" onClick={onAdd} disabled={g.status === "paused"}>
            <Plus className="size-3.5" /> Add money
          </Button>
        )}
        <Button size="sm" variant="secondary" onClick={onWithdraw} disabled={g.current_amount <= 0}>
          <Minus className="size-3.5" /> Withdraw
        </Button>
        {!done && (
          <Link href={plannerHref(m)} className="inline-flex h-8 items-center gap-1.5 rounded-xl bg-brand-soft px-3 text-xs font-medium text-brand hover:opacity-90">
            <Wand2 className="size-3.5" /> Plan this goal
          </Link>
        )}
      </div>

      <div className="flex flex-wrap items-center gap-1 border-t border-line pt-2">
        {g.status !== "completed" &&
          (g.status === "paused" ? (
            <Button size="sm" variant="ghost" loading={busy === "status"} onClick={() => run("status", () => db.update("goals", g.id, { status: "active" }), "Goal resumed")}>
              <Play className="size-3.5" /> Resume
            </Button>
          ) : (
            <Button size="sm" variant="ghost" loading={busy === "status"} onClick={() => run("status", () => db.update("goals", g.id, { status: "paused" }), "Goal paused")}>
              <Pause className="size-3.5" /> Pause
            </Button>
          ))}
        {g.status === "completed" ? (
          <Button size="sm" variant="ghost" loading={busy === "done"} onClick={() => run("done", () => db.update("goals", g.id, { status: "active" }), "Goal reopened")}>
            <Play className="size-3.5" /> Reopen
          </Button>
        ) : (
          <Button size="sm" variant="ghost" loading={busy === "done"} onClick={() => run("done", () => db.update("goals", g.id, { status: "completed" }), "🎉 Goal marked complete")}>
            <CheckCircle2 className="size-3.5" /> Complete
          </Button>
        )}
        <Button size="sm" variant="ghost" className="text-bad" loading={busy === "delete"} onClick={remove}>
          <Trash2 className="size-3.5" /> Delete
        </Button>
        <button type="button" onClick={() => setOpen((o) => !o)} className="ml-auto inline-flex items-center gap-1 rounded-lg px-2 py-1 text-xs text-ink-2 hover:bg-surface-2" aria-expanded={open}>
          History ({history.length}) {open ? <ChevronUp className="size-3.5" /> : <ChevronDown className="size-3.5" />}
        </button>
      </div>

      {open && (
        <ul className="max-h-56 space-y-1 overflow-y-auto text-sm">
          {history.length === 0 && <li className="text-xs text-muted">No money added yet.</li>}
          {history.map((c) => (
            <li key={c.id} className="flex items-center justify-between gap-2 rounded-lg px-2 py-1 odd:bg-surface-2">
              <span className="min-w-0">
                <span className="text-xs text-muted">{fmtDate(c.date, { year: true })}</span>
                {c.note && <span className="ml-2 truncate text-xs text-ink-2">{c.note}</span>}
              </span>
              <span className={cn("tabular shrink-0 font-medium", c.amount < 0 ? "text-bad" : "text-good")}>{formatINR(c.amount, { sign: true })}</span>
            </li>
          ))}
        </ul>
      )}
    </Card>
  );
}

"use client";
import { Bell, LogOut, Plus, Wallet } from "lucide-react";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { createContext, useCallback, useContext, useEffect, useState, type ReactNode } from "react";
import { supabaseBrowser } from "@/lib/supabase/client";
import { useFinance } from "@/lib/client/useFinance";
import type { Transaction, TxType } from "@/lib/types";
import { BOTTOM_NAV, NAV } from "./nav";
import { ThemeToggle } from "./ThemeToggle";
import { draftFrom, TransactionForm, type TxDraft } from "./TransactionForm";
import { Modal, ToastProvider, cn } from "./ui";

interface QuickAddApi {
  /** open the add form; pass a transaction to edit it, or `duplicate` to copy it as new */
  open: (opts?: { type?: TxType; edit?: Transaction; duplicate?: Transaction; preset?: Partial<Transaction> }) => void;
}
const QuickAddCtx = createContext<QuickAddApi>({ open: () => {} });
export const useQuickAdd = () => useContext(QuickAddCtx);

function isActive(pathname: string, href: string) {
  return href === "/" ? pathname === "/" : pathname === href || pathname.startsWith(`${href}/`);
}

export function AppShell({ children }: { children: ReactNode }) {
  const pathname = usePathname();
  const router = useRouter();
  const { data } = useFinance();
  const [modal, setModal] = useState<{ draft: TxDraft; editId?: string; title: string } | null>(null);

  // first-time users go through onboarding (skippable)
  useEffect(() => {
    if (data && !data.s.profile.onboarded && data.s.totals.tx_count === 0 && pathname !== "/onboarding") {
      try {
        if (sessionStorage.getItem("pp-skip-onboarding")) return;
      } catch {}
      router.replace("/onboarding");
    }
  }, [data, pathname, router]);

  const open = useCallback<QuickAddApi["open"]>((opts = {}) => {
    if (opts.edit) setModal({ draft: draftFrom(opts.edit), editId: opts.edit.id, title: "Edit transaction" });
    else if (opts.duplicate) setModal({ draft: draftFrom(opts.duplicate, opts.duplicate.type, false), title: "Duplicate transaction" });
    else setModal({ draft: draftFrom(opts.preset ?? null, opts.type ?? "expense"), title: opts.type === "income" ? "Add money received" : "Add expense" });
  }, []);

  async function signOut() {
    await supabaseBrowser().auth.signOut();
    router.replace("/login");
    router.refresh();
  }

  const alertCount = data?.alerts.filter((a) => a.level !== "info").length ?? 0;

  return (
    <ToastProvider>
      <QuickAddCtx.Provider value={{ open }}>
        <div className="min-h-dvh lg:pl-60">
          {/* desktop sidebar */}
          <aside className="fixed inset-y-0 left-0 z-30 hidden w-60 flex-col border-r border-line bg-surface lg:flex">
            <Link href="/" className="flex items-center gap-2 px-5 py-5 font-semibold">
              <span className="flex size-8 items-center justify-center rounded-xl bg-brand text-brand-ink">
                <Wallet className="size-4" />
              </span>
              PaisaPal
            </Link>
            <nav className="flex-1 space-y-0.5 overflow-y-auto px-3 pb-3" aria-label="Main">
              {NAV.map(({ href, label, icon: Icon }) => (
                <Link
                  key={href}
                  href={href}
                  className={cn("flex items-center gap-2.5 rounded-xl px-3 py-2 text-sm transition-colors", isActive(pathname, href) ? "bg-brand-soft font-medium text-brand" : "text-ink-2 hover:bg-surface-2 hover:text-ink")}
                  aria-current={isActive(pathname, href) ? "page" : undefined}
                >
                  <Icon className="size-4" />
                  <span className="flex-1">{label}</span>
                  {href === "/alerts" && alertCount > 0 && <span className="rounded-full bg-bad px-1.5 text-[10px] font-semibold text-white">{alertCount}</span>}
                </Link>
              ))}
            </nav>
            <div className="space-y-3 border-t border-line p-3">
              <ThemeToggle />
              <button onClick={signOut} className="flex w-full items-center gap-2 rounded-xl px-3 py-2 text-sm text-ink-2 hover:bg-surface-2">
                <LogOut className="size-4" /> Log out
              </button>
            </div>
          </aside>

          {/* mobile top bar */}
          <header className="sticky top-0 z-20 flex items-center justify-between border-b border-line bg-bg/85 px-4 py-3 backdrop-blur lg:hidden">
            <Link href="/" className="flex items-center gap-2 font-semibold">
              <span className="flex size-7 items-center justify-center rounded-lg bg-brand text-brand-ink">
                <Wallet className="size-3.5" />
              </span>
              PaisaPal
            </Link>
            <Link href="/alerts" className="relative rounded-lg p-1.5 text-ink-2" aria-label={`Alerts${alertCount ? ` (${alertCount})` : ""}`}>
              <Bell className="size-5" />
              {alertCount > 0 && <span className="absolute -right-0.5 -top-0.5 rounded-full bg-bad px-1 text-[10px] font-semibold text-white">{alertCount}</span>}
            </Link>
          </header>

          <main className="mx-auto w-full max-w-6xl px-4 pt-5 pb-28 sm:px-6 lg:px-8 lg:pt-8 lg:pb-12">{children}</main>

          {/* floating + Expense */}
          <button
            onClick={() => open({ type: "expense" })}
            className="fixed right-4 bottom-20 z-30 flex h-14 items-center gap-2 rounded-full bg-brand px-5 font-semibold text-brand-ink shadow-lg shadow-brand/30 transition-transform hover:scale-[1.03] active:scale-95 lg:right-8 lg:bottom-8"
            aria-label="Add expense"
          >
            <Plus className="size-5" /> Expense
          </button>

          {/* mobile bottom nav */}
          <nav className="fixed inset-x-0 bottom-0 z-30 grid grid-cols-5 border-t border-line bg-surface pb-[env(safe-area-inset-bottom)] lg:hidden" aria-label="Bottom">
            {BOTTOM_NAV.map(({ href, label, icon: Icon }) => {
              const active = href === "/more" ? !BOTTOM_NAV.some((b) => b.href !== "/more" && isActive(pathname, b.href)) : isActive(pathname, href);
              return (
                <Link key={href} href={href} className={cn("flex flex-col items-center gap-0.5 py-2 text-[11px]", active ? "text-brand" : "text-muted")} aria-current={active ? "page" : undefined}>
                  <Icon className="size-5" />
                  {label}
                </Link>
              );
            })}
          </nav>
        </div>

        <Modal open={!!modal} onClose={() => setModal(null)} title={modal?.title ?? ""}>
          {modal && data && <TransactionForm key={modal.title + (modal.editId ?? "")} snapshot={data.s} initial={modal.draft} editId={modal.editId} compact onDone={() => setModal(null)} />}
          {modal && !data && <p className="text-sm text-muted">Loading…</p>}
        </Modal>
      </QuickAddCtx.Provider>
    </ToastProvider>
  );
}

"use client";
import { useState } from "react";
import { db } from "@/lib/client/api";
import { EARNING_TYPES } from "@/lib/constants";
import type { EarningSource } from "@/lib/types";
import { Button, Field, Input, Modal, MoneyInput, Segmented, Select, Textarea, useToast } from "@/components/ui";
import { errMsg, toNum } from "./shared";

export const STATUS_LABEL: Record<EarningSource["status"], string> = { idea: "Idea", active: "Active", paused: "Paused", stopped: "Stopped" };

/** Map an earning type to the income source category used on transactions. */
export function incomeCategoryFor(type: string): string {
  const map: Record<string, string> = {
    Freelancing: "Freelancing",
    Tutoring: "Tutoring",
    Internship: "Internship",
    "Part-time Job": "Part-time Work",
    "Campus Work": "Part-time Work",
    "Content Creation": "Content Creation",
    "Affiliate Marketing": "Affiliate Income",
    "Digital Products": "Selling Products",
    "Coding Projects": "Freelancing",
    "Design Services": "Freelancing",
    "Video Editing": "Freelancing",
    Writing: "Freelancing",
    "Online Services": "Online Work",
  };
  return map[type] ?? "Other";
}

export function EarningSourceModal({ open, onClose, source, today }: { open: boolean; onClose: () => void; source: EarningSource | null; today: string }) {
  const toast = useToast();
  const [name, setName] = useState(source?.source ?? "");
  const [type, setType] = useState(source?.type ?? "Freelancing");
  const [expected, setExpected] = useState(source ? String(source.expected_income || "") : "");
  const [hours, setHours] = useState(source ? String(source.hours || "") : "");
  const [start, setStart] = useState(source?.start_date ?? today);
  const [status, setStatus] = useState<EarningSource["status"]>(source?.status ?? "idea");
  const [notes, setNotes] = useState(source?.notes ?? "");
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function save() {
    if (!name.trim()) return setError("Give this income source a name");
    const h = toNum(hours) ?? 0;
    if (h < 0 || h > 200) return setError("Hours per week should be between 0 and 200");
    setError(null);
    setSaving(true);
    const body = { source: name.trim(), type, expected_income: toNum(expected) ?? 0, hours: h, start_date: start || null, status, notes: notes.trim() || null };
    try {
      if (source) await db.update("earning-sources", source.id, body);
      else await db.create("earning-sources", body);
      toast(source ? "Income source updated" : "Income source added");
      onClose();
    } catch (e) {
      toast(errMsg(e), "bad");
    } finally {
      setSaving(false);
    }
  }

  return (
    <Modal
      open={open}
      onClose={onClose}
      title={source ? "Edit income source" : "New income source"}
      footer={
        <>
          <Button variant="secondary" onClick={onClose}>
            Cancel
          </Button>
          <Button onClick={save} loading={saving}>
            Save
          </Button>
        </>
      }
    >
      <div className="space-y-3">
        <Field label="Income source" error={error}>
          {(id) => <Input id={id} value={name} onChange={(e) => setName(e.target.value)} placeholder="e.g. Maths tutoring for Class 10" maxLength={80} />}
        </Field>
        <Field label="Type">
          {(id) => (
            <Select id={id} value={type} onChange={(e) => setType(e.target.value)}>
              {[...new Set([...EARNING_TYPES, type])].map((t) => (
                <option key={t} value={t}>
                  {t}
                </option>
              ))}
            </Select>
          )}
        </Field>
        <div className="grid grid-cols-2 gap-3">
          <Field label="Expected monthly income" hint="Your guess — not guaranteed">
            {(id) => <MoneyInput id={id} value={expected} onChange={setExpected} placeholder="0" />}
          </Field>
          <Field label="Hours per week">
            {(id) => <Input id={id} inputMode="decimal" value={hours} onChange={(e) => setHours(e.target.value.replace(/[^\d.]/g, ""))} placeholder="0" />}
          </Field>
        </div>
        <Field label="Start date">{(id) => <Input id={id} type="date" value={start ?? ""} onChange={(e) => setStart(e.target.value)} />}</Field>
        <div>
          <p className="mb-1 text-xs font-medium text-ink-2">Status</p>
          <Segmented size="sm" value={status} onChange={setStatus} options={(Object.keys(STATUS_LABEL) as EarningSource["status"][]).map((k) => ({ value: k, label: STATUS_LABEL[k] }))} />
        </div>
        <Field label="Notes (optional)">{(id) => <Textarea id={id} value={notes} onChange={(e) => setNotes(e.target.value)} maxLength={500} placeholder="Clients, platform, next steps…" />}</Field>
      </div>
    </Modal>
  );
}

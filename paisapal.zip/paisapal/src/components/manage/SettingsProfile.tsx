"use client";
import { useState } from "react";
import { updateProfile } from "@/lib/client/api";
import type { Profile } from "@/lib/types";
import { Button, Card, CardTitle, Field, Input, MoneyInput, Toggle, useToast } from "@/components/ui";
import { ThemeToggle } from "@/components/ThemeToggle";
import { errMsg, toNum } from "./shared";

export function ProfileCard({ profile }: { profile: Profile }) {
  const toast = useToast();
  const [name, setName] = useState(profile.name ?? "");
  const [opening, setOpening] = useState(String(profile.opening_balance ?? 0));
  const [income, setIncome] = useState(profile.monthly_income_estimate ? String(profile.monthly_income_estimate) : "");
  const [limit, setLimit] = useState(profile.daily_limit != null ? String(profile.daily_limit) : "");
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function save() {
    const ob = opening.trim() === "" ? 0 : Number(opening);
    if (!Number.isFinite(ob)) return setError("Opening balance must be a number");
    if (!name.trim()) return setError("Tell us what to call you");
    setError(null);
    setSaving(true);
    try {
      await updateProfile({ name: name.trim(), opening_balance: ob, monthly_income_estimate: toNum(income) ?? 0, daily_limit: toNum(limit) });
      toast("Profile saved");
    } catch (e) {
      toast(errMsg(e), "bad");
    } finally {
      setSaving(false);
    }
  }

  return (
    <Card>
      <CardTitle>Profile</CardTitle>
      <div className="grid gap-3 sm:grid-cols-2">
        <Field label="Name" error={error}>
          {(id) => <Input id={id} value={name} onChange={(e) => setName(e.target.value)} maxLength={80} />}
        </Field>
        <Field label="Email" hint="Used to sign in — can't be changed here">
          {(id) => <Input id={id} value={profile.email ?? ""} readOnly disabled />}
        </Field>
        <Field label="Currency" hint="PaisaPal works in Indian Rupees">
          {(id) => <Input id={id} value="INR (₹)" readOnly disabled />}
        </Field>
        <Field label="Opening balance" hint="Money you had (wallet + bank) before your first recorded transaction. Your current balance = this + all income − all expenses.">
          {(id) => (
            <div className="relative">
              <span className="pointer-events-none absolute inset-y-0 left-3 flex items-center text-sm text-muted">₹</span>
              <Input id={id} inputMode="decimal" className="pl-7 tabular" value={opening} onChange={(e) => setOpening(e.target.value.replace(/[^\d.-]/g, ""))} />
            </div>
          )}
        </Field>
        <Field label="Monthly income estimate" hint="Pocket money, stipend, salary… used for planning when there's little history">
          {(id) => <MoneyInput id={id} value={income} onChange={setIncome} placeholder="0" />}
        </Field>
        <Field label="Daily spending limit" hint="Leave blank to use your calculated safe-to-spend">
          {(id) => <MoneyInput id={id} value={limit} onChange={setLimit} placeholder="Auto" />}
        </Field>
      </div>
      <div className="mt-4 flex justify-end">
        <Button onClick={save} loading={saving}>
          Save profile
        </Button>
      </div>
    </Card>
  );
}

export function PreferencesCard({ profile }: { profile: Profile }) {
  const toast = useToast();
  const gamification = profile.preferences?.gamification !== false;
  async function setGamification(v: boolean) {
    try {
      await updateProfile({ preferences: { gamification: v } });
      toast(v ? "Streaks & badges on" : "Streaks & badges off", "info");
    } catch (e) {
      toast(errMsg(e), "bad");
    }
  }
  return (
    <Card>
      <CardTitle>Preferences</CardTitle>
      <div className="space-y-3">
        <div className="flex items-center justify-between gap-3">
          <div>
            <p className="text-sm">Theme</p>
            <p className="text-xs text-muted">Light, system or dark</p>
          </div>
          <ThemeToggle />
        </div>
        <Toggle checked={gamification} onChange={setGamification} label="Streaks & badges" description="Show savings streaks and achievements on your dashboard and insights." />
      </div>
    </Card>
  );
}

"use client";
import { useState } from "react";
import { db } from "@/lib/client/api";
import { REMINDER_KINDS } from "@/lib/constants";
import type { CustomCategory, Reminder, ReminderRecurrence } from "@/lib/types";
import { Button, Field, Input, Modal, MoneyInput, Select, Textarea, useToast } from "@/components/ui";
import { CategoryPicker, errMsg, toNum } from "./shared";

export const RECUR_LABEL: Record<ReminderRecurrence, string> = { none: "One-time", weekly: "Weekly", monthly: "Monthly", quarterly: "Quarterly", yearly: "Yearly" };

/** Sensible default expense category for each reminder kind. */
export const KIND_CATEGORY: Record<string, string> = {
  Rent: "Housing",
  "Hostel Fees": "Housing",
  "Mobile Recharge": "Technology",
  Internet: "Technology",
  Subscription: "Technology",
  "College Fees": "Education",
  "Loan/EMI": "Other",
  Mess: "Food",
  Transport: "Travel",
  Tuition: "Education",
  Bill: "Housing",
  Other: "Other",
};

export type ReminderDraft = Partial<Pick<Reminder, "title" | "amount" | "due_date" | "recurring" | "kind" | "category" | "notes">>;

export function ReminderModal({ open, onClose, reminder, draft, today, custom }: { open: boolean; onClose: () => void; reminder: Reminder | null; draft?: ReminderDraft; today: string; custom: CustomCategory[] }) {
  const toast = useToast();
  const init = reminder ?? draft ?? {};
  const [title, setTitle] = useState(init.title ?? "");
  const [amount, setAmount] = useState(init.amount ? String(init.amount) : "");
  const [due, setDue] = useState(init.due_date ?? today);
  const [recurring, setRecurring] = useState<ReminderRecurrence>(init.recurring ?? "monthly");
  const [kind, setKind] = useState(init.kind ?? "Bill");
  const [category, setCategory] = useState(init.category ?? KIND_CATEGORY[init.kind ?? "Bill"] ?? "Other");
  const [notes, setNotes] = useState(init.notes ?? "");
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function save() {
    if (!title.trim()) return setError("What is this payment for?");
    const amt = toNum(amount) ?? 0;
    if (amt < 0) return setError("Amount can't be negative");
    if (!due) return setError("Pick a due date");
    setError(null);
    setSaving(true);
    const body = { title: title.trim(), amount: amt, due_date: due, recurring, kind, category, notes: notes.trim() || null };
    try {
      if (reminder) await db.update("reminders", reminder.id, body);
      else await db.create("reminders", body);
      toast(reminder ? "Reminder updated" : "Reminder added");
      onClose();
    } catch (e) {
      toast(errMsg(e), "bad");
    } finally {
      setSaving(false);
    }
  }

  return (
    <Modal
      open={open}
      onClose={onClose}
      title={reminder ? "Edit reminder" : "New bill / reminder"}
      footer={
        <>
          <Button variant="secondary" onClick={onClose}>
            Cancel
          </Button>
          <Button onClick={save} loading={saving}>
            Save
          </Button>
        </>
      }
    >
      <div className="space-y-3">
        <Field label="Title" error={error}>
          {(id) => <Input id={id} value={title} onChange={(e) => setTitle(e.target.value)} placeholder="e.g. Internet bill" maxLength={80} />}
        </Field>
        <div className="grid grid-cols-2 gap-3">
          <Field label="Amount">{(id) => <MoneyInput id={id} value={amount} onChange={setAmount} placeholder="0" />}</Field>
          <Field label="Due date">{(id) => <Input id={id} type="date" value={due} onChange={(e) => setDue(e.target.value)} />}</Field>
        </div>
        <div className="grid grid-cols-2 gap-3">
          <Field label="Repeats">
            {(id) => (
              <Select id={id} value={recurring} onChange={(e) => setRecurring(e.target.value as ReminderRecurrence)}>
                {(Object.keys(RECUR_LABEL) as ReminderRecurrence[]).map((r) => (
                  <option key={r} value={r}>
                    {RECUR_LABEL[r]}
                  </option>
                ))}
              </Select>
            )}
          </Field>
          <Field label="Kind">
            {(id) => (
              <Select
                id={id}
                value={kind}
                onChange={(e) => {
                  setKind(e.target.value);
                  if (KIND_CATEGORY[e.target.value]) setCategory(KIND_CATEGORY[e.target.value]);
                }}
              >
                {[...new Set([...REMINDER_KINDS, kind])].map((k) => (
                  <option key={k} value={k}>
                    {k}
                  </option>
                ))}
              </Select>
            )}
          </Field>
        </div>
        <CategoryPicker custom={custom} category={category} onChange={(c) => setCategory(c)} />
        <Field label="Notes (optional)">{(id) => <Textarea id={id} value={notes} onChange={(e) => setNotes(e.target.value)} maxLength={500} />}</Field>
      </div>
    </Modal>
  );
}

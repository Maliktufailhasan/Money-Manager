"use client";
import { Trash2 } from "lucide-react";
import { useState } from "react";
import { db } from "@/lib/client/api";
import { EXPENSE_CATEGORIES, INCOME_SOURCES } from "@/lib/constants";
import type { CustomCategory } from "@/lib/types";
import { Badge, Button, Card, CardTitle, Field, IconButton, Input, Select, confirmAction, useToast } from "@/components/ui";
import { errMsg } from "./shared";

const splitList = (v: string) => [...new Set(v.split(",").map((x) => x.trim()).filter(Boolean))];

export function CategoriesCard({ custom }: { custom: CustomCategory[] }) {
  const toast = useToast();
  const [busy, setBusy] = useState<string | null>(null);
  const [expName, setExpName] = useState("");
  const [expSubs, setExpSubs] = useState("");
  const [incName, setIncName] = useState("");
  const [builtIn, setBuiltIn] = useState(Object.keys(EXPENSE_CATEGORIES)[0]);
  const [extraSubs, setExtraSubs] = useState("");

  async function run(key: string, fn: () => Promise<unknown>, ok: string, reset?: () => void) {
    setBusy(key);
    try {
      await fn();
      toast(ok);
      reset?.();
    } catch (e) {
      toast(errMsg(e), "bad");
    } finally {
      setBusy(null);
    }
  }

  /** Create a row, or merge subcategories into an existing row with the same name. */
  function upsert(kind: "expense" | "income", name: string, subs: string[]) {
    const existing = custom.find((c) => c.kind === kind && c.name.toLowerCase() === name.toLowerCase());
    if (existing) return db.update("categories", existing.id, { subcategories: [...new Set([...existing.subcategories, ...subs])] });
    return db.create("categories", { kind, name, subcategories: subs });
  }

  function addExpense() {
    const name = expName.trim();
    if (!name) return toast("Name your category", "warn");
    const builtInMatch = Object.keys(EXPENSE_CATEGORIES).find((c) => c.toLowerCase() === name.toLowerCase());
    run("exp", () => upsert("expense", builtInMatch ?? name, splitList(expSubs)), `Category "${builtInMatch ?? name}" saved`, () => {
      setExpName("");
      setExpSubs("");
    });
  }
  function addIncome() {
    const name = incName.trim();
    if (!name) return toast("Name your income source", "warn");
    if (INCOME_SOURCES.some((s) => s.toLowerCase() === name.toLowerCase())) return toast(`"${name}" already exists`, "info");
    run("inc", () => upsert("income", name, []), `Income source "${name}" added`, () => setIncName(""));
  }
  function addSubs() {
    const subs = splitList(extraSubs).filter((x) => !EXPENSE_CATEGORIES[builtIn].includes(x));
    if (!subs.length) return toast("Enter new subcategories, separated by commas", "warn");
    run("sub", () => upsert("expense", builtIn, subs), `Added to ${builtIn}`, () => setExtraSubs(""));
  }
  function remove(c: CustomCategory) {
    const msg = EXPENSE_CATEGORIES[c.name] && c.kind === "expense" ? `Remove your extra subcategories from ${c.name}?` : `Delete "${c.name}"? Existing transactions keep their category.`;
    if (!confirmAction(msg)) return;
    run(`d-${c.id}`, () => db.remove("categories", c.id), "Removed");
  }

  return (
    <Card>
      <CardTitle hint="Add your own categories on top of the built-in ones">Custom categories</CardTitle>
      <div className="grid gap-5 lg:grid-cols-3">
        <div className="space-y-2">
          <p className="text-xs font-semibold text-ink-2">New expense category</p>
          <Field label="Name">{(id) => <Input id={id} value={expName} onChange={(e) => setExpName(e.target.value)} placeholder="e.g. Gym" maxLength={60} />}</Field>
          <Field label="Subcategories" hint="Comma-separated">
            {(id) => <Input id={id} value={expSubs} onChange={(e) => setExpSubs(e.target.value)} placeholder="Membership, Supplements" />}
          </Field>
          <Button size="sm" onClick={addExpense} loading={busy === "exp"}>
            Add category
          </Button>
        </div>
        <div className="space-y-2">
          <p className="text-xs font-semibold text-ink-2">Add subcategories to a built-in category</p>
          <Field label="Category">
            {(id) => (
              <Select id={id} value={builtIn} onChange={(e) => setBuiltIn(e.target.value)}>
                {Object.keys(EXPENSE_CATEGORIES).map((c) => (
                  <option key={c}>{c}</option>
                ))}
              </Select>
            )}
          </Field>
          <Field label="New subcategories" hint="Comma-separated">
            {(id) => <Input id={id} value={extraSubs} onChange={(e) => setExtraSubs(e.target.value)} placeholder="e.g. Juice, Bakery" />}
          </Field>
          <Button size="sm" onClick={addSubs} loading={busy === "sub"}>
            Add subcategories
          </Button>
        </div>
        <div className="space-y-2">
          <p className="text-xs font-semibold text-ink-2">New income source</p>
          <Field label="Name">{(id) => <Input id={id} value={incName} onChange={(e) => setIncName(e.target.value)} placeholder="e.g. Hackathon prizes" maxLength={60} />}</Field>
          <Button size="sm" onClick={addIncome} loading={busy === "inc"}>
            Add income source
          </Button>
        </div>
      </div>

      <div className="mt-5 border-t border-line pt-4">
        <p className="mb-2 text-xs font-semibold text-ink-2">Your custom categories</p>
        {custom.length === 0 ? (
          <p className="text-sm text-muted">None yet — you&apos;re using the built-in list.</p>
        ) : (
          <ul className="divide-y divide-line">
            {custom.map((c) => (
              <li key={c.id} className="flex items-start gap-3 py-2">
                <div className="min-w-0 flex-1">
                  <div className="flex flex-wrap items-center gap-1.5 text-sm">
                    <span className="font-medium">{c.name}</span>
                    <Badge tone={c.kind === "income" ? "good" : "neutral"}>{c.kind === "income" ? "Income" : EXPENSE_CATEGORIES[c.name] ? "Extra subcategories" : "Expense"}</Badge>
                  </div>
                  {c.subcategories.length > 0 && <p className="mt-0.5 text-xs text-muted">{c.subcategories.join(", ")}</p>}
                </div>
                <IconButton label={`Delete ${c.name}`} onClick={() => remove(c)} disabled={busy === `d-${c.id}`}>
                  <Trash2 className="size-4" />
                </IconButton>
              </li>
            ))}
          </ul>
        )}
      </div>
    </Card>
  );
}

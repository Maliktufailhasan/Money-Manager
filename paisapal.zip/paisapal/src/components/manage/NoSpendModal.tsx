"use client";
import { useState } from "react";
import { db } from "@/lib/client/api";
import { addDays } from "@/lib/finance";
import type { CustomCategory, NoSpendRule } from "@/lib/types";
import { Button, Chip, Field, Input, Modal, MoneyInput, Toggle, useToast } from "@/components/ui";
import { CategoryPicker, errMsg, toNum } from "./shared";

export const NO_SPEND_SUGGESTIONS = [
  { title: "Food Delivery", category: "Food", subcategory: "Delivery" },
  { title: "Unnecessary Shopping", category: "Personal", subcategory: "Shopping" },
  { title: "Daily Café", category: "Social", subcategory: "Cafes" },
  { title: "Random Online Purchases", category: "Personal", subcategory: "Shopping" },
  { title: "Unused Subscriptions", category: "Technology", subcategory: "Subscriptions" },
];

export function NoSpendModal({ open, onClose, rule, today, custom }: { open: boolean; onClose: () => void; rule: NoSpendRule | null; today: string; custom: CustomCategory[] }) {
  const toast = useToast();
  const [title, setTitle] = useState(rule?.title ?? "");
  const [category, setCategory] = useState(rule?.category ?? "Food");
  const [sub, setSub] = useState(rule?.subcategory ?? "");
  const [start, setStart] = useState(rule?.start_date ?? today);
  const [end, setEnd] = useState(rule?.end_date ?? addDays(today, 29));
  const [limit, setLimit] = useState(rule ? String(rule.limit_amount) : "0");
  const [baseline, setBaseline] = useState(rule?.baseline_monthly != null ? String(rule.baseline_monthly) : "");
  const [active, setActive] = useState(rule?.active ?? true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function save() {
    if (!title.trim()) return setError("Give the rule a name");
    if (!category) return setError("Pick a category");
    if (!start || !end || end < start) return setError("End date must be on or after the start date");
    setError(null);
    setSaving(true);
    const body = { title: title.trim(), category, subcategory: sub || null, start_date: start, end_date: end, limit_amount: toNum(limit) ?? 0, baseline_monthly: toNum(baseline), active };
    try {
      if (rule) await db.update("no-spend", rule.id, body);
      else await db.create("no-spend", body);
      toast(rule ? "Rule updated" : "Rule created — you've got this!");
      onClose();
    } catch (e) {
      toast(errMsg(e), "bad");
    } finally {
      setSaving(false);
    }
  }

  return (
    <Modal
      open={open}
      onClose={onClose}
      title={rule ? "Edit don't-spend rule" : "New don't-spend rule"}
      footer={
        <>
          <Button variant="secondary" onClick={onClose}>
            Cancel
          </Button>
          <Button onClick={save} loading={saving}>
            Save rule
          </Button>
        </>
      }
    >
      <div className="space-y-3">
        {!rule && (
          <div>
            <p className="mb-1.5 text-xs font-medium text-ink-2">Quick picks</p>
            <div className="flex flex-wrap gap-1.5">
              {NO_SPEND_SUGGESTIONS.map((s) => (
                <Chip
                  key={s.title}
                  active={title === s.title}
                  onClick={() => {
                    setTitle(s.title);
                    setCategory(s.category);
                    setSub(s.subcategory);
                  }}
                >
                  ❌ {s.title}
                </Chip>
              ))}
            </div>
          </div>
        )}
        <Field label="Rule name" error={error}>
          {(id) => <Input id={id} value={title} onChange={(e) => setTitle(e.target.value)} placeholder="e.g. No food delivery" maxLength={80} />}
        </Field>
        <CategoryPicker custom={custom} category={category} subcategory={sub} onChange={(c, s2) => {
            setCategory(c);
            setSub(s2);
          }} />
        <div className="grid grid-cols-2 gap-3">
          <Field label="Start date">{(id) => <Input id={id} type="date" value={start} onChange={(e) => setStart(e.target.value)} />}</Field>
          <Field label="End date">{(id) => <Input id={id} type="date" value={end} min={start} onChange={(e) => setEnd(e.target.value)} />}</Field>
        </div>
        <div className="flex flex-wrap gap-1.5">
          {[7, 14, 30].map((n) => (
            <Chip key={n} active={end === addDays(start, n - 1)} onClick={() => setEnd(addDays(start, n - 1))}>
              {n} days
            </Chip>
          ))}
        </div>
        <div className="grid grid-cols-2 gap-3">
          <Field label="Spending limit" hint="0 = avoid completely">
            {(id) => <MoneyInput id={id} value={limit} onChange={setLimit} />}
          </Field>
          <Field label="Typical monthly spend" hint="Optional. Blank = use your history">
            {(id) => <MoneyInput id={id} value={baseline} onChange={setBaseline} placeholder="Auto" />}
          </Field>
        </div>
        <Toggle checked={active} onChange={setActive} label="Rule is on" description="Turned-off rules don't warn you when you add an expense." />
      </div>
    </Modal>
  );
}

"use client";
import { Plus, Trash2 } from "lucide-react";
import { REMINDER_KINDS } from "@/lib/constants";
import { EXPENSE_CATEGORIES } from "@/lib/constants";
import { Button, Chip, IconButton, Input, MoneyInput, Select } from "@/components/ui";
import { KIND_CATEGORY } from "./ReminderModal";

export interface RecurringRow {
  key: number;
  title: string;
  amount: string;
  kind: string;
  category: string;
  day: string;
}

export const RECURRING_CHIPS = [
  { title: "Rent", kind: "Rent", category: "Housing" },
  { title: "Hostel", kind: "Hostel Fees", category: "Housing" },
  { title: "Mess", kind: "Mess", category: "Food" },
  { title: "Internet", kind: "Internet", category: "Technology" },
  { title: "Mobile recharge", kind: "Mobile Recharge", category: "Technology" },
  { title: "Transport pass", kind: "Transport", category: "Travel" },
];

export function newRow(preset?: { title: string; kind: string; category: string }): RecurringRow {
  return { key: Date.now() + Math.random(), title: preset?.title ?? "", amount: "", kind: preset?.kind ?? "Bill", category: preset?.category ?? "Other", day: "1" };
}

export function RecurringEditor({ rows, onChange, errors }: { rows: RecurringRow[]; onChange: (rows: RecurringRow[]) => void; errors: Record<number, string> }) {
  const set = (key: number, patch: Partial<RecurringRow>) => onChange(rows.map((r) => (r.key === key ? { ...r, ...patch } : r)));
  const has = (title: string) => rows.some((r) => r.title.toLowerCase() === title.toLowerCase());
  return (
    <div className="space-y-3">
      <div className="flex flex-wrap gap-1.5">
        {RECURRING_CHIPS.map((c) => (
          <Chip key={c.title} active={has(c.title)} onClick={() => (has(c.title) ? onChange(rows.filter((r) => r.title.toLowerCase() !== c.title.toLowerCase())) : onChange([...rows, newRow(c)]))}>
            {has(c.title) ? "✓ " : "+ "}
            {c.title}
          </Chip>
        ))}
      </div>
      {rows.map((r) => (
        <div key={r.key} className="rounded-2xl border border-line bg-surface p-3">
          <div className="flex items-center gap-2">
            <Input aria-label="What is it?" value={r.title} onChange={(e) => set(r.key, { title: e.target.value })} placeholder="What is it?" maxLength={80} />
            <IconButton label={`Remove ${r.title || "row"}`} onClick={() => onChange(rows.filter((x) => x.key !== r.key))}>
              <Trash2 className="size-4" />
            </IconButton>
          </div>
          <div className="mt-2 grid grid-cols-2 gap-2 sm:grid-cols-4">
            <MoneyInput aria-label="Amount per month" value={r.amount} onChange={(v) => set(r.key, { amount: v })} placeholder="Amount" />
            <label className="flex items-center gap-1.5 text-xs text-muted">
              Day
              <Input aria-label="Day of month" inputMode="numeric" value={r.day} onChange={(e) => set(r.key, { day: e.target.value.replace(/\D/g, "").slice(0, 2) })} />
            </label>
            <Select aria-label="Kind" value={r.kind} onChange={(e) => set(r.key, { kind: e.target.value, category: KIND_CATEGORY[e.target.value] ?? r.category })}>
              {REMINDER_KINDS.map((k) => (
                <option key={k}>{k}</option>
              ))}
            </Select>
            <Select aria-label="Category" value={r.category} onChange={(e) => set(r.key, { category: e.target.value })}>
              {Object.keys(EXPENSE_CATEGORIES).map((c) => (
                <option key={c}>{c}</option>
              ))}
            </Select>
          </div>
          {errors[r.key] && <p className="mt-1.5 text-xs text-bad">{errors[r.key]}</p>}
        </div>
      ))}
      <Button variant="secondary" size="sm" onClick={() => onChange([...rows, newRow()])}>
        <Plus className="size-3.5" /> Add another
      </Button>
    </div>
  );
}

"use client";
import { Database, Download, FileJson, FileSpreadsheet, FlaskConical, Trash2, Upload } from "lucide-react";
import { useRef, useState } from "react";
import { api, refreshAll } from "@/lib/client/api";
import type { Transaction } from "@/lib/types";
import { Badge, Button, Card, CardTitle, Segmented, confirmAction, useToast } from "@/components/ui";
import { errMsg } from "./shared";

const CSV_COLUMNS: (keyof Transaction)[] = [
  "date", "time", "type", "amount", "category", "subcategory", "income_type", "description", "merchant", "payment_method", "need_or_want", "essential", "recurring", "recurrence", "notes",
];

function csvCell(v: unknown): string {
  if (v === null || v === undefined) return "";
  const s = String(v);
  // guard against spreadsheet formula injection, then quote
  const safe = /^[=+\-@\t\r]/.test(s) && !/^-?\d/.test(s) ? `'${s}` : s;
  return /[",\n\r]/.test(safe) ? `"${safe.replace(/"/g, '""')}"` : safe;
}

function download(name: string, text: string, type: string) {
  const url = URL.createObjectURL(new Blob([text], { type }));
  const a = document.createElement("a");
  a.href = url;
  a.download = name;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

const BACKUP_KEYS = ["transactions", "goals", "goal_contributions", "budgets", "subscriptions", "reminders", "no_spend_rules", "earning_sources", "categories"] as const;
type Backup = { app: string; version: number } & Partial<Record<(typeof BACKUP_KEYS)[number], unknown[]>>;

export function DataCard({ today, demoCount }: { today: string; demoCount: number }) {
  const toast = useToast();
  const fileRef = useRef<HTMLInputElement>(null);
  const [busy, setBusy] = useState<string | null>(null);
  const [csvProgress, setCsvProgress] = useState<string | null>(null);
  const [pending, setPending] = useState<{ file: string; backup: Backup } | null>(null);
  const [mode, setMode] = useState<"merge" | "replace">("merge");
  const [result, setResult] = useState<{ ok: boolean; text: string } | null>(null);

  async function exportCsv() {
    setBusy("csv");
    try {
      const rows: Transaction[] = [];
      for (let page = 1; page < 1000; page++) {
        const r = await api<{ rows: Transaction[]; total: number }>(`/api/data/transactions?page=${page}&pageSize=200&sort=date&dir=asc`);
        rows.push(...r.rows);
        setCsvProgress(`${rows.length} / ${r.total}`);
        if (!r.rows.length || rows.length >= r.total) break;
      }
      if (!rows.length) {
        toast("No transactions to export yet", "info");
        return;
      }
      const csv = [CSV_COLUMNS.join(","), ...rows.map((t) => CSV_COLUMNS.map((c) => csvCell(t[c])).join(","))].join("\n");
      download(`paisapal-transactions-${today}.csv`, "﻿" + csv, "text/csv;charset=utf-8");
      toast(`Exported ${rows.length} transactions`);
    } catch (e) {
      toast(errMsg(e), "bad");
    } finally {
      setBusy(null);
      setCsvProgress(null);
    }
  }

  async function pickFile(f: File | undefined) {
    setResult(null);
    if (!f) return;
    try {
      const parsed: unknown = JSON.parse(await f.text());
      if (!parsed || typeof parsed !== "object" || (parsed as Backup).app !== "paisapal") throw new Error("This doesn't look like a PaisaPal backup file.");
      setPending({ file: f.name, backup: parsed as Backup });
      setMode("merge");
    } catch (e) {
      setResult({ ok: false, text: e instanceof SyntaxError ? "That file isn't valid JSON." : errMsg(e) });
    } finally {
      if (fileRef.current) fileRef.current.value = "";
    }
  }

  async function doImport() {
    if (!pending) return;
    if (mode === "replace" && !confirmAction("Replace ALL your current data with this backup? Everything you have now will be deleted first. This can't be undone.")) return;
    setBusy("import");
    try {
      const r = await api<{ imported: Record<string, number> }>("/api/backup", { method: "POST", json: { mode, backup: pending.backup } });
      await refreshAll();
      const parts = Object.entries(r.imported).map(([k, v]) => `${v} ${k}`);
      setResult({ ok: true, text: `Imported ${parts.join(", ")}.` });
      setPending(null);
      toast("Backup imported");
    } catch (e) {
      setResult({ ok: false, text: errMsg(e) });
    } finally {
      setBusy(null);
    }
  }

  async function demo(load: boolean) {
    if (!load && !confirmAction("Remove all sample (demo) data? Your own entries are not touched.")) return;
    setBusy("demo");
    try {
      await api("/api/demo", { method: load ? "POST" : "DELETE" });
      await refreshAll();
      toast(load ? "Sample data loaded — look for the demo labels" : "Sample data removed");
    } catch (e) {
      toast(errMsg(e), "bad");
    } finally {
      setBusy(null);
    }
  }

  return (
    <Card>
      <CardTitle hint="Your data belongs to you — take it anywhere">
        <span className="flex items-center gap-1.5">
          <Database className="size-4 text-brand" /> Data & backup
        </span>
      </CardTitle>
      <div className="grid gap-3 sm:grid-cols-2">
        <a href="/api/backup" download className="flex items-center gap-3 rounded-xl border border-line p-3 hover:bg-surface-2">
          <FileJson className="size-5 shrink-0 text-brand" />
          <span className="min-w-0">
            <span className="block text-sm font-medium">Export all data</span>
            <span className="block text-xs text-muted">Full JSON backup (can be imported later)</span>
          </span>
          <Download className="ml-auto size-4 shrink-0 text-muted" />
        </a>
        <button type="button" onClick={exportCsv} disabled={busy === "csv"} className="flex items-center gap-3 rounded-xl border border-line p-3 text-left hover:bg-surface-2 disabled:opacity-60">
          <FileSpreadsheet className="size-5 shrink-0 text-brand" />
          <span className="min-w-0">
            <span className="block text-sm font-medium">Export transactions (CSV)</span>
            <span className="block text-xs text-muted">{csvProgress ? `Fetching ${csvProgress}…` : "Opens in Excel / Google Sheets"}</span>
          </span>
          <Download className="ml-auto size-4 shrink-0 text-muted" />
        </button>
      </div>

      <div className="mt-4 rounded-xl border border-line p-3">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div>
            <p className="text-sm font-medium">Import a backup</p>
            <p className="text-xs text-muted">Choose a PaisaPal .json backup file</p>
          </div>
          <Button size="sm" variant="secondary" onClick={() => fileRef.current?.click()}>
            <Upload className="size-3.5" /> Choose file
          </Button>
          <input ref={fileRef} type="file" accept="application/json,.json" className="hidden" onChange={(e) => pickFile(e.target.files?.[0])} />
        </div>
        {pending && (
          <div className="mt-3 space-y-3 border-t border-line pt-3">
            <p className="text-xs text-ink-2">
              <span className="font-medium">{pending.file}</span> contains{" "}
              {BACKUP_KEYS.filter((k) => Array.isArray(pending.backup[k]) && pending.backup[k]!.length)
                .map((k) => `${pending.backup[k]!.length} ${k.replace(/_/g, " ")}`)
                .join(", ") || "no records"}
              .
            </p>
            <Segmented
              size="sm"
              value={mode}
              onChange={setMode}
              options={[
                { value: "merge", label: "Merge with my data" },
                { value: "replace", label: "Replace my data" },
              ]}
            />
            <p className="text-xs text-muted">{mode === "merge" ? "Adds the backup's records alongside what you already have (duplicates are possible)." : "Deletes everything you have now, then restores the backup and its profile settings."}</p>
            <div className="flex gap-2">
              <Button size="sm" variant={mode === "replace" ? "danger" : "primary"} onClick={doImport} loading={busy === "import"}>
                {mode === "replace" ? "Replace & import" : "Import"}
              </Button>
              <Button size="sm" variant="ghost" onClick={() => setPending(null)}>
                Cancel
              </Button>
            </div>
          </div>
        )}
        {result && <p className={`mt-3 rounded-lg px-3 py-2 text-xs ${result.ok ? "bg-good-soft text-good" : "bg-bad-soft text-bad"}`}>{result.text}</p>}
      </div>

      <div className="mt-4 rounded-xl border border-dashed border-line p-3">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div className="min-w-0">
            <p className="flex items-center gap-1.5 text-sm font-medium">
              <FlaskConical className="size-4 text-warn" /> Demo data <Badge tone="warn">Sample data</Badge>
            </p>
            <p className="text-xs text-muted">
              {demoCount > 0 ? `${demoCount} sample transactions are loaded. They're fake and only there to explore the app.` : "Load clearly-labelled fake transactions, goals and bills to explore the app. Remove them any time."}
            </p>
          </div>
          <div className="flex gap-2">
            <Button size="sm" variant="secondary" onClick={() => demo(true)} loading={busy === "demo"}>
              {demoCount > 0 ? "Reload demo data" : "Load demo data"}
            </Button>
            {demoCount > 0 && (
              <Button size="sm" variant="ghost" onClick={() => demo(false)} disabled={busy === "demo"}>
                <Trash2 className="size-3.5" /> Remove
              </Button>
            )}
          </div>
        </div>
      </div>
    </Card>
  );
}

export function DangerCard() {
  const toast = useToast();
  const [busy, setBusy] = useState(false);
  async function wipe() {
    if (!confirmAction("Delete ALL your financial data? Transactions, goals, budgets, bills, subscriptions and rules will be erased.")) return;
    if (!confirmAction("Are you absolutely sure? This cannot be undone. Consider exporting a backup first.")) return;
    setBusy(true);
    try {
      await api("/api/backup", { method: "DELETE" });
      await refreshAll();
      toast("All financial data deleted", "info");
    } catch (e) {
      toast(errMsg(e), "bad");
    } finally {
      setBusy(false);
    }
  }
  return (
    <section className="rounded-2xl border border-bad/40 bg-surface p-4 sm:p-5">
      <CardTitle hint="Your account stays — only the data is removed">
        <span className="text-bad">Danger zone</span>
      </CardTitle>
      <div className="flex flex-wrap items-center justify-between gap-3">
        <p className="text-sm text-ink-2">Delete all my financial data</p>
        <Button variant="danger" size="sm" onClick={wipe} loading={busy}>
          <Trash2 className="size-3.5" /> Delete everything
        </Button>
      </div>
    </section>
  );
}

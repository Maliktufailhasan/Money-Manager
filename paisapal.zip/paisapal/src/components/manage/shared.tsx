"use client";
import { MoreHorizontal } from "lucide-react";
import { useEffect, useRef, useState, type ReactNode } from "react";
import { expenseCategories } from "@/lib/client/categories";
import type { CustomCategory } from "@/lib/types";
import { Badge, Field, Select, cn } from "@/components/ui";

/** Human-readable error message from anything thrown. */
export function errMsg(e: unknown): string {
  return e instanceof Error ? e.message : "Something went wrong";
}

/** Parse a money/number text field ("" → null). */
export function toNum(v: string): number | null {
  if (v.trim() === "") return null;
  const n = Number(v);
  return Number.isFinite(n) ? n : null;
}

/** "Overdue by 2 days" / "Today" / "Tomorrow" / "in 5 days" */
export function dueLabel(daysAway: number): string {
  if (daysAway < 0) return `Overdue by ${-daysAway} day${daysAway === -1 ? "" : "s"}`;
  if (daysAway === 0) return "Today";
  if (daysAway === 1) return "Tomorrow";
  return `in ${daysAway} days`;
}

export function DueBadge({ daysAway, soonWithin = 3 }: { daysAway: number; soonWithin?: number }) {
  const tone = daysAway < 0 ? "bad" : daysAway <= soonWithin ? "warn" : "neutral";
  return <Badge tone={tone}>{dueLabel(daysAway)}</Badge>;
}

/** Category + optional subcategory pickers, using built-in + custom expense categories. */
export function CategoryPicker({
  custom, category, subcategory, onChange, allowNoSub = true, subLabel = "Subcategory (optional)",
}: {
  custom: CustomCategory[];
  category: string;
  subcategory?: string;
  onChange: (category: string, subcategory: string) => void;
  allowNoSub?: boolean;
  subLabel?: string;
}) {
  const cats = expenseCategories(custom);
  const subs = cats[category] ?? [];
  return (
    <div className="grid grid-cols-2 gap-3">
      <Field label="Category">
        {(id) => (
          <Select id={id} value={category} onChange={(e) => onChange(e.target.value, "")}>
            {!cats[category] && <option value={category}>{category || "Choose…"}</option>}
            {Object.keys(cats).map((c) => (
              <option key={c} value={c}>
                {c}
              </option>
            ))}
          </Select>
        )}
      </Field>
      {subcategory !== undefined && (
        <Field label={subLabel}>
          {(id) => (
            <Select id={id} value={subcategory} onChange={(e) => onChange(category, e.target.value)}>
              {allowNoSub && <option value="">Whole category</option>}
              {subcategory && !subs.includes(subcategory) && <option value={subcategory}>{subcategory}</option>}
              {subs.map((s) => (
                <option key={s} value={s}>
                  {s}
                </option>
              ))}
            </Select>
          )}
        </Field>
      )}
    </div>
  );
}

/** Small overflow menu for secondary row actions (edit/delete/skip). */
export function RowMenu({ items, label = "More actions" }: { items: { label: string; icon?: ReactNode; onClick: () => void; danger?: boolean }[]; label?: string }) {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (!open) return;
    const close = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    const esc = (e: KeyboardEvent) => e.key === "Escape" && setOpen(false);
    document.addEventListener("mousedown", close);
    document.addEventListener("keydown", esc);
    return () => {
      document.removeEventListener("mousedown", close);
      document.removeEventListener("keydown", esc);
    };
  }, [open]);
  return (
    <div className="relative" ref={ref}>
      <button
        type="button"
        aria-label={label}
        title={label}
        aria-haspopup="menu"
        aria-expanded={open}
        onClick={() => setOpen((v) => !v)}
        className="inline-flex size-8 items-center justify-center rounded-lg text-ink-2 hover:bg-surface-2 hover:text-ink"
      >
        <MoreHorizontal className="size-4" />
      </button>
      {open && (
        <div role="menu" className="absolute right-0 z-20 mt-1 min-w-36 overflow-hidden rounded-xl border border-line bg-surface py-1 shadow-lg">
          {items.map((it) => (
            <button
              key={it.label}
              role="menuitem"
              type="button"
              onClick={() => {
                setOpen(false);
                it.onClick();
              }}
              className={cn("flex w-full items-center gap-2 px-3 py-2 text-left text-sm hover:bg-surface-2", it.danger ? "text-bad" : "text-ink")}
            >
              {it.icon}
              {it.label}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

/** A labelled summary number in a compact strip. */
export function Figure({ label, children, hint }: { label: string; children: ReactNode; hint?: ReactNode }) {
  return (
    <div className="min-w-0">
      <div className="text-xs text-muted">{label}</div>
      <div className="text-lg font-semibold tracking-tight tabular">{children}</div>
      {hint && <div className="text-xs text-muted">{hint}</div>}
    </div>
  );
}

"use client";
import { useState } from "react";
import { db } from "@/lib/client/api";
import { addMonths } from "@/lib/finance";
import type { BillingCycle, CustomCategory, Subscription } from "@/lib/types";
import { Button, Chip, Field, Input, Modal, MoneyInput, Segmented, Select, Textarea, Toggle, useToast } from "@/components/ui";
import { CategoryPicker, errMsg, toNum } from "./shared";

export const CYCLE_LABEL: Record<BillingCycle, string> = { weekly: "Weekly", monthly: "Monthly", quarterly: "Quarterly", yearly: "Yearly" };

const EXAMPLES = [
  { name: "Netflix", category: "Personal" },
  { name: "Spotify", category: "Personal" },
  { name: "YouTube Premium", category: "Personal" },
  { name: "Cloud storage", category: "Technology" },
  { name: "ChatGPT / AI tools", category: "Technology" },
  { name: "Coursera / learning platform", category: "Education" },
  { name: "Mobile plan", category: "Technology" },
];

export function SubscriptionModal({ open, onClose, sub, today, custom }: { open: boolean; onClose: () => void; sub: Subscription | null; today: string; custom: CustomCategory[] }) {
  const toast = useToast();
  const [name, setName] = useState(sub?.name ?? "");
  const [amount, setAmount] = useState(sub ? String(sub.amount) : "");
  const [cycle, setCycle] = useState<BillingCycle>(sub?.billing_cycle ?? "monthly");
  const [next, setNext] = useState(sub?.next_payment_date ?? addMonths(today, 1));
  const [category, setCategory] = useState(sub?.category ?? "Technology");
  const [remind, setRemind] = useState(String(sub?.remind_days_before ?? 2));
  const [active, setActive] = useState(sub ? sub.status === "active" : true);
  const [notes, setNotes] = useState(sub?.notes ?? "");
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function save() {
    const amt = toNum(amount);
    if (!name.trim()) return setError("Name the subscription");
    if (amt === null || amt <= 0) return setError("Enter how much it costs");
    if (!next) return setError("Pick the next payment date");
    setError(null);
    setSaving(true);
    const body = { name: name.trim(), amount: amt, billing_cycle: cycle, next_payment_date: next, category, status: active ? "active" : "inactive", remind_days_before: Math.min(30, Math.max(0, Math.round(toNum(remind) ?? 2))), notes: notes.trim() || null };
    try {
      if (sub) await db.update("subscriptions", sub.id, body);
      else await db.create("subscriptions", body);
      toast(sub ? "Subscription updated" : "Subscription added");
      onClose();
    } catch (e) {
      toast(errMsg(e), "bad");
    } finally {
      setSaving(false);
    }
  }

  return (
    <Modal
      open={open}
      onClose={onClose}
      title={sub ? "Edit subscription" : "Add subscription"}
      footer={
        <>
          <Button variant="secondary" onClick={onClose}>
            Cancel
          </Button>
          <Button onClick={save} loading={saving}>
            Save
          </Button>
        </>
      }
    >
      <div className="space-y-3">
        {!sub && (
          <div className="flex flex-wrap gap-1.5">
            {EXAMPLES.map((x) => (
              <Chip
                key={x.name}
                active={name === x.name}
                onClick={() => {
                  setName(x.name);
                  setCategory(x.category);
                }}
              >
                {x.name}
              </Chip>
            ))}
          </div>
        )}
        <Field label="Name" error={error}>
          {(id) => <Input id={id} value={name} onChange={(e) => setName(e.target.value)} placeholder="e.g. Spotify" maxLength={80} />}
        </Field>
        <div className="grid grid-cols-2 gap-3">
          <Field label="Cost per bill">{(id) => <MoneyInput id={id} value={amount} onChange={setAmount} placeholder="0" />}</Field>
          <Field label="Next payment">{(id) => <Input id={id} type="date" value={next} onChange={(e) => setNext(e.target.value)} />}</Field>
        </div>
        <div>
          <p className="mb-1 text-xs font-medium text-ink-2">Billing cycle</p>
          <Segmented size="sm" value={cycle} onChange={setCycle} options={(Object.keys(CYCLE_LABEL) as BillingCycle[]).map((c) => ({ value: c, label: CYCLE_LABEL[c] }))} />
        </div>
        <CategoryPicker custom={custom} category={category} onChange={(c) => setCategory(c)} />
        <Field label="Remind me before (days)">
          {(id) => (
            <Select id={id} value={remind} onChange={(e) => setRemind(e.target.value)}>
              {[0, 1, 2, 3, 5, 7, 14].map((n) => (
                <option key={n} value={String(n)}>
                  {n === 0 ? "On the day" : `${n} day${n === 1 ? "" : "s"} before`}
                </option>
              ))}
            </Select>
          )}
        </Field>
        <Toggle checked={active} onChange={setActive} label="Active" description="Inactive subscriptions aren't counted in your costs or reminders." />
        <Field label="Notes (optional)">{(id) => <Textarea id={id} value={notes} onChange={(e) => setNotes(e.target.value)} maxLength={500} />}</Field>
      </div>
    </Modal>
  );
}

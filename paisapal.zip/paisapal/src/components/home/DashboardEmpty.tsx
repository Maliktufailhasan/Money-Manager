"use client";
import { Minus, Plus, Sparkles, Target } from "lucide-react";
import Link from "next/link";
import { useState } from "react";
import { useQuickAdd } from "@/components/AppShell";
import { Badge, Button, Card, useToast } from "@/components/ui";
import { api, refreshAll } from "@/lib/client/api";

export function DashboardEmpty({ name }: { name: string }) {
  const quick = useQuickAdd();
  const toast = useToast();
  const [loading, setLoading] = useState(false);

  async function loadDemo() {
    setLoading(true);
    try {
      await api("/api/demo", { method: "POST" });
      await refreshAll();
      toast("Sample data loaded. It is marked as demo and can be removed any time.", "info");
    } catch (e) {
      toast(e instanceof Error ? e.message : "Couldn't load demo data", "bad");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="mx-auto max-w-xl py-6 sm:py-12">
      <Card className="text-center">
        <div className="mx-auto mb-3 flex size-12 items-center justify-center rounded-2xl bg-brand-soft text-brand">
          <Sparkles className="size-6" />
        </div>
        <h1 className="text-xl font-semibold tracking-tight">Hi{name ? ` ${name.split(" ")[0]}` : ""}! Welcome to PaisaPal</h1>
        <p className="mt-1 text-sm text-muted">Welcome! Start by adding your first income or expense.</p>
        <p className="mt-1 text-xs text-muted">Your dashboard fills in from what you record — nothing here is guessed.</p>
        <div className="mt-5 grid gap-2 sm:grid-cols-2">
          <Button variant="soft" onClick={() => quick.open({ type: "income" })}>
            <Plus className="size-4" /> Add Income
          </Button>
          <Button onClick={() => quick.open({ type: "expense" })}>
            <Minus className="size-4" /> Add Expense
          </Button>
        </div>
        <Link href="/goals" className="mt-2 inline-flex h-10 w-full items-center justify-center gap-1.5 rounded-xl border border-line text-sm font-medium hover:bg-surface-2">
          <Target className="size-4" /> Create your first goal
        </Link>
        <div className="mt-6 border-t border-line pt-4">
          <p className="mb-2 text-xs text-muted">
            Just exploring? Load a few months of <Badge tone="warn">sample data</Badge> to see how everything works. It&apos;s marked as demo and can be removed later.
          </p>
          <Button variant="ghost" size="sm" loading={loading} onClick={loadDemo}>
            Load demo data (sample only)
          </Button>
        </div>
      </Card>
    </div>
  );
}

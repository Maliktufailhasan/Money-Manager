"use client";
import Link from "next/link";
import { useMemo } from "react";
import { BarsChart, COLORS, ChartBox, Donut, LinesChart, SERIES } from "@/components/charts";
import { Badge, Card, CardTitle, Money, Progress } from "@/components/ui";
import type { FinanceData } from "@/lib/client/useFinance";
import { incomeSources } from "@/lib/client/categories";
import { addDays, balanceSeries, dailySeries, fmtDate, formatINR, goalMetrics, monthStart, monthlySeries, summarize, weeklySeries, type GoalStatus } from "@/lib/finance";

const INC = { key: "income", label: "Received", color: COLORS.income };
const EXP = { key: "expense", label: "Spent", color: COLORS.expense };

export function sourceColorFor(sources: string[]) {
  return (name: string) => {
    const i = sources.indexOf(name);
    return i < 0 ? "var(--muted)" : SERIES[i % SERIES.length];
  };
}

const goalTone: Record<GoalStatus, "good" | "warn" | "bad" | "brand"> = { completed: "good", on_track: "good", behind: "warn", overdue: "bad", no_deadline: "brand", paused: "brand" };

export function DashboardCharts({ data }: { data: FinanceData }) {
  const { s, today, budget, position } = data;
  const c = useMemo(() => {
    const txs = s.transactions;
    const six = monthlySeries(txs, 6, today).map((p) => ({ ...p }));
    const twelve = monthlySeries(txs, 12, today).map((p) => ({ ...p }));
    const daily = dailySeries(txs, monthStart(today), today).map((p) => ({ ...p }));
    const weekly = weeklySeries(txs, 8, today).map((p) => ({ ...p }));
    const from60 = addDays(today, -59) < s.windowStart ? s.windowStart : addDays(today, -59);
    const bal = balanceSeries(s, from60, today).map((p) => ({ ...p }));
    const month = summarize(txs, monthStart(today), today);
    const goals = s.goals.filter((g) => g.status === "active").map((g) => goalMetrics(g, s.contributions, today, Math.max(0, position.savingCapacity - position.committedToGoals)));
    return { six, twelve, daily, weekly, bal, month, goals };
  }, [s, today, position]);
  const sourceColor = sourceColorFor(incomeSources(s.categories));
  const budgetRows = budget.rows.filter((r) => r.budget > 0).slice(0, 6);
  const from60 = c.bal[0]?.key;

  return (
    <div className="grid gap-4 lg:grid-cols-2">
      <ChartBox title="Income vs expenses" hint="Last 6 months" table={{ columns: ["Month", "Received", "Spent", "Saved"], rows: c.six.map((p) => [p.label, p.income, p.expense, p.net]) }}>
        <BarsChart data={c.six} xKey="label" series={[INC, EXP]} />
      </ChartBox>

      <ChartBox title="Spending by category" hint="This month so far" table={{ columns: ["Category", "Spent"], rows: c.month.byCategory.map((b) => [b.name, b.amount]) }}>
        <Donut data={c.month.byCategory.map((b) => ({ name: b.name, value: b.amount }))} centerLabel={<><span className="text-xs text-muted">Spent</span><span className="text-sm font-semibold">{formatINR(c.month.grossSpent)}</span></>} />
      </ChartBox>

      <ChartBox title="Daily spending" hint="This month, day by day" table={{ columns: ["Day", "Spent"], rows: c.daily.filter((p) => p.expense).map((p) => [p.label, p.expense]) }}>
        <BarsChart data={c.daily} xKey="label" series={[EXP]} height={200} />
      </ChartBox>

      <ChartBox title="Weekly spending" hint="Last 8 weeks (Mon–Sun)" table={{ columns: ["Week of", "Spent"], rows: c.weekly.map((p) => [p.label, p.expense]) }}>
        <BarsChart data={c.weekly} xKey="label" series={[EXP]} height={200} />
      </ChartBox>

      <ChartBox title="Monthly spending trend" hint="Last 12 months" table={{ columns: ["Month", "Spent"], rows: c.twelve.map((p) => [p.label, p.expense]) }}>
        <LinesChart data={c.twelve} xKey="label" series={[EXP]} height={200} />
      </ChartBox>

      <ChartBox title="Balance trend" hint={from60 ? `End-of-day balance since ${fmtDate(from60)}` : "End-of-day balance"} table={{ columns: ["Day", "Balance"], rows: c.bal.filter((_, i) => i % 7 === 0 || i === c.bal.length - 1).map((p) => [p.label, p.balance]) }}>
        <LinesChart data={c.bal} xKey="label" series={[{ key: "balance", label: "Balance", color: COLORS.saved }]} height={200} area />
      </ChartBox>

      <Card>
        <CardTitle
          hint="This month, most-used first"
          action={
            <Link href="/budget" className="text-xs text-brand hover:underline">
              {budget.hasBudget ? "Edit" : "Set budget"}
            </Link>
          }
        >
          Budget usage
        </CardTitle>
        {budgetRows.length === 0 ? (
          <p className="py-6 text-center text-sm text-muted">
            No budget for this month yet. <Link href="/budget" className="text-brand hover:underline">Create one</Link> to see how each category is tracking.
          </p>
        ) : (
          <ul className="space-y-3">
            {budgetRows.map((r) => (
              <li key={r.category}>
                <div className="mb-1 flex justify-between gap-2 text-sm">
                  <span className="truncate text-ink-2">{r.category}</span>
                  <span className="tabular shrink-0">
                    <Money value={r.spent} /> <span className="text-xs text-muted">/ {formatINR(r.budget)}</span>
                  </span>
                </div>
                <Progress value={r.usedPct ?? 0} tone={r.state === "over" ? "bad" : r.state === "near" ? "warn" : "good"} label={`${r.category} budget used`} />
              </li>
            ))}
          </ul>
        )}
      </Card>

      <Card>
        <CardTitle
          hint="Active goals"
          action={
            <Link href="/goals" className="text-xs text-brand hover:underline">
              All goals
            </Link>
          }
        >
          Goal progress
        </CardTitle>
        {c.goals.length === 0 ? (
          <p className="py-6 text-center text-sm text-muted">
            No active goals. <Link href="/goals" className="text-brand hover:underline">Create a goal</Link> — a laptop, a trip, an emergency fund.
          </p>
        ) : (
          <ul className="space-y-3">
            {c.goals.slice(0, 5).map((m) => (
              <li key={m.goal.id}>
                <div className="mb-1 flex items-center justify-between gap-2 text-sm">
                  <span className="flex min-w-0 items-center gap-2">
                    <span className="truncate text-ink-2">{m.goal.name}</span>
                    <Badge tone={goalTone[m.status] === "brand" ? "neutral" : goalTone[m.status]}>{m.status.replace("_", " ")}</Badge>
                  </span>
                  <span className="tabular shrink-0">
                    <Money value={m.goal.current_amount} /> <span className="text-xs text-muted">/ {formatINR(m.goal.target_amount)}</span>
                  </span>
                </div>
                <Progress value={m.progressPct} tone={goalTone[m.status]} label={`${m.goal.name} progress`} />
              </li>
            ))}
          </ul>
        )}
      </Card>

      <ChartBox title="Where your money came from" hint="Income sources this month" table={{ columns: ["Source", "Received"], rows: c.month.bySource.map((b) => [b.name, b.amount]) }} className="lg:col-span-2">
        <Donut data={c.month.bySource.map((b) => ({ name: b.name, value: b.amount }))} colorFor={sourceColor} height={170} />
      </ChartBox>
    </div>
  );
}


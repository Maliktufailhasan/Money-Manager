"use client";
import { useState } from "react";
import { Button, Card, CardTitle, MoneyInput, useToast } from "@/components/ui";
import { updateProfile } from "@/lib/client/api";
import { formatINR } from "@/lib/finance";

/** Inline editor for profile.daily_limit. */
export function DailyLimitControl({ current, suggested }: { current: number | null; suggested: number }) {
  const toast = useToast();
  const [value, setValue] = useState(current ? String(current) : "");
  const [saving, setSaving] = useState<"save" | "clear" | null>(null);
  const n = Number(value);
  const valid = value !== "" && Number.isFinite(n) && n > 0;

  async function save(limit: number | null) {
    setSaving(limit === null ? "clear" : "save");
    try {
      await updateProfile({ daily_limit: limit });
      if (limit === null) setValue("");
      toast(limit === null ? "Daily limit removed — using the suggested amount." : `Daily limit set to ${formatINR(limit)}.`);
    } catch (e) {
      toast(e instanceof Error ? e.message : "Couldn't save", "bad");
    } finally {
      setSaving(null);
    }
  }

  return (
    <Card>
      <CardTitle hint={current ? `Currently ${formatINR(current)} per day` : suggested > 0 ? `Not set — we suggest ${formatINR(suggested)}/day from your safe-to-spend` : "Not set yet"}>
        Your daily limit
      </CardTitle>
      <form
        className="flex gap-2"
        onSubmit={(e) => {
          e.preventDefault();
          if (valid) save(Math.round(n));
        }}
      >
        <div className="flex-1">
          <MoneyInput value={value} onChange={setValue} placeholder={suggested > 0 ? String(suggested) : "e.g. 300"} aria-label="Daily limit in rupees" />
        </div>
        <Button type="submit" disabled={!valid || Math.round(n) === current} loading={saving === "save"}>
          Save
        </Button>
        {current !== null && (
          <Button type="button" variant="ghost" onClick={() => save(null)} loading={saving === "clear"}>
            Clear
          </Button>
        )}
      </form>
      {!current && suggested > 0 && (
        <button type="button" className="mt-2 text-xs text-brand hover:underline" onClick={() => setValue(String(suggested))}>
          Use suggested {formatINR(suggested)}
        </button>
      )}
    </Card>
  );
}

"use client";
import { CalendarClock, Info, PiggyBank, Receipt, ShoppingBag, TrendingDown, TrendingUp, Wallet } from "lucide-react";
import Link from "next/link";
import { useState } from "react";
import { Card, CardTitle, Money, SourceTag, Stat } from "@/components/ui";
import type { FinanceData } from "@/lib/client/useFinance";
import { addDays, fmtDate, formatINR, formatPct, monthStart, spentOn, summarize, totalDue, upcomingPayments, weekStart } from "@/lib/finance";

export function MoneyTiles({ data }: { data: FinanceData }) {
  const { s, today, balance, budget } = data;
  const month = summarize(s.transactions, monthStart(today), today);
  const todaySpent = spentOn(s.transactions, today, today);
  const weekSpent = spentOn(s.transactions, weekStart(today), today);
  const [showHow, setShowHow] = useState(false);

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-3 sm:gap-4 lg:grid-cols-4">
        <Stat label="Current balance" value={<Money value={balance} />} tone={balance < 0 ? "bad" : undefined} icon={<Wallet className="size-4" />} sub="Opening balance + all income − all expenses" />
        <Stat label="Received this month" value={<Money value={month.received} />} icon={<TrendingUp className="size-4" />} sub={`${month.incomeCount} entr${month.incomeCount === 1 ? "y" : "ies"}`} />
        <Stat label="Spent this month" value={<Money value={month.spent} />} icon={<TrendingDown className="size-4" />} sub={`${month.expenseCount} expense${month.expenseCount === 1 ? "" : "s"}${month.refunds ? `, net of ${formatINR(month.refunds)} refunds` : ""}`} />
        <Stat label="Saved this month" value={<Money value={month.saved} />} tone={month.saved < 0 ? "bad" : month.saved > 0 ? "good" : undefined} icon={<PiggyBank className="size-4" />} sub="Received − spent" />
        <Stat label="Savings rate" value={formatPct(month.savingsRate, 0)} tone={month.savingsRate === null ? undefined : month.savingsRate >= 20 ? "good" : month.savingsRate < 0 ? "bad" : "warn"} sub={month.savingsRate === null ? "No income recorded this month" : "Share of this month's income kept"} />
        <Stat
          label="Today's spending"
          value={<Money value={todaySpent} />}
          tone={data.dailyTarget && todaySpent > data.dailyTarget ? "bad" : undefined}
          icon={<ShoppingBag className="size-4" />}
          sub={
            <Link href="/daily" className="hover:text-brand">
              {data.dailyTarget ? `Target ${formatINR(data.dailyTarget)} →` : "Open daily tracker →"}
            </Link>
          }
        />
        <Stat label="This week's spending" value={<Money value={weekSpent} />} icon={<Receipt className="size-4" />} sub={`Since Mon ${fmtDate(weekStart(today))}`} />
        {budget.hasBudget ? (
          <Stat
            label="Budget left this month"
            value={<Money value={budget.remaining} />}
            tone={budget.remaining < 0 ? "bad" : (budget.usedPct ?? 0) >= 80 ? "warn" : "good"}
            sub={
              <Link href="/budget" className="hover:text-brand">
                {formatPct(budget.usedPct, 0)} of {formatINR(budget.totalBudget)} used →
              </Link>
            }
          />
        ) : (
          <div className="flex flex-col justify-between rounded-2xl border border-dashed border-line p-4">
            <span className="text-xs font-medium text-muted">Remaining monthly budget</span>
            <Link href="/budget" className="mt-2 text-sm font-semibold text-brand hover:underline">
              Set a budget →
            </Link>
            <span className="mt-1 text-xs text-muted">Know what&apos;s left for the month</span>
          </div>
        )}
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        <SafeToSpendCard data={data} showHow={showHow} onToggle={() => setShowHow((v) => !v)} />
        <UpcomingCard data={data} />
      </div>
    </div>
  );
}

function SafeToSpendCard({ data, showHow, onToggle }: { data: FinanceData; showHow: boolean; onToggle: () => void }) {
  const { sts } = data;
  return (
    <Card>
      <CardTitle
        hint={`For each of the ${sts.daysLeft} day${sts.daysLeft === 1 ? "" : "s"} left this month`}
        action={
          <button type="button" onClick={onToggle} className="flex items-center gap-1 text-xs text-muted hover:text-ink" aria-expanded={showHow}>
            <Info className="size-3.5" /> How?
          </button>
        }
      >
        Safe to spend today
      </CardTitle>
      <div className="flex items-baseline gap-2">
        <span className={sts.daily > 0 ? "text-3xl font-semibold tracking-tight text-brand" : "text-3xl font-semibold tracking-tight text-bad"}>
          <Money value={sts.daily} />
        </span>
        <span className="text-sm text-muted">/ day</span>
        <SourceTag kind="calculated" />
      </div>
      <p className="mt-1 text-xs text-muted">
        About <Money value={sts.weekly} /> over the next {Math.min(7, sts.daysLeft)} days{sts.limitedBy === "budget" ? " · limited by your budget" : ""}.
      </p>
      {showHow && (
        <div className="mt-3 space-y-1 rounded-xl bg-surface-2 p-3 text-xs">
          <Row label="Current balance" value={sts.balance} />
          <Row label="− Bills & subscriptions due this month" value={-sts.upcomingThisMonth} />
          <Row label="− Savings target still to set aside" value={-sts.savingsStillToSet} />
          <Row label="= Available" value={sts.available} strong />
          <p className="pt-1 text-muted">
            Divided by {sts.daysLeft} days left{sts.remainingBudget !== null ? `, then capped by the budget left (${formatINR(sts.remainingBudget)} minus upcoming bills)` : ""}. Rounded down.
          </p>
        </div>
      )}
    </Card>
  );
}

function Row({ label, value, strong }: { label: string; value: number; strong?: boolean }) {
  return (
    <div className={strong ? "flex justify-between border-t border-line pt-1 font-semibold" : "flex justify-between text-ink-2"}>
      <span>{label}</span>
      <Money value={value} />
    </div>
  );
}

function UpcomingCard({ data }: { data: FinanceData }) {
  const { s, today } = data;
  const list = upcomingPayments(s, today, addDays(today, 14));
  return (
    <Card>
      <CardTitle
        hint="Bills and subscriptions in the next 14 days"
        action={
          <Link href="/bills" className="text-xs text-brand hover:underline">
            Manage
          </Link>
        }
      >
        Upcoming planned expenses
      </CardTitle>
      {list.length === 0 ? (
        <p className="py-4 text-center text-sm text-muted">
          Nothing scheduled. <Link href="/bills" className="text-brand hover:underline">Add a bill reminder</Link>
        </p>
      ) : (
        <>
          <ul className="divide-y divide-line">
            {list.slice(0, 5).map((p) => (
              <li key={p.key} className="flex items-center justify-between gap-3 py-2 text-sm">
                <span className="flex min-w-0 items-center gap-2">
                  <CalendarClock className="size-4 shrink-0 text-muted" />
                  <span className="truncate">{p.title}</span>
                </span>
                <span className="flex shrink-0 items-center gap-2">
                  <span className={p.daysAway < 0 ? "text-xs text-bad" : p.daysAway <= 2 ? "text-xs text-warn" : "text-xs text-muted"}>
                    {p.daysAway < 0 ? `${-p.daysAway}d overdue` : p.daysAway === 0 ? "Today" : p.daysAway === 1 ? "Tomorrow" : fmtDate(p.date)}
                  </span>
                  <Money value={p.amount} className="font-medium" />
                </span>
              </li>
            ))}
          </ul>
          <div className="mt-2 flex justify-between border-t border-line pt-2 text-sm font-semibold">
            <span>Total{list.length > 5 ? ` (${list.length} items)` : ""}</span>
            <Money value={totalDue(list)} />
          </div>
        </>
      )}
    </Card>
  );
}

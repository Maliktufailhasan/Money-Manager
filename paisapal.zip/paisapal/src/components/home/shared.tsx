"use client";
import { ChevronLeft, ChevronRight, Copy, Pencil, Trash2 } from "lucide-react";
import { useState, type ReactNode } from "react";
import { useQuickAdd } from "@/components/AppShell";
import { IconButton, cn, confirmAction, useToast } from "@/components/ui";
import { db } from "@/lib/client/api";
import { formatINR } from "@/lib/finance";
import type { Transaction } from "@/lib/types";

/** Edit / duplicate / delete buttons for one transaction. */
export function TxActions({ tx, compact }: { tx: Transaction; compact?: boolean }) {
  const quick = useQuickAdd();
  const toast = useToast();
  const [busy, setBusy] = useState(false);

  async function remove() {
    if (!confirmAction(`Delete this ${tx.type} of ${formatINR(tx.amount)}${tx.description ? ` (${tx.description})` : ""}?`)) return;
    setBusy(true);
    try {
      await db.remove("transactions", tx.id);
      toast("Transaction deleted");
    } catch (e) {
      toast(e instanceof Error ? e.message : "Couldn't delete", "bad");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className={cn("flex items-center", compact ? "gap-0" : "gap-0.5")}>
      <IconButton label="Edit" onClick={() => quick.open({ edit: tx })}>
        <Pencil className="size-3.5" />
      </IconButton>
      <IconButton label="Duplicate" onClick={() => quick.open({ duplicate: tx })}>
        <Copy className="size-3.5" />
      </IconButton>
      <IconButton label="Delete" onClick={remove} disabled={busy} className="hover:text-bad">
        <Trash2 className="size-3.5" />
      </IconButton>
    </div>
  );
}

/** Signed, coloured amount: +₹ for income, −₹ for expenses. */
export function TxAmount({ tx, className }: { tx: Pick<Transaction, "type" | "amount">; className?: string }) {
  const income = tx.type === "income";
  return <span className={cn("tabular font-semibold whitespace-nowrap", income ? "text-good" : "text-ink", className)}>{income ? "+" : "−"}{formatINR(tx.amount)}</span>;
}

export function txTitle(t: Transaction): string {
  return t.description || t.merchant || (t.subcategory ? `${t.category} · ${t.subcategory}` : t.category);
}

/** Prev / label / next switcher used by month & day pickers. */
export function PeriodSwitcher({ label, onPrev, onNext, prevDisabled, nextDisabled, children }: { label: ReactNode; onPrev: () => void; onNext: () => void; prevDisabled?: boolean; nextDisabled?: boolean; children?: ReactNode }) {
  return (
    <div className="flex items-center gap-1 rounded-xl border border-line bg-surface p-1">
      <IconButton label="Previous" onClick={onPrev} disabled={prevDisabled} className="disabled:opacity-30">
        <ChevronLeft className="size-4" />
      </IconButton>
      <div className="min-w-28 px-1 text-center text-sm font-medium">{label}</div>
      {children}
      <IconButton label="Next" onClick={onNext} disabled={nextDisabled} className="disabled:opacity-30">
        <ChevronRight className="size-4" />
      </IconButton>
    </div>
  );
}

/** Change vs. a previous value, coloured by whether the change is good. */
export function Delta({ now, before, higherIsGood }: { now: number; before: number; higherIsGood: boolean }) {
  const diff = Math.round(now - before);
  if (!before && !now) return <span className="text-xs text-muted">—</span>;
  if (diff === 0) return <span className="text-xs text-muted">same as last month</span>;
  const good = diff > 0 === higherIsGood;
  const p = before ? Math.round((Math.abs(diff) / Math.abs(before)) * 100) : null;
  return (
    <span className={cn("text-xs font-medium", good ? "text-good" : "text-bad")}>
      {diff > 0 ? "▲" : "▼"} {formatINR(Math.abs(diff))}
      {p !== null && ` (${p}%)`} vs last month
    </span>
  );
}

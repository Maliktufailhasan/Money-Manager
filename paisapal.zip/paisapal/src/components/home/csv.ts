import { api } from "@/lib/client/api";
import type { Transaction } from "@/lib/types";

const MAX_ROWS = 5000;
const PAGE = 200; // API maximum page size

/** Escape one CSV cell (RFC 4180) and neutralise spreadsheet formulas in text fields. */
export function csvCell(v: unknown): string {
  if (v === null || v === undefined) return "";
  let s = String(v);
  if (typeof v === "string" && /^[=+\-@\t\r]/.test(s)) s = `'${s}`;
  return /[",\r\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
}

const COLUMNS: [string, (t: Transaction) => unknown][] = [
  ["Date", (t) => t.date],
  ["Time", (t) => t.time?.slice(0, 5) ?? ""],
  ["Type", (t) => t.type],
  ["Category", (t) => t.category],
  ["Subcategory", (t) => t.subcategory],
  ["Description", (t) => t.description],
  ["Merchant", (t) => t.merchant],
  ["Payment method", (t) => t.payment_method],
  ["Need/Want", (t) => t.need_or_want],
  ["Essential", (t) => (t.essential === null ? "" : t.essential ? "yes" : "no")],
  ["Recurring", (t) => (t.recurring ? "yes" : "no")],
  ["Amount (INR)", (t) => t.amount],
  ["Signed amount (INR)", (t) => (t.type === "income" ? t.amount : -t.amount)],
  ["Notes", (t) => t.notes],
];

export function toCsv(rows: Transaction[]): string {
  const lines = [COLUMNS.map(([h]) => csvCell(h)).join(",")];
  for (const t of rows) lines.push(COLUMNS.map(([, f]) => csvCell(f(t))).join(","));
  return lines.join("\r\n");
}

/** Fetch every page of the filtered result set (capped at 5000 rows). */
export async function fetchAllTransactions(params: URLSearchParams): Promise<{ rows: Transaction[]; total: number; capped: boolean }> {
  const out: Transaction[] = [];
  let total = 0;
  for (let page = 1; out.length < MAX_ROWS; page++) {
    const p = new URLSearchParams(params);
    p.set("page", String(page));
    p.set("pageSize", String(PAGE));
    const res = await api<{ rows: Transaction[]; total: number }>(`/api/data/transactions?${p}`);
    total = res.total;
    out.push(...res.rows);
    if (res.rows.length < PAGE || out.length >= total) break;
  }
  return { rows: out.slice(0, MAX_ROWS), total, capped: total > MAX_ROWS };
}

export function downloadText(filename: string, text: string, mime = "text/csv;charset=utf-8") {
  // BOM so Excel opens the ₹ / non-ASCII text correctly
  const blob = new Blob(["﻿", text], { type: mime });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

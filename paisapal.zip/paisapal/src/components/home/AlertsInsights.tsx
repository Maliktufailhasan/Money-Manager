"use client";
import { AlertTriangle, Award, Bell, CalendarCheck, Flame, Info, Lightbulb, PiggyBank, ShieldCheck, ThumbsUp } from "lucide-react";
import Link from "next/link";
import { useMemo } from "react";
import { Card, CardTitle, SourceTag, cn } from "@/components/ui";
import type { FinanceData } from "@/lib/client/useFinance";
import { generateInsights, streaks } from "@/lib/finance";

export function AlertsInsights({ data }: { data: FinanceData }) {
  const { s, today, position, alerts } = data;
  const insights = useMemo(() => generateInsights(s, today, position).slice(0, 3), [s, today, position]);
  const top = alerts.slice(0, 3);

  return (
    <div className="grid gap-4 lg:grid-cols-2">
      <Card>
        <CardTitle
          action={
            <Link href="/alerts" className="text-xs text-brand hover:underline">
              All alerts{alerts.length > 3 ? ` (${alerts.length})` : ""}
            </Link>
          }
        >
          Alerts
        </CardTitle>
        {top.length === 0 ? (
          <p className="flex items-center gap-2 py-3 text-sm text-muted">
            <ShieldCheck className="size-4 text-good" /> All clear — nothing needs your attention.
          </p>
        ) : (
          <ul className="space-y-2">
            {top.map((a) => (
              <li key={a.id}>
                <Link
                  href={a.href ?? "/alerts"}
                  className={cn(
                    "flex items-start gap-2 rounded-xl px-3 py-2 text-sm hover:opacity-90",
                    a.level === "danger" ? "bg-bad-soft text-bad" : a.level === "warning" ? "bg-warn-soft text-warn" : "bg-surface-2 text-ink-2",
                  )}
                >
                  {a.level === "info" ? <Bell className="mt-0.5 size-4 shrink-0" /> : <AlertTriangle className="mt-0.5 size-4 shrink-0" />}
                  <span>{a.text}</span>
                </Link>
              </li>
            ))}
          </ul>
        )}
      </Card>

      <Card>
        <CardTitle
          action={
            <Link href="/insights" className="text-xs text-brand hover:underline">
              More insights
            </Link>
          }
        >
          Insights
        </CardTitle>
        {insights.length === 0 ? (
          <p className="py-3 text-sm text-muted">Insights appear once you have a few transactions recorded.</p>
        ) : (
          <ul className="space-y-2.5">
            {insights.map((i) => (
              <li key={i.id} className="flex items-start gap-2 text-sm">
                {i.tone === "positive" ? <ThumbsUp className="mt-0.5 size-4 shrink-0 text-good" /> : i.tone === "warning" ? <AlertTriangle className="mt-0.5 size-4 shrink-0 text-warn" /> : <Lightbulb className="mt-0.5 size-4 shrink-0 text-brand" />}
                <span className="flex-1">
                  {i.text} <SourceTag kind={i.basis} />
                </span>
              </li>
            ))}
          </ul>
        )}
      </Card>
    </div>
  );
}

export function StreakChips({ data }: { data: FinanceData }) {
  const { s, today } = data;
  const st = useMemo(() => streaks(s.transactions, s.goals, today, s.profile.daily_limit, s.totals.first_date), [s, today]);
  if (s.profile.preferences?.gamification === false) return null;
  const chips: { icon: React.ReactNode; text: string }[] = [];
  if (st.trackingDays > 0) chips.push({ icon: <Flame className="size-3.5" />, text: `${st.trackingDays}-day tracking streak` });
  if (st.noSpendDaysThisMonth > 0) chips.push({ icon: <CalendarCheck className="size-3.5" />, text: `${st.noSpendDaysThisMonth} no-spend day${st.noSpendDaysThisMonth === 1 ? "" : "s"} this month` });
  if (st.underLimitDays) chips.push({ icon: <ShieldCheck className="size-3.5" />, text: `${st.underLimitDays} day${st.underLimitDays === 1 ? "" : "s"} under daily limit` });
  if (st.savingsMonths > 0) chips.push({ icon: <PiggyBank className="size-3.5" />, text: `${st.savingsMonths} month${st.savingsMonths === 1 ? "" : "s"} of saving in a row` });
  if (st.milestones[0]) chips.push({ icon: <Award className="size-3.5" />, text: `${st.milestones[0].goal}: ${st.milestones[0].pct}% reached` });
  if (!chips.length) return null;
  return (
    <div className="flex flex-wrap gap-2" aria-label="Streaks">
      {chips.map((c) => (
        <span key={c.text} className="inline-flex items-center gap-1.5 rounded-full bg-brand-soft px-3 py-1 text-xs font-medium text-brand">
          {c.icon}
          {c.text}
        </span>
      ))}
      <span className="inline-flex items-center gap-1 px-1 text-[11px] text-muted">
        <Info className="size-3" /> from your records
      </span>
    </div>
  );
}

"use client";
import { RotateCcw } from "lucide-react";
import { Button, Chip, Field, Input, MoneyInput, Select } from "@/components/ui";
import { PAYMENT_METHODS } from "@/lib/constants";
import { addMonths, monthEnd, monthStart, weekStart } from "@/lib/finance";

export type Preset = "all" | "today" | "week" | "month" | "last" | "custom";

export interface TxFilterState {
  preset: Preset;
  from: string;
  to: string;
  type: "" | "income" | "expense";
  category: string;
  payment_method: string;
  need_or_want: "" | "need" | "want";
  essential: "" | "true" | "false";
  min: string;
  max: string;
  merchant: string;
  sort: "date" | "amount";
  dir: "asc" | "desc";
}

export const EMPTY_FILTERS: TxFilterState = { preset: "all", from: "", to: "", type: "", category: "", payment_method: "", need_or_want: "", essential: "", min: "", max: "", merchant: "", sort: "date", dir: "desc" };

const PRESETS: { value: Preset; label: string }[] = [
  { value: "all", label: "All time" },
  { value: "today", label: "Today" },
  { value: "week", label: "This week" },
  { value: "month", label: "This month" },
  { value: "last", label: "Last month" },
  { value: "custom", label: "Custom" },
];

export function presetRange(p: Preset, today: string, custom: { from: string; to: string }): { from: string; to: string } {
  switch (p) {
    case "today":
      return { from: today, to: today };
    case "week":
      return { from: weekStart(today), to: today };
    case "month":
      return { from: monthStart(today), to: today };
    case "last": {
      const m = addMonths(monthStart(today), -1);
      return { from: m, to: monthEnd(m) };
    }
    case "custom":
      return custom;
    default:
      return { from: "", to: "" };
  }
}

/** Number of non-default filters (excluding search and sort). */
export function activeCount(f: TxFilterState): number {
  return (["type", "category", "payment_method", "need_or_want", "essential", "min", "max", "merchant"] as const).filter((k) => f[k]).length + (f.preset !== "all" ? 1 : 0);
}

export function TxFilters({ value, onChange, categories, incomeCats, advanced }: { value: TxFilterState; onChange: (f: TxFilterState) => void; categories: string[]; incomeCats: string[]; advanced: boolean }) {
  const set = <K extends keyof TxFilterState>(k: K, v: TxFilterState[K]) => onChange({ ...value, [k]: v });
  const catOptions = value.type === "income" ? incomeCats : value.type === "expense" ? categories : [...categories, ...incomeCats.filter((c) => !categories.includes(c))];

  return (
    <div className="space-y-3">
      <div className="-mx-1 flex gap-1.5 overflow-x-auto px-1 pb-1">
        {PRESETS.map((p) => (
          <Chip key={p.value} active={value.preset === p.value} onClick={() => set("preset", p.value)} className="shrink-0">
            {p.label}
          </Chip>
        ))}
      </div>
      {value.preset === "custom" && (
        <div className="grid grid-cols-2 gap-3 sm:max-w-md">
          <Field label="From">{(id) => <Input id={id} type="date" value={value.from} max={value.to || undefined} onChange={(e) => set("from", e.target.value)} />}</Field>
          <Field label="To">{(id) => <Input id={id} type="date" value={value.to} min={value.from || undefined} onChange={(e) => set("to", e.target.value)} />}</Field>
        </div>
      )}
      {advanced && (
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-5">
        <Field label="Type">
          {(id) => (
            <Select id={id} value={value.type} onChange={(e) => onChange({ ...value, type: e.target.value as TxFilterState["type"], category: "" })}>
              <option value="">All</option>
              <option value="income">Income</option>
              <option value="expense">Expense</option>
            </Select>
          )}
        </Field>
        <Field label="Category">
          {(id) => (
            <Select id={id} value={value.category} onChange={(e) => set("category", e.target.value)}>
              <option value="">All</option>
              {catOptions.map((c) => (
                <option key={c} value={c}>
                  {c}
                </option>
              ))}
            </Select>
          )}
        </Field>
        <Field label="Payment">
          {(id) => (
            <Select id={id} value={value.payment_method} onChange={(e) => set("payment_method", e.target.value)}>
              <option value="">All</option>
              {PAYMENT_METHODS.map((c) => (
                <option key={c} value={c}>
                  {c}
                </option>
              ))}
            </Select>
          )}
        </Field>
        <Field label="Need / want">
          {(id) => (
            <Select id={id} value={value.need_or_want} onChange={(e) => set("need_or_want", e.target.value as TxFilterState["need_or_want"])}>
              <option value="">All</option>
              <option value="need">Need</option>
              <option value="want">Want</option>
            </Select>
          )}
        </Field>
        <Field label="Essential">
          {(id) => (
            <Select id={id} value={value.essential} onChange={(e) => set("essential", e.target.value as TxFilterState["essential"])}>
              <option value="">All</option>
              <option value="true">Essential</option>
              <option value="false">Non-essential</option>
            </Select>
          )}
        </Field>
        <Field label="Merchant">{(id) => <Input id={id} value={value.merchant} placeholder="e.g. Swiggy" onChange={(e) => set("merchant", e.target.value)} />}</Field>
        <Field label="Min amount">{(id) => <MoneyInput id={id} value={value.min} onChange={(v) => set("min", v)} placeholder="0" />}</Field>
        <Field label="Max amount">{(id) => <MoneyInput id={id} value={value.max} onChange={(v) => set("max", v)} placeholder="Any" />}</Field>
        <Field label="Sort by">
          {(id) => (
            <Select id={id} value={`${value.sort}-${value.dir}`} onChange={(e) => { const [sort, dir] = e.target.value.split("-") as [TxFilterState["sort"], TxFilterState["dir"]]; onChange({ ...value, sort, dir }); }}>
              <option value="date-desc">Newest first</option>
              <option value="date-asc">Oldest first</option>
              <option value="amount-desc">Largest amount</option>
              <option value="amount-asc">Smallest amount</option>
            </Select>
          )}
        </Field>
        <div className="flex items-end">
          <Button variant="ghost" size="md" className="w-full" onClick={() => onChange(EMPTY_FILTERS)} disabled={activeCount(value) === 0 && value.sort === "date" && value.dir === "desc"}>
            <RotateCcw className="size-4" /> Reset
          </Button>
        </div>
      </div>
      )}
    </div>
  );
}

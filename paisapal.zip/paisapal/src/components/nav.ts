import {
  BarChart3, Bell, Bot, CalendarDays, CalendarRange, CreditCard, FileText, Gauge, Home, Lightbulb, ListOrdered, PiggyBank, Repeat, Settings, ShieldBan, Sun, Target, Wallet, Wand2,
} from "lucide-react";

export const NAV = [
  { href: "/", label: "Dashboard", icon: Home },
  { href: "/transactions", label: "Transactions", icon: ListOrdered },
  { href: "/daily", label: "Today", icon: Sun },
  { href: "/monthly", label: "Monthly", icon: CalendarRange },
  { href: "/budget", label: "Budget", icon: Gauge },
  { href: "/goals", label: "Goals", icon: Target },
  { href: "/planner", label: "Planner", icon: Wand2 },
  { href: "/savings", label: "Savings", icon: PiggyBank },
  { href: "/earn", label: "Earn", icon: Wallet },
  { href: "/insights", label: "Insights", icon: Lightbulb },
  { href: "/assistant", label: "AI Assistant", icon: Bot },
  { href: "/dont-spend", label: "Don't Spend", icon: ShieldBan },
  { href: "/subscriptions", label: "Subscriptions", icon: CreditCard },
  { href: "/bills", label: "Bills & Recurring", icon: Repeat },
  { href: "/calendar", label: "Calendar", icon: CalendarDays },
  { href: "/reports", label: "Reports", icon: FileText },
  { href: "/health", label: "Financial Health", icon: BarChart3 },
  { href: "/alerts", label: "Alerts", icon: Bell },
  { href: "/settings", label: "Settings", icon: Settings },
] as const;

export const BOTTOM_NAV = [
  { href: "/", label: "Home", icon: Home },
  { href: "/transactions", label: "Transactions", icon: ListOrdered },
  { href: "/goals", label: "Goals", icon: Target },
  { href: "/insights", label: "Insights", icon: Lightbulb },
  { href: "/more", label: "More", icon: Settings },
] as const;

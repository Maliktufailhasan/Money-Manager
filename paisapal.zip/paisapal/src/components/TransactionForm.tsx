"use client";
import { ChevronDown, ChevronUp } from "lucide-react";
import { useMemo, useState } from "react";
import { INCOME_TYPES, PAYMENT_METHODS, QUICK_AMOUNTS, defaultNeedOrWant } from "@/lib/constants";
import { budgetReport, fmtDate, nowTimeHM, todayISO, violatedRules, ym } from "@/lib/finance";
import { ApiError, db } from "@/lib/client/api";
import { expenseCategories, incomeSources } from "@/lib/client/categories";
import type { Snapshot, Transaction, TxType } from "@/lib/types";
import { Button, Chip, Field, Input, MoneyInput, Segmented, Select, Textarea, Toggle, cn, useToast } from "./ui";

export interface TxDraft {
  type: TxType;
  amount: string;
  category: string;
  subcategory: string;
  date: string;
  time: string;
  merchant: string;
  payment_method: string;
  description: string;
  need_or_want: "need" | "want" | "";
  essential: boolean | null;
  recurring: boolean;
  recurrence: string;
  income_type: string;
  earning_source_id: string;
  notes: string;
}

export function draftFrom(tx?: Partial<Transaction> | null, type: TxType = "expense", keepDate = true): TxDraft {
  return {
    type: tx?.type ?? type,
    amount: tx?.amount ? String(tx.amount) : "",
    category: tx?.category ?? "",
    subcategory: tx?.subcategory ?? "",
    date: keepDate && tx?.date ? tx.date : todayISO(),
    time: keepDate && tx?.time ? tx.time.slice(0, 5) : nowTimeHM(),
    merchant: tx?.merchant ?? "",
    payment_method: tx?.payment_method ?? "UPI",
    description: tx?.description ?? "",
    need_or_want: tx?.need_or_want ?? "",
    essential: tx?.essential ?? null,
    recurring: tx?.recurring ?? false,
    recurrence: tx?.recurrence ?? "monthly",
    income_type: tx?.income_type ?? "",
    earning_source_id: tx?.earning_source_id ?? "",
    notes: tx?.notes ?? "",
  };
}

/**
 * Add / edit / duplicate a transaction. The fast path is amount → category
 * → Save; everything else lives under "More details".
 */
export function TransactionForm({ snapshot, initial, editId, onDone, compact }: { snapshot: Snapshot; initial?: TxDraft; editId?: string; onDone: (saved: Transaction) => void; compact?: boolean }) {
  const toast = useToast();
  const [d, setD] = useState<TxDraft>(initial ?? draftFrom(null));
  const [more, setMore] = useState(!compact || Boolean(editId));
  const [saving, setSaving] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const set = <K extends keyof TxDraft>(k: K, v: TxDraft[K]) => setD((p) => ({ ...p, [k]: v }));

  const cats = useMemo(() => expenseCategories(snapshot.categories), [snapshot.categories]);
  const sources = useMemo(() => incomeSources(snapshot.categories), [snapshot.categories]);
  const isExpense = d.type === "expense";
  const subs = isExpense && d.category ? cats[d.category] ?? [] : [];
  const nw = d.need_or_want || (isExpense && d.category ? defaultNeedOrWant(d.category, d.subcategory) : "");
  const warnings = isExpense && d.category ? violatedRules(snapshot.noSpendRules, { category: d.category, subcategory: d.subcategory || null, date: d.date }) : [];

  async function save() {
    setErr(null);
    const amount = Number(d.amount);
    if (!amount || amount <= 0) return setErr("Enter an amount");
    if (!d.category) return setErr(isExpense ? "Pick a category" : "Pick where the money came from");
    const body = {
      type: d.type,
      amount,
      category: d.category,
      subcategory: isExpense ? d.subcategory || null : null,
      income_type: !isExpense ? d.income_type || null : null,
      description: d.description || null,
      date: d.date,
      time: d.time || null,
      merchant: d.merchant || null,
      payment_method: d.payment_method || null,
      need_or_want: isExpense ? nw || null : null,
      essential: isExpense ? (d.essential ?? (nw ? nw === "need" : null)) : null,
      recurring: d.recurring,
      recurrence: d.recurring ? d.recurrence : null,
      earning_source_id: !isExpense && d.earning_source_id ? d.earning_source_id : null,
      notes: d.notes || null,
    };
    setSaving(true);
    try {
      const saved = editId ? await db.update<Transaction>("transactions", editId, body) : await db.create<Transaction>("transactions", body);
      toast(editId ? "Transaction updated" : `${isExpense ? "Expense" : "Income"} of ₹${amount.toLocaleString("en-IN")} saved`);
      if (isExpense) {
        for (const r of warnings) toast(`⚠️ You planned to avoid ${r.title.toLowerCase()} until ${fmtDate(r.end_date)}.`, "warn");
        const { year, month } = ym(d.date);
        const line = budgetReport(snapshot.budgets, [...snapshot.transactions.filter((t) => t.id !== editId), { ...(body as unknown as Transaction), id: "new", created_at: "" }], year, month, todayISO()).rows.find((r) => r.category === d.category);
        if (line && (line.state === "near" || line.state === "over")) toast(`⚠️ You have used ${Math.round(line.usedPct ?? 0)}% of your ${d.category.toLowerCase()} budget this month.`, "warn");
      }
      onDone(saved);
    } catch (e) {
      setErr(e instanceof ApiError ? e.message : "Could not save. Check your connection.");
    } finally {
      setSaving(false);
    }
  }

  return (
    <form
      className="space-y-4"
      onSubmit={(e) => {
        e.preventDefault();
        save();
      }}
    >
      <Segmented
        className="w-full [&>button]:flex-1"
        value={d.type}
        onChange={(v) => setD((p) => ({ ...p, type: v, category: "", subcategory: "" }))}
        options={[
          { value: "expense", label: "Expense" },
          { value: "income", label: "Money received" },
        ]}
      />

      <div>
        <MoneyInput aria-label="Amount" autoFocus placeholder="0" value={d.amount} onChange={(v) => set("amount", v)} className="h-14 text-2xl font-semibold" />
        <div className="mt-2 flex flex-wrap gap-1.5">
          {QUICK_AMOUNTS.map((a) => (
            <Chip key={a} active={Number(d.amount) === a} onClick={() => set("amount", String(a))}>
              ₹{a}
            </Chip>
          ))}
        </div>
      </div>

      <div>
        <p className="mb-1.5 text-xs font-medium text-ink-2">{isExpense ? "Category" : "Source"}</p>
        <div className="flex flex-wrap gap-1.5">
          {(isExpense ? Object.keys(cats) : sources).map((c) => (
            <Chip key={c} active={d.category === c} onClick={() => setD((p) => ({ ...p, category: c, subcategory: "", need_or_want: "" }))}>
              {c}
            </Chip>
          ))}
        </div>
      </div>

      {subs.length > 0 && (
        <div>
          <p className="mb-1.5 text-xs font-medium text-ink-2">{d.category} →</p>
          <div className="flex flex-wrap gap-1.5">
            {subs.map((s) => (
              <Chip key={s} active={d.subcategory === s} onClick={() => setD((p) => ({ ...p, subcategory: p.subcategory === s ? "" : s, need_or_want: "" }))}>
                {s}
              </Chip>
            ))}
          </div>
        </div>
      )}

      {warnings.length > 0 && (
        <p className="rounded-xl bg-warn-soft px-3 py-2 text-sm text-warn">
          ⚠️ You planned to avoid {warnings[0].title.toLowerCase()} until {fmtDate(warnings[0].end_date)}.
        </p>
      )}

      <button type="button" className="flex items-center gap-1 text-xs font-medium text-brand" onClick={() => setMore((m) => !m)} aria-expanded={more}>
        {more ? <ChevronUp className="size-3.5" /> : <ChevronDown className="size-3.5" />} More details
      </button>

      {more && (
        <div className="grid grid-cols-2 gap-3">
          <Field label="Date">{(id) => <Input id={id} type="date" value={d.date} max="2100-12-31" onChange={(e) => set("date", e.target.value)} required />}</Field>
          <Field label="Time">{(id) => <Input id={id} type="time" value={d.time} onChange={(e) => set("time", e.target.value)} />}</Field>
          <Field label={isExpense ? "Merchant / place" : "From (person/company)"} className="col-span-2 sm:col-span-1">
            {(id) => <Input id={id} value={d.merchant} maxLength={80} placeholder={isExpense ? "e.g. Canteen, Swiggy" : "e.g. Dad, Internshala"} onChange={(e) => set("merchant", e.target.value)} />}
          </Field>
          <Field label="Payment method" className="col-span-2 sm:col-span-1">
            {(id) => (
              <Select id={id} value={d.payment_method} onChange={(e) => set("payment_method", e.target.value)}>
                <option value="">—</option>
                {PAYMENT_METHODS.map((m) => (
                  <option key={m}>{m}</option>
                ))}
              </Select>
            )}
          </Field>
          <Field label="Description" className="col-span-2">
            {(id) => <Input id={id} value={d.description} maxLength={200} placeholder={isExpense ? "e.g. Lunch with friends" : "e.g. October pocket money"} onChange={(e) => set("description", e.target.value)} />}
          </Field>

          {isExpense ? (
            <>
              <div className="col-span-2">
                <p className="mb-1.5 text-xs font-medium text-ink-2">Need or want?</p>
                <Segmented
                  size="sm"
                  value={(nw || "need") as "need" | "want"}
                  onChange={(v) => setD((p) => ({ ...p, need_or_want: v, essential: v === "need" }))}
                  options={[
                    { value: "need", label: "Need" },
                    { value: "want", label: "Want" },
                  ]}
                />
                <span className="ml-2 text-xs text-muted">{d.need_or_want ? "set by you" : "suggested"}</span>
              </div>
              <div className="col-span-2">
                <Toggle label="Essential" description="Couldn't have skipped this expense" checked={d.essential ?? nw === "need"} onChange={(v) => set("essential", v)} />
              </div>
            </>
          ) : (
            <>
              <Field label="Income type">
                {(id) => (
                  <Select id={id} value={d.income_type} onChange={(e) => set("income_type", e.target.value)}>
                    <option value="">—</option>
                    {INCOME_TYPES.map((m) => (
                      <option key={m}>{m}</option>
                    ))}
                  </Select>
                )}
              </Field>
              <Field label="Side hustle" hint="Counts as actual income">
                {(id) => (
                  <Select id={id} value={d.earning_source_id} onChange={(e) => set("earning_source_id", e.target.value)}>
                    <option value="">None</option>
                    {snapshot.earningSources.map((e) => (
                      <option key={e.id} value={e.id}>
                        {e.source}
                      </option>
                    ))}
                  </Select>
                )}
              </Field>
            </>
          )}

          <div className={cn("col-span-2 flex flex-wrap items-center gap-3")}>
            <div className="flex-1">
              <Toggle label="Recurring" description={isExpense ? "Rent, mess, recharge…" : "Pocket money, stipend…"} checked={d.recurring} onChange={(v) => set("recurring", v)} />
            </div>
            {d.recurring && (
              <Select aria-label="Frequency" className="w-36" value={d.recurrence} onChange={(e) => set("recurrence", e.target.value)}>
                <option value="daily">Daily</option>
                <option value="weekly">Weekly</option>
                <option value="monthly">Monthly</option>
                <option value="yearly">Yearly</option>
                <option value="custom">Custom</option>
              </Select>
            )}
          </div>
          <Field label="Notes" className="col-span-2">
            {(id) => <Textarea id={id} value={d.notes} maxLength={500} onChange={(e) => set("notes", e.target.value)} />}
          </Field>
        </div>
      )}

      {err && <p className="text-sm text-bad">{err}</p>}
      <Button type="submit" size="lg" className="w-full" loading={saving}>
        {editId ? "Save changes" : `Save ${isExpense ? "expense" : "income"}`}
      </Button>
    </form>
  );
}

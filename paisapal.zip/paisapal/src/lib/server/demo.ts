import "server-only";
import { suggestBudget } from "@/lib/finance/budget";
import { addDays, addMonths, eachDay, isoFromYM, monthStart, ym } from "@/lib/finance/dates";
import { defaultNeedOrWant } from "@/lib/constants";

/** Small deterministic PRNG so demo data looks the same each time. */
function rng(seed: number) {
  return () => {
    seed = (seed * 1664525 + 1013904223) % 4294967296;
    return seed / 4294967296;
  };
}

type Row = Record<string, unknown>;

/**
 * Builds clearly-labelled sample data (is_demo = true) covering the last
 * ~3 months, so every screen has something to show. Only created when the
 * user explicitly asks for it and removable in one click.
 */
export function buildDemoData(userId: string, today: string) {
  const r = rng(42);
  const pick = <T,>(a: T[]) => a[Math.floor(r() * a.length)];
  const amt = (min: number, max: number, step = 10) => Math.round((min + r() * (max - min)) / step) * step;
  const start = addMonths(monthStart(today), -2);
  const txs: Row[] = [];
  const base = { user_id: userId, is_demo: true };
  // PostgREST bulk inserts fill keys missing from some rows with NULL (not the
  // column default), so every transaction row carries the full set of keys
  const txBase = { ...base, subcategory: null, merchant: null, description: null, time: null, payment_method: null, need_or_want: null, essential: null, recurring: false, recurrence: null, earning_source_id: null };
  const exp = (date: string, amount: number, category: string, subcategory: string, merchant: string | null, payment = "UPI", extra: Row = {}) =>
    txs.push({ ...txBase, type: "expense", date, amount, category, subcategory, merchant, payment_method: payment, need_or_want: defaultNeedOrWant(category, subcategory), essential: defaultNeedOrWant(category, subcategory) === "need", time: `${String(8 + Math.floor(r() * 14)).padStart(2, "0")}:${String(Math.floor(r() * 60)).padStart(2, "0")}`, ...extra });

  for (let m = 0; m < 3; m++) {
    const first = addMonths(start, m);
    const { year, month } = ym(first);
    if (first > today) break;
    txs.push({ ...txBase, type: "income", date: first, amount: 12000, category: "Pocket Money", description: "Monthly allowance from parents", recurring: true, recurrence: "monthly", payment_method: "Bank Transfer" });
    const d15 = isoFromYM(year, month, 15);
    if (d15 <= today) txs.push({ ...txBase, type: "income", date: d15, amount: 2500 + m * 500, category: "Freelancing", description: "Logo design project", payment_method: "UPI" });
    const d5 = isoFromYM(year, month, 5);
    if (d5 <= today) exp(d5, 3500, "Food", "Mess", "Hostel Mess", "Bank Transfer", { recurring: true, recurrence: "monthly", description: "Mess fee" });
    const d7 = isoFromYM(year, month, 7);
    if (d7 <= today) exp(d7, 299, "Technology", "Mobile Recharge", "Jio", "UPI", { recurring: true, recurrence: "monthly", description: "Mobile plan" });
  }

  for (const day of eachDay(start, today)) {
    const dow = new Date(`${day}T00:00:00Z`).getUTCDay();
    const weekend = dow === 0 || dow === 6;
    if (r() < 0.75) exp(day, amt(15, 40, 5), "Food", "Tea/Coffee", pick(["Canteen", "Chaayos", "Tapri"]));
    if (r() < 0.45) exp(day, amt(20, 90, 5), "Food", "Snacks", pick(["Canteen", "Kirana Store", "Vending Machine"]));
    if (r() < (weekend ? 0.5 : 0.18)) exp(day, amt(180, 450), "Food", "Delivery", pick(["Swiggy", "Zomato"]));
    if (r() < 0.35) exp(day, amt(20, 60, 5), "Travel", pick(["Bus", "Metro"]), null, "Cash");
    if (r() < (weekend ? 0.35 : 0.08)) exp(day, amt(80, 260), "Travel", pick(["Auto", "Cab"]), pick(["Uber", "Ola", "Rapido"]));
    if (weekend && r() < 0.3) exp(day, amt(250, 600), "Social", pick(["Movies", "Cafes", "Friends"]), pick(["PVR", "Starbucks", "Third Wave Coffee", null]));
    if (r() < 0.04) exp(day, amt(400, 1500, 50), "Personal", pick(["Clothes", "Shopping", "Accessories"]), pick(["Myntra", "Amazon", "Ajio"]));
    if (r() < 0.05) exp(day, amt(30, 250), "Education", pick(["Printing", "Stationery", "Books"]), pick(["Xerox Shop", "Campus Store"]));
  }

  const { year, month } = ym(today);
  const budgets = suggestBudget({ income: 14500, typicalFood: 6500, typicalTravel: 1500 }).map((b) => ({ ...base, ...b, year, month }));

  const goals: Row[] = [
    { ...base, name: "New Phone", category: "Phone", target_amount: 25000, target_date: addMonths(today, 8), priority: "high", is_emergency: false },
    { ...base, name: "Emergency Fund", category: "Emergency Fund", target_amount: 10000, target_date: null, priority: "high", is_emergency: true },
  ];
  const contributions = (goalIds: string[]) => [
    { ...base, goal_id: goalIds[0], amount: 3000, date: addDays(start, 20), note: "Demo saving" },
    { ...base, goal_id: goalIds[0], amount: 2000, date: addDays(start, 50), note: "Demo saving" },
    { ...base, goal_id: goalIds[1], amount: 4500, date: addDays(start, 10), note: "Demo saving" },
  ].filter((c) => c.date <= today);

  return {
    transactions: txs,
    budgets,
    goals,
    contributions,
    subscriptions: [
      { ...base, name: "Spotify Student", amount: 59, billing_cycle: "monthly", next_payment_date: addDays(today, 4), category: "Technology" },
      { ...base, name: "Netflix Mobile", amount: 149, billing_cycle: "monthly", next_payment_date: addDays(today, 12), category: "Technology" },
      { ...base, name: "Amazon Prime", amount: 299, billing_cycle: "monthly", next_payment_date: addDays(today, 20), category: "Technology" },
      { ...base, name: "Cloud storage", amount: 130, billing_cycle: "monthly", next_payment_date: addDays(today, 1), category: "Technology" },
    ],
    reminders: [
      { ...base, title: "Wi-Fi bill", amount: 499, due_date: addDays(today, 1), recurring: "monthly", kind: "Internet", category: "Technology" },
      { ...base, title: "Hostel fee", amount: 5000, due_date: addDays(today, 9), recurring: "quarterly", kind: "Hostel Fees", category: "Housing" },
    ],
    earningSources: [
      { ...base, source: "Logo design gigs", type: "Design Services", expected_income: 3000, hours: 6, status: "active", start_date: start },
      { ...base, source: "Maths tutoring", type: "Tutoring", expected_income: 2000, hours: 4, status: "idea", start_date: null },
    ],
    noSpend: [{ ...base, title: "No food delivery on weekdays", category: "Food", subcategory: "Delivery", start_date: addDays(today, -10), end_date: addDays(today, 20), limit_amount: 500 }],
  };
}

import "server-only";
import type { z } from "zod";
import {
  budgetSchema, categorySchema, contributionSchema, earningSourceSchema, goalSchema, noSpendBase, noSpendSchema, reminderSchema, subscriptionSchema, transactionSchema,
} from "@/lib/validation";

export interface ResourceDef {
  table: string;
  create: z.ZodType;
  update: z.ZodType;
  order: { column: string; ascending: boolean }[];
}

export const RESOURCES: Record<string, ResourceDef> = {
  transactions: { table: "transactions", create: transactionSchema, update: transactionSchema.partial(), order: [{ column: "date", ascending: false }, { column: "time", ascending: false }, { column: "created_at", ascending: false }] },
  budgets: { table: "budgets", create: budgetSchema, update: budgetSchema.partial(), order: [{ column: "year", ascending: false }, { column: "month", ascending: false }] },
  goals: { table: "goals", create: goalSchema, update: goalSchema.omit({ current_amount: true }).partial(), order: [{ column: "created_at", ascending: true }] },
  contributions: { table: "goal_contributions", create: contributionSchema, update: contributionSchema.partial(), order: [{ column: "date", ascending: false }] },
  subscriptions: { table: "subscriptions", create: subscriptionSchema, update: subscriptionSchema.partial(), order: [{ column: "next_payment_date", ascending: true }] },
  reminders: { table: "reminders", create: reminderSchema, update: reminderSchema.partial(), order: [{ column: "due_date", ascending: true }] },
  "no-spend": { table: "no_spend_rules", create: noSpendSchema, update: noSpendBase.partial(), order: [{ column: "start_date", ascending: false }] },
  "earning-sources": { table: "earning_sources", create: earningSourceSchema, update: earningSourceSchema.partial(), order: [{ column: "created_at", ascending: true }] },
  categories: { table: "categories", create: categorySchema, update: categorySchema.partial(), order: [{ column: "name", ascending: true }] },
};

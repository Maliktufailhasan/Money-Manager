import "server-only";
import Anthropic from "@anthropic-ai/sdk";
import {
  affordability, budgetReport, currentBalance, detectWaste, financialPosition, goalMetrics, planFromZero, ruleProgress, safeToSpend,
  subscriptionMonthlyCost, summarize, upcomingPayments, whatIf, addDays, addMonths, monthEnd, monthStart, ym, round2, sum,
} from "@/lib/finance";
import type { Snapshot, Transaction } from "@/lib/types";

export const AI_MODEL = "claude-opus-5-5";
export const aiConfigured = () => Boolean(process.env.ANTHROPIC_API_KEY || process.env.ANTHROPIC_AUTH_TOKEN);

const top = <T,>(a: T[], n: number) => a.slice(0, n);

/** Compact, pre-computed view of the student's finances. Only aggregates — no raw transaction dump. */
export function financialContext(s: Snapshot, today: string) {
  const pos = financialPosition(s, today);
  const balance = currentBalance(s);
  const thisMonth = summarize(s.transactions, monthStart(today), today);
  const lm = addMonths(monthStart(today), -1);
  const lastMonth = summarize(s.transactions, lm, monthEnd(lm));
  const { year, month } = ym(today);
  const br = budgetReport(s.budgets, s.transactions, year, month, today);
  const brief = (p: ReturnType<typeof summarize>) => ({
    from: p.from, to: p.to, received: p.received, refunds: p.refunds, spent: p.spent, saved: p.saved, savings_rate_pct: p.savingsRate,
    by_category: top(p.byCategory, 10).map((c) => ({ category: c.name, amount: c.amount, count: c.count })),
    by_subcategory: top(p.bySubcategory, 12).map((c) => ({ subcategory: c.name, amount: c.amount, count: c.count })),
    income_sources: p.bySource.map((c) => ({ source: c.name, amount: c.amount })),
    needs: p.needs, wants: p.wants, unclassified: p.unclassified,
    largest_expenses: p.largestExpenses.map((t) => ({ date: t.date, amount: t.amount, category: t.category, subcategory: t.subcategory, merchant: t.merchant, description: t.description, need_or_want: t.need_or_want })),
  });
  return {
    today,
    name: s.profile.name || null,
    currency: "INR",
    data_quality: { level: pos.dataQuality, months_of_data: pos.monthsOfData, basis: pos.basis, total_transactions: s.totals.tx_count, first_transaction: s.totals.first_date },
    balance,
    averages_monthly: { income: pos.avgMonthlyIncome, expenses: pos.avgMonthlyExpense, needs: pos.avgNeeds, wants: pos.avgWants, reducible: pos.reducibleMonthly, recurring_commitments: pos.recurringMonthly, saving_capacity: pos.savingCapacity, savings_rate_pct: pos.savingsRate, committed_to_goals: pos.committedToGoals, is_estimate: pos.isEstimate },
    this_month_to_date: brief(thisMonth),
    last_month: brief(lastMonth),
    safe_to_spend: safeToSpend(s, today, balance),
    budget_this_month: { total_budget: br.totalBudget, spent: br.totalSpent, savings_target: br.savingsTarget, lines: br.rows.map((r) => ({ category: r.category, budget: r.budget, spent: r.spent, used_pct: r.usedPct, state: r.state, projected_month_end: r.projected })) },
    goals: s.goals.map((g) => {
      const m = goalMetrics(g, s.contributions, today, pos.savingCapacity);
      return { name: g.name, target: g.target_amount, saved: g.current_amount, remaining: m.remaining, target_date: g.target_date, priority: g.priority, status: m.status, required_monthly: m.requiredMonthly, recent_pace_monthly: m.recentPace, eta_months: m.etaMonths, emergency_fund: g.is_emergency };
    }),
    subscriptions: s.subscriptions.map((x) => ({ name: x.name, amount: x.amount, cycle: x.billing_cycle, monthly_cost: round2(subscriptionMonthlyCost(x)), next: x.next_payment_date, active: x.status === "active" })),
    upcoming_payments_30d: upcomingPayments(s, today, addDays(today, 30)).map((p) => ({ title: p.title, amount: p.amount, date: p.date, kind: p.kind })),
    spending_patterns_last_30d: detectWaste(s.transactions, s.subscriptions, today, pos.avgMonthlyIncome).map((w) => ({ pattern: w.title, amount: w.amount, count: w.count, suggested_cut_pct: w.cutPct, monthly_saving_if_cut: w.monthlySaving })),
    earning_sources: s.earningSources.map((e) => ({
      source: e.source, type: e.type, status: e.status, expected_monthly_potential: e.expected_income, hours_per_week: e.hours,
      actual_this_month: sum(s.transactions.filter((t) => t.earning_source_id === e.id && t.date >= monthStart(today)).map((t) => t.amount)),
    })),
    dont_spend_rules: s.noSpendRules.filter((r) => r.active).map((r) => {
      const p = ruleProgress(r, s.transactions, today);
      return { title: r.title, category: r.category, subcategory: r.subcategory, from: r.start_date, to: r.end_date, limit: r.limit_amount, spent: p.spent, state: p.state, estimated_saved: p.estimatedSaved };
    }),
  };
}

const SYSTEM = `You are PaisaPal, a friendly personal-budgeting assistant for a college student in India. You help them understand their own recorded money data and plan savings.

Ground rules:
- Use ONLY the student's data provided in <financial_data> and tool results. Never invent transactions, income, balances, savings or prices. If something isn't in the data, say so and say what they could record.
- For specific questions (a category, merchant, date range, comparison) call query_transactions rather than guessing from summaries. For purchase plans, affordability and "what if" questions, call the planning tools so the numbers are computed exactly.
- Make the source of every number clear. Use these labels where it helps: "Recorded" (straight from their data), "Calculated" (arithmetic on their data), "Estimate" (a projection), "Your assumption" (something they told you), "Suggestion" (your idea).
- Potential extra income is never guaranteed — always say so when a plan relies on it.
- If data_quality.level is "none" or "limited", mention that answers will improve as they record more.
- You give personal budgeting help, not professional financial, tax or investment advice. Don't recommend specific investment products.
- Be practical and kind, not preachy. Offer realistic student-friendly alternatives (mess food, bus passes, student plans, campus jobs, tutoring, freelancing).
- Money is in Indian Rupees: write amounts like ₹1,250 with Indian digit grouping.
- Keep answers short and scannable: a direct answer first, then a few bullets or a small table. No more than ~200 words unless they ask for a detailed plan.`;

const nullable = (type: string, description: string) => ({ type: [type, "null"], description });

export const AI_TOOLS: Anthropic.Beta.BetaTool[] = [
  {
    name: "query_transactions",
    description: "Sum and list the student's recorded transactions for a date range with optional filters. Use for any question about a specific category, subcategory, merchant, payment method, need/want or period, and for comparisons (call once per period).",
    strict: true,
    input_schema: {
      type: "object",
      properties: {
        from: { type: "string", description: "Start date YYYY-MM-DD (inclusive)" },
        to: { type: "string", description: "End date YYYY-MM-DD (inclusive)" },
        type: { type: "string", enum: ["expense", "income"] },
        category: nullable("string", "Exact category, e.g. Food, Travel, Social, or an income source like Freelancing"),
        subcategory: nullable("string", "Exact subcategory, e.g. Delivery, Tea/Coffee, Cab"),
        text: nullable("string", "Case-insensitive text to find in merchant/description, e.g. swiggy"),
        need_or_want: { type: ["string", "null"], enum: ["need", "want", null] },
        max_items: { type: "integer", description: "How many of the largest matching transactions to list (0-20)" },
      },
      required: ["from", "to", "type", "category", "subcategory", "text", "need_or_want", "max_items"],
      additionalProperties: false,
    },
  },
  {
    name: "plan_purchase",
    description: "Build a step-by-step savings plan to buy something by a deadline, starting from a given amount (often ₹0), using the student's real averages: saving capacity, possible spending cuts and the extra income still needed.",
    strict: true,
    input_schema: {
      type: "object",
      properties: {
        item: { type: "string" },
        price: { type: "number" },
        months: { type: "number", description: "Months until they want to buy it" },
        starting_amount: { type: "number", description: "Money already set aside for it (0 if starting from zero)" },
      },
      required: ["item", "price", "months", "starting_amount"],
      additionalProperties: false,
    },
  },
  {
    name: "check_affordability",
    description: "Can they afford an item? Returns monthly/weekly/daily saving needed and four scenarios (current, reduced spending, extra income, combined) using their real income and expenses.",
    strict: true,
    input_schema: {
      type: "object",
      properties: {
        price: { type: "number" },
        target_months: nullable("number", "Months until purchase, or null for 'as soon as possible'"),
        current_money: nullable("number", "Money available for it now; null = use 0"),
        extra_income: nullable("number", "Extra monthly income to assume; null = use their tracked earning potential"),
      },
      required: ["price", "target_months", "current_money", "extra_income"],
      additionalProperties: false,
    },
  },
  {
    name: "what_if",
    description: "Calculate the effect of a habit change: stop/save a daily amount, earn extra monthly, or cut a category by a percentage (uses their real average for that category).",
    strict: true,
    input_schema: {
      type: "object",
      properties: {
        kind: { type: "string", enum: ["stop_daily", "save_daily", "earn_monthly", "reduce_category"] },
        amount: nullable("number", "₹ amount for stop_daily / save_daily / earn_monthly"),
        category: nullable("string", "Category for reduce_category"),
        percent: nullable("number", "Percent for reduce_category"),
      },
      required: ["kind", "amount", "category", "percent"],
      additionalProperties: false,
    },
  },
];

function isoOk(x: unknown): x is string {
  return typeof x === "string" && /^\d{4}-\d{2}-\d{2}$/.test(x);
}

export function runTool(name: string, input: Record<string, unknown>, s: Snapshot, today: string): unknown {
  const pos = financialPosition(s, today);
  switch (name) {
    case "query_transactions": {
      if (!isoOk(input.from) || !isoOk(input.to)) return { error: "from/to must be YYYY-MM-DD" };
      const from = String(input.from);
      const to = String(input.to);
      const text = typeof input.text === "string" ? input.text.toLowerCase() : null;
      const match = (t: Transaction) =>
        t.type === input.type && t.date >= from && t.date <= to &&
        (!input.category || t.category.toLowerCase() === String(input.category).toLowerCase()) &&
        (!input.subcategory || (t.subcategory ?? "").toLowerCase() === String(input.subcategory).toLowerCase()) &&
        (!input.need_or_want || t.need_or_want === input.need_or_want) &&
        (!text || `${t.merchant ?? ""} ${t.description ?? ""} ${t.notes ?? ""}`.toLowerCase().includes(text));
      const rows = s.transactions.filter(match);
      const note = from < s.windowStart ? `Only data from ${s.windowStart} onward is loaded; older transactions are not included.` : undefined;
      const byCat = new Map<string, number>();
      for (const t of rows) byCat.set(t.subcategory ? `${t.category} → ${t.subcategory}` : t.category, (byCat.get(t.subcategory ? `${t.category} → ${t.subcategory}` : t.category) ?? 0) + t.amount);
      return {
        total: sum(rows.map((t) => t.amount)),
        count: rows.length,
        breakdown: [...byCat.entries()].sort((a, b) => b[1] - a[1]).slice(0, 10).map(([k, v]) => ({ name: k, amount: round2(v) })),
        largest: [...rows].sort((a, b) => b.amount - a.amount).slice(0, Math.min(20, Math.max(0, Number(input.max_items) || 0))).map((t) => ({ date: t.date, amount: t.amount, category: t.category, subcategory: t.subcategory, merchant: t.merchant, description: t.description })),
        note,
      };
    }
    case "plan_purchase": {
      const potential = sum(s.earningSources.filter((e) => e.status === "active" || e.status === "idea").map((e) => e.expected_income));
      return planFromZero({ item: String(input.item), price: Number(input.price), months: Number(input.months), startingAmount: Number(input.starting_amount) || 0, incomePotential: potential }, pos);
    }
    case "check_affordability": {
      const potential = sum(s.earningSources.filter((e) => e.status !== "stopped").map((e) => e.expected_income));
      return {
        ...affordability({
          price: Number(input.price),
          currentMoney: Number(input.current_money) || 0,
          monthlyIncome: pos.avgMonthlyIncome,
          monthlyExpenses: pos.avgMonthlyExpense,
          targetMonths: input.target_months === null ? null : Number(input.target_months),
          reduction: Math.round(pos.reducibleMonthly * 0.3),
          extraIncome: input.extra_income === null ? potential : Number(input.extra_income),
        }, today),
        basis: pos.basis,
      };
    }
    case "what_if": {
      const kind = String(input.kind);
      if (kind === "reduce_category") {
        const cat = String(input.category ?? "");
        const months = [1, 2, 3].map((i) => addMonths(monthStart(today), -i));
        const avg = sum(months.map((m) => summarize(s.transactions, m, monthEnd(m)).byCategory.find((c) => c.name.toLowerCase() === cat.toLowerCase())?.amount ?? 0)) / 3;
        return whatIf({ kind: "reduce_category", category: cat, percent: Number(input.percent) || 0, categoryMonthly: round2(avg) });
      }
      if (kind === "stop_daily" || kind === "save_daily" || kind === "earn_monthly") return whatIf({ kind, amount: Number(input.amount) || 0 });
      return { error: "unknown kind" };
    }
  }
  return { error: `unknown tool ${name}` };
}

let client: Anthropic | null = null;
const anthropic = () => (client ??= new Anthropic());

export interface ChatTurn {
  role: "user" | "assistant";
  content: string;
}

/** Runs the assistant with the student's data and tools; returns the final text. */
export async function askAssistant(history: ChatTurn[], s: Snapshot, today: string, extraInstruction?: string): Promise<{ text: string; toolsUsed: string[] }> {
  const ctx = financialContext(s, today);
  const messages: Anthropic.Beta.BetaMessageParam[] = history.map((h) => ({ role: h.role, content: h.content }));
  const toolsUsed: string[] = [];

  for (let i = 0; i < 6; i++) {
    const response = await anthropic().beta.messages.create({
      model: AI_MODEL,
      max_tokens: 16000,
      betas: ["server-side-fallback-2026-07-01"],
      fallbacks: "default",
      output_config: { effort: "medium" },
      system: [
        { type: "text", text: SYSTEM, cache_control: { type: "ephemeral" } },
        { type: "text", text: `<financial_data>\n${JSON.stringify(ctx)}\n</financial_data>${extraInstruction ? `\n\n${extraInstruction}` : ""}` },
      ],
      tools: AI_TOOLS,
      messages,
    });

    if (response.stop_reason === "refusal") {
      return { text: "Sorry — I can't help with that request. Try asking about your spending, budget, savings or goals.", toolsUsed };
    }
    const toolUses = response.content.filter((b): b is Anthropic.Beta.BetaToolUseBlock => b.type === "tool_use");
    if (response.stop_reason !== "tool_use" || toolUses.length === 0) {
      const text = response.content.filter((b): b is Anthropic.Beta.BetaTextBlock => b.type === "text").map((b) => b.text).join("\n").trim();
      return { text: text || "I couldn't produce an answer. Please try rephrasing.", toolsUsed };
    }
    messages.push({ role: "assistant", content: response.content });
    messages.push({
      role: "user",
      content: toolUses.map((tu) => {
        toolsUsed.push(tu.name);
        let result: unknown;
        try {
          result = runTool(tu.name, tu.input as Record<string, unknown>, s, today);
        } catch (e) {
          return { type: "tool_result" as const, tool_use_id: tu.id, content: `Error: ${(e as Error).message}`, is_error: true };
        }
        return { type: "tool_result" as const, tool_use_id: tu.id, content: JSON.stringify(result) };
      }),
    });
  }
  return { text: "That took too many steps. Please ask a more specific question.", toolsUsed };
}

export function aiErrorMessage(e: unknown): string {
  if (e instanceof Anthropic.AuthenticationError) return "The AI key is invalid. Check ANTHROPIC_API_KEY.";
  if (e instanceof Anthropic.RateLimitError) return "The AI is busy right now. Try again in a minute.";
  if (e instanceof Anthropic.BadRequestError) return `The AI request was rejected: ${e.message}`;
  if (e instanceof Anthropic.APIError) return `AI service error (${e.status ?? "network"}).`;
  return "The AI assistant failed unexpectedly.";
}

import "server-only";
import { NextResponse } from "next/server";
import { z } from "zod";
import { supabaseServer } from "@/lib/supabase/server";

export class HttpError extends Error {
  constructor(public status: number, message: string, public details?: unknown) {
    super(message);
  }
}

/** Resolve the signed-in user (verified with the auth server) and a user-scoped client. */
export async function requireUser() {
  const supabase = await supabaseServer();
  const { data, error } = await supabase.auth.getUser();
  if (error || !data.user) throw new HttpError(401, "Not signed in");
  return { supabase, user: data.user };
}

export function parse<T extends z.ZodType>(schema: T, input: unknown): z.infer<T> {
  const r = schema.safeParse(input);
  if (!r.success) {
    const first = r.error.issues[0];
    throw new HttpError(400, first ? `${first.path.join(".") || "input"}: ${first.message}` : "Invalid input", z.flattenError(r.error));
  }
  return r.data;
}

export async function readJson(req: Request): Promise<unknown> {
  try {
    return await req.json();
  } catch {
    throw new HttpError(400, "Body must be JSON");
  }
}

export function handle<A extends unknown[]>(fn: (...args: A) => Promise<Response | unknown>) {
  return async (...args: A): Promise<Response> => {
    try {
      const out = await fn(...args);
      return out instanceof Response ? out : NextResponse.json(out ?? { ok: true });
    } catch (e) {
      if (e instanceof HttpError) return NextResponse.json({ error: e.message, details: e.details }, { status: e.status });
      console.error(e);
      return NextResponse.json({ error: "Something went wrong" }, { status: 500 });
    }
  };
}

export function dbError(error: { message: string; code?: string } | null): void {
  if (!error) return;
  if (error.code === "23505") throw new HttpError(409, "That already exists");
  if (error.code === "23514" || error.code === "22P02" || error.code === "P0001") throw new HttpError(400, error.message);
  throw new HttpError(500, error.message);
}

const NUMERIC = new Set(["amount", "target_amount", "current_amount", "opening_balance", "monthly_income_estimate", "daily_limit", "limit_amount", "baseline_monthly", "expected_income", "hours", "total_income", "total_expense", "tx_count"]);

/** PostgREST may serialise numeric columns as strings; normalise to numbers. */
export function normalize<T>(rows: T): T {
  const fix = (r: Record<string, unknown>) => {
    for (const k of Object.keys(r)) if (NUMERIC.has(k) && r[k] !== null && r[k] !== undefined) r[k] = Number(r[k]);
    return r;
  };
  if (Array.isArray(rows)) rows.forEach((r) => fix(r as Record<string, unknown>));
  else if (rows && typeof rows === "object") fix(rows as Record<string, unknown>);
  return rows;
}

import "server-only";
import type { SupabaseClient } from "@supabase/supabase-js";
import { addMonths, monthStart } from "@/lib/finance/dates";
import type { Snapshot } from "@/lib/types";
import { dbError, HttpError, normalize } from "./api";

/** Months of transaction history loaded for the dashboard (older rows are still counted in lifetime totals). */
export const SNAPSHOT_MONTHS = 13;

type Query = ReturnType<ReturnType<SupabaseClient["from"]>["select"]>;

/** PostgREST caps rows per request (1000 by default), so page through large tables. */
export async function fetchAll(supabase: SupabaseClient, table: string, build: (q: Query) => Query = (q) => q, pageSize = 1000) {
  const rows: Record<string, unknown>[] = [];
  for (let from = 0; ; from += pageSize) {
    const { data, error } = await build(supabase.from(table).select("*")).range(from, from + pageSize - 1);
    if (error) return { data: null, error };
    rows.push(...(data as Record<string, unknown>[]));
    if (!data || data.length < pageSize || rows.length >= 50_000) break;
  }
  return { data: rows, error: null };
}

export async function loadSnapshot(supabase: SupabaseClient, userId: string, today: string): Promise<Snapshot> {
  const windowStart = addMonths(monthStart(today), -(SNAPSHOT_MONTHS - 1));
  const [profile, totals, transactions, budgets, goals, contributions, subscriptions, reminders, noSpend, earning, categories] = await Promise.all([
    supabase.from("profiles").select("*").eq("id", userId).maybeSingle(),
    supabase.rpc("lifetime_totals"),
    fetchAll(supabase, "transactions", (q) => q.gte("date", windowStart).order("date", { ascending: false }).order("created_at", { ascending: false })),
    supabase.from("budgets").select("id,category,amount,month,year").gte("year", Number(windowStart.slice(0, 4))),
    supabase.from("goals").select("*").order("created_at"),
    supabase.from("goal_contributions").select("*").order("date", { ascending: false }),
    supabase.from("subscriptions").select("*").order("next_payment_date"),
    supabase.from("reminders").select("*").order("due_date"),
    supabase.from("no_spend_rules").select("*").order("start_date", { ascending: false }),
    supabase.from("earning_sources").select("*").order("created_at"),
    supabase.from("categories").select("id,kind,name,subcategories").order("name"),
  ]);
  for (const r of [profile, totals, transactions, budgets, goals, contributions, subscriptions, reminders, noSpend, earning, categories]) dbError(r.error);

  let prof = profile.data;
  if (!prof) {
    // profile trigger may not have run (e.g. user created before migration) — create it
    const { data: user } = await supabase.auth.getUser();
    const ins = await supabase.from("profiles").insert({ id: userId, email: user.user?.email ?? null, name: user.user?.user_metadata?.name ?? "" }).select("*").single();
    dbError(ins.error);
    prof = ins.data;
  }
  if (!prof) throw new HttpError(500, "Profile missing");

  const t = (Array.isArray(totals.data) ? totals.data[0] : totals.data) ?? { total_income: 0, total_expense: 0, first_date: null, tx_count: 0 };
  return {
    profile: normalize({ ...prof, preferences: prof.preferences ?? {} }),
    totals: normalize(t),
    transactions: normalize(transactions.data ?? []),
    windowStart,
    budgets: normalize(budgets.data ?? []),
    goals: normalize(goals.data ?? []),
    contributions: normalize(contributions.data ?? []),
    subscriptions: normalize(subscriptions.data ?? []),
    reminders: normalize(reminders.data ?? []),
    noSpendRules: normalize(noSpend.data ?? []),
    earningSources: normalize(earning.data ?? []),
    categories: categories.data ?? [],
  } as unknown as Snapshot;
}

import type { Snapshot } from "../types";
import { isExpense, summarize, txInRange } from "./aggregate";
import { addDays, addMonths, d, daysInMonth, diffDays, monthStart, ym } from "./dates";
import { goalMetrics } from "./goals";
import { pct, round2, sum } from "./money";
import type { FinancialPosition } from "./position";

export interface Insight {
  id: string;
  tone: "positive" | "warning" | "info";
  text: string;
  /** recorded = straight from data; calculated = derived; estimate = projection */
  basis: "recorded" | "calculated" | "estimate";
}

const fmt = (n: number) => `₹${Math.round(n).toLocaleString("en-IN")}`;

/** Data-driven insights. Each one is computed from stored records; nothing is invented. */
export function generateInsights(s: Snapshot, today: string, pos: FinancialPosition): Insight[] {
  const out: Insight[] = [];
  const txs = s.transactions;
  if (!txs.length) return out;

  // month-to-date vs the same days of last month
  const thisFrom = monthStart(today);
  const dayN = diffDays(today, thisFrom) + 1;
  const lastFrom = addMonths(thisFrom, -1);
  const { year: ly, month: lm } = ym(lastFrom);
  const lastTo = addDays(lastFrom, Math.min(dayN, daysInMonth(ly, lm)) - 1);
  const cur = summarize(txs, thisFrom, today);
  const prev = summarize(txs, lastFrom, lastTo);
  // a few days of data swing wildly in percentage terms, so wait for a week
  const hasPrev = dayN >= 7 && !!s.totals.first_date && s.totals.first_date <= lastTo;

  if (hasPrev) {
    const cats = new Set([...cur.byCategory.map((c) => c.name), ...prev.byCategory.map((c) => c.name)]);
    const changes: { cat: string; now: number; before: number; change: number }[] = [];
    for (const cat of cats) {
      const now = cur.byCategory.find((c) => c.name === cat)?.amount ?? 0;
      const before = prev.byCategory.find((c) => c.name === cat)?.amount ?? 0;
      if (before > 0 && Math.abs(now - before) >= 200) changes.push({ cat, now, before, change: ((now - before) / before) * 100 });
    }
    changes.sort((a, b) => Math.abs(b.change) - Math.abs(a.change));
    for (const c of changes.slice(0, 3)) {
      if (Math.abs(c.change) < 15) continue;
      const up = c.change > 0;
      out.push({
        id: `cat-${c.cat}`,
        tone: up ? "warning" : "positive",
        text: `Your ${c.cat.toLowerCase()} spending ${up ? "increased" : "decreased"} ${Math.abs(Math.round(c.change))}% compared with the same ${dayN} days last month (${fmt(c.now)} vs ${fmt(c.before)}).`,
        basis: "calculated",
      });
    }
    if (prev.spent > 0) {
      const ch = ((cur.spent - prev.spent) / prev.spent) * 100;
      if (Math.abs(ch) >= 10)
        out.push({ id: "total", tone: ch > 0 ? "warning" : "positive", text: `Overall spending is ${Math.abs(Math.round(ch))}% ${ch > 0 ? "higher" : "lower"} than this point last month.`, basis: "calculated" });
    }
  }

  // small purchases in last 30 days
  const last30 = txInRange(txs, addDays(today, -29), today).filter(isExpense);
  const small = last30.filter((t) => t.amount < 100);
  const smallAmt = sum(small.map((t) => t.amount));
  const total30 = sum(last30.map((t) => t.amount));
  if (small.length >= 8 && total30 > 0 && smallAmt / total30 >= 0.1) {
    out.push({ id: "small", tone: "warning", text: `You spent ${fmt(smallAmt)} on ${small.length} small purchases under ₹100 in the last 30 days — ${Math.round((smallAmt / total30) * 100)}% of your spending.`, basis: "recorded" });
  }

  // top category this month
  if (cur.byCategory[0] && cur.spent > 0) {
    out.push({ id: "top", tone: "info", text: `${cur.byCategory[0].name} is your biggest expense this month: ${fmt(cur.byCategory[0].amount)} (${Math.round(cur.byCategory[0].share ?? 0)}% of spending).`, basis: "recorded" });
  }

  // wants share
  const classified = cur.needs + cur.wants;
  if (classified > 0 && cur.wants / classified > 0.4) {
    out.push({ id: "wants", tone: "warning", text: `${Math.round((cur.wants / classified) * 100)}% of this month's classified spending is on wants (${fmt(cur.wants)}).`, basis: "calculated" });
  }

  // weekend vs weekday (last 60 days)
  const last60 = txInRange(txs, addDays(today, -59), today).filter(isExpense);
  if (last60.length >= 15) {
    const isWeekend = (iso: string) => [0, 6].includes(d(iso).getUTCDay());
    const we = sum(last60.filter((t) => isWeekend(t.date)).map((t) => t.amount)) / (60 * (2 / 7));
    const wd = sum(last60.filter((t) => !isWeekend(t.date)).map((t) => t.amount)) / (60 * (5 / 7));
    if (wd > 0 && we / wd >= 1.5) out.push({ id: "weekend", tone: "info", text: `You spend about ${round2(we / wd).toFixed(1)}× more per day on weekends (${fmt(we)}/day vs ${fmt(wd)}/day).`, basis: "calculated" });
  }

  // savings rate this month
  if (cur.received > 0) {
    const r = pct(cur.saved, cur.received)!;
    out.push({ id: "rate", tone: r >= 20 ? "positive" : r < 0 ? "warning" : "info", text: r < 0 ? `You've spent ${fmt(-cur.saved)} more than you received this month so far.` : `You've kept ${Math.round(r)}% of the money you received this month (${fmt(cur.saved)}).`, basis: "recorded" });
  }

  // goal ETA at current savings
  const freeCap = Math.max(0, pos.savingCapacity - pos.committedToGoals);
  const active = s.goals.filter((g) => g.status === "active").sort((a, b) => (a.priority === "high" ? -1 : 0) - (b.priority === "high" ? -1 : 0));
  for (const g of active.slice(0, 2)) {
    const m = goalMetrics(g, s.contributions, today, pos.savingCapacity);
    if (m.etaMonths && m.etaMonths > 0) {
      out.push({
        id: `goal-${g.id}`,
        tone: m.status === "behind" ? "warning" : "positive",
        text: `If your ${m.etaBasis === "goal pace" ? "recent saving pace for this goal" : "current savings rate"} continues, you may reach your ${g.name} goal in about ${Math.ceil(m.etaMonths)} month${Math.ceil(m.etaMonths) > 1 ? "s" : ""}${g.target_date ? (m.status === "behind" ? " — later than your target date" : " — before your target date") : ""}.`,
        basis: "estimate",
      });
    } else if (m.remaining > 0 && freeCap <= 0) {
      out.push({ id: `goal-${g.id}`, tone: "warning", text: `At current spending there's no money left over each month for your ${g.name} goal.`, basis: "estimate" });
    }
  }

  if (pos.dataQuality !== "good") {
    out.push({ id: "data", tone: "info", text: "Insights get more accurate after a full month of recorded income and expenses.", basis: "calculated" });
  }
  return out;
}

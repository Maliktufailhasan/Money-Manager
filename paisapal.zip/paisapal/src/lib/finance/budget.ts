import type { Budget, Snapshot, Transaction } from "../types";
import { isExpense, summarize } from "./aggregate";
import { daysInMonth, diffDays, isoFromYM, monthEnd, monthStart, ym } from "./dates";
import { pct, round2, sum } from "./money";
import { totalDue, upcomingPayments } from "./schedule";

export const SAVINGS_BUDGET = "Savings";
export const NEAR_LIMIT_PCT = 80;

export type BudgetState = "under" | "near" | "over" | "unbudgeted";

export interface BudgetRow {
  category: string;
  budget: number;
  spent: number;
  remaining: number;
  usedPct: number | null;
  state: BudgetState;
  /** spending pace: projected month-end spend at the current daily rate */
  projected: number;
}

export function budgetsFor(budgets: Budget[], year: number, month: number): Budget[] {
  return budgets.filter((b) => b.year === year && b.month === month);
}

export function budgetState(spent: number, budget: number): BudgetState {
  if (budget <= 0) return spent > 0 ? "over" : "under";
  const used = (spent / budget) * 100;
  if (used > 100) return "over";
  if (used >= NEAR_LIMIT_PCT) return "near";
  return "under";
}

/** Budget vs actual for a month; categories with spending but no budget are listed as "unbudgeted". */
export function budgetReport(budgets: Budget[], txs: Transaction[], year: number, month: number, today: string) {
  const from = isoFromYM(year, month, 1);
  const to = monthEnd(from);
  const s = summarize(txs, from, to);
  const monthBudgets = budgetsFor(budgets, year, month);
  const expenseBudgets = monthBudgets.filter((b) => b.category !== SAVINGS_BUDGET);
  const savingsTarget = monthBudgets.find((b) => b.category === SAVINGS_BUDGET)?.amount ?? null;

  const dim = daysInMonth(year, month);
  const elapsed = today < from ? 0 : today > to ? dim : diffDays(today, from) + 1;
  const project = (spent: number) => (elapsed > 0 && elapsed < dim ? round2((spent / elapsed) * dim) : spent);

  const spentBy = new Map(s.byCategory.map((c) => [c.name, c.amount]));
  const rows: BudgetRow[] = expenseBudgets.map((b) => {
    const spent = spentBy.get(b.category) ?? 0;
    return {
      category: b.category,
      budget: b.amount,
      spent,
      remaining: round2(b.amount - spent),
      usedPct: pct(spent, b.amount),
      state: budgetState(spent, b.amount),
      projected: project(spent),
    };
  });
  for (const c of s.byCategory) {
    if (!expenseBudgets.some((b) => b.category === c.name)) {
      rows.push({ category: c.name, budget: 0, spent: c.amount, remaining: -c.amount, usedPct: null, state: "unbudgeted", projected: project(c.amount) });
    }
  }
  rows.sort((a, b) => (b.usedPct ?? -1) - (a.usedPct ?? -1));

  const totalBudget = sum(expenseBudgets.map((b) => b.amount));
  const budgetedSpent = sum(rows.filter((r) => r.state !== "unbudgeted").map((r) => r.spent));
  return {
    rows,
    totalBudget,
    totalSpent: s.spent,
    budgetedSpent,
    remaining: round2(totalBudget - s.spent),
    /** what is left across budgeted categories (unbudgeted spending excluded) */
    budgetedRemaining: round2(totalBudget - budgetedSpent),
    usedPct: pct(s.spent, totalBudget),
    savingsTarget,
    saved: s.saved,
    hasBudget: expenseBudgets.length > 0,
    /** % of budgeted categories within their limit */
    adherence: expenseBudgets.length ? round2((rows.filter((r) => r.state === "under" || r.state === "near").length / expenseBudgets.length) * 100) : null,
  };
}

export interface SafeToSpend {
  balance: number;
  upcomingThisMonth: number;
  savingsStillToSet: number;
  available: number;
  daysLeft: number;
  /** what can be spent per day for the rest of the month */
  daily: number;
  /** spendable over the next 7 days (or until month end) */
  weekly: number;
  /** the remaining monthly expense budget, if a budget exists */
  remainingBudget: number | null;
  limitedBy: "balance" | "budget";
}

/**
 * Safe-to-spend = balance − bills & subscriptions due before month end − the
 * part of this month's savings target not yet saved, spread over the days
 * left. If a monthly budget exists, the result is also capped by what is left
 * in the budget.
 */
export function safeToSpend(s: Snapshot, today: string, balance: number): SafeToSpend {
  const end = monthEnd(today);
  const due = upcomingPayments(s, today, end);
  const upcoming = totalDue(due);
  const { year, month } = ym(today);
  const report = budgetReport(s.budgets, s.transactions, year, month, today);
  const savingsStillToSet = report.savingsTarget ? Math.max(0, round2(report.savingsTarget - Math.max(0, report.saved))) : 0;
  const available = round2(balance - upcoming - savingsStillToSet);
  const daysLeft = diffDays(end, today) + 1;
  let daily = Math.max(0, available) / daysLeft;
  let limitedBy: SafeToSpend["limitedBy"] = "balance";
  let remainingBudget: number | null = null;
  if (report.hasBudget) {
    // budget left, minus scheduled payments that fall inside budgeted categories
    // (a bill in an unbudgeted category doesn't eat into the budget)
    remainingBudget = round2(report.budgetedRemaining);
    const budgeted = new Set(report.rows.filter((r) => r.state !== "unbudgeted").map((r) => r.category));
    const dueInBudget = totalDue(due.filter((p) => budgeted.has(p.category)));
    const budgetDaily = Math.max(0, remainingBudget - dueInBudget) / daysLeft;
    if (budgetDaily < daily) {
      daily = budgetDaily;
      limitedBy = "budget";
    }
  }
  daily = Math.floor(daily);
  return {
    balance,
    upcomingThisMonth: upcoming,
    savingsStillToSet,
    available,
    daysLeft,
    daily,
    weekly: daily * Math.min(7, daysLeft),
    remainingBudget,
    limitedBy,
  };
}

/**
 * Suggest a first monthly budget from onboarding answers. Fixed recurring
 * costs are kept as-is, typical food/travel come from the student, other
 * categories get modest defaults, and whatever is left becomes the savings
 * target. If the plan doesn't fit the income, discretionary lines shrink.
 */
export function suggestBudget(input: {
  income: number;
  typicalFood?: number;
  typicalTravel?: number;
  recurring?: { category: string; amount: number }[];
}): { category: string; amount: number }[] {
  const income = Math.max(0, input.income);
  const lines = new Map<string, number>();
  for (const r of input.recurring ?? []) lines.set(r.category, (lines.get(r.category) ?? 0) + r.amount);
  const fixed = sum([...lines.values()]);

  const discretionary: Record<string, number> = {
    Food: input.typicalFood ?? income * 0.2,
    Travel: input.typicalTravel ?? income * 0.08,
    Education: income * 0.06,
    Personal: income * 0.06,
    Social: income * 0.05,
    Technology: income * 0.03,
    Other: income * 0.03,
  };
  const discTotal = Object.values(discretionary).reduce((a, b) => a + b, 0);
  // keep at least 10% for savings when possible
  const room = Math.max(0, income * 0.9 - fixed);
  const scale = discTotal > room && discTotal > 0 ? room / discTotal : 1;
  for (const [cat, amt] of Object.entries(discretionary)) {
    const val = Math.round((amt * scale) / 50) * 50;
    lines.set(cat, (lines.get(cat) ?? 0) + val);
  }
  const spend = sum([...lines.values()]);
  const out = [...lines.entries()].filter(([, v]) => v > 0).map(([category, amount]) => ({ category, amount: round2(amount) }));
  out.push({ category: SAVINGS_BUDGET, amount: Math.max(0, Math.floor((income - spend) / 50) * 50) });
  return out;
}

/** Copy last month's budget lines into a new month (skips existing categories). */
export function rolloverBudget(budgets: Budget[], fromYear: number, fromMonth: number): { category: string; amount: number }[] {
  return budgetsFor(budgets, fromYear, fromMonth).map((b) => ({ category: b.category, amount: b.amount }));
}

export function monthBounds(year: number, month: number): [string, string] {
  const from = isoFromYM(year, month, 1);
  return [from, monthEnd(from)];
}

export function categorySpentThisMonth(txs: Transaction[], category: string, today: string): number {
  const from = monthStart(today);
  return sum(txs.filter((t) => isExpense(t) && t.category === category && t.date >= from && t.date <= today).map((t) => t.amount));
}

// All dates in the app are calendar dates ("yyyy-MM-dd") interpreted in the
// student's local timezone (default Asia/Kolkata). Working with strings avoids
// UTC-midnight off-by-one bugs between server and browser.

export const DEFAULT_TZ = "Asia/Kolkata";

export function todayISO(tz: string = DEFAULT_TZ, now: Date = new Date()): string {
  const parts = new Intl.DateTimeFormat("en-CA", { timeZone: tz, year: "numeric", month: "2-digit", day: "2-digit" }).formatToParts(now);
  const get = (t: string) => parts.find((p) => p.type === t)!.value;
  return `${get("year")}-${get("month")}-${get("day")}`;
}

export function nowTimeHM(tz: string = DEFAULT_TZ, now: Date = new Date()): string {
  return new Intl.DateTimeFormat("en-GB", { timeZone: tz, hour: "2-digit", minute: "2-digit", hour12: false }).format(now);
}

/** Parse yyyy-MM-dd into a UTC-midnight Date (only used for arithmetic). */
export function d(iso: string): Date {
  const [y, m, day] = iso.slice(0, 10).split("-").map(Number);
  return new Date(Date.UTC(y, m - 1, day));
}

export function iso(date: Date): string {
  return date.toISOString().slice(0, 10);
}

export function addDays(isoDate: string, n: number): string {
  const x = d(isoDate);
  x.setUTCDate(x.getUTCDate() + n);
  return iso(x);
}

export function daysInMonth(year: number, month: number): number {
  return new Date(Date.UTC(year, month, 0)).getUTCDate();
}

/** Add months, clamping the day (Jan 31 + 1 month = Feb 28/29). */
export function addMonths(isoDate: string, n: number): string {
  const [y, m, day] = isoDate.split("-").map(Number);
  const total = y * 12 + (m - 1) + n;
  const ny = Math.floor(total / 12);
  const nm = (total % 12) + 1;
  const nd = Math.min(day, daysInMonth(ny, nm));
  return `${ny}-${String(nm).padStart(2, "0")}-${String(nd).padStart(2, "0")}`;
}

export function diffDays(a: string, b: string): number {
  return Math.round((d(a).getTime() - d(b).getTime()) / 86_400_000);
}

export function monthStart(isoDate: string): string {
  return isoDate.slice(0, 8) + "01";
}

export function monthEnd(isoDate: string): string {
  const [y, m] = isoDate.split("-").map(Number);
  return `${isoDate.slice(0, 8)}${String(daysInMonth(y, m)).padStart(2, "0")}`;
}

export function ym(isoDate: string): { year: number; month: number } {
  const [y, m] = isoDate.split("-").map(Number);
  return { year: y, month: m };
}

export function monthKey(isoDate: string): string {
  return isoDate.slice(0, 7);
}

export function isoFromYM(year: number, month: number, day = 1): string {
  return `${year}-${String(month).padStart(2, "0")}-${String(day).padStart(2, "0")}`;
}

/** Monday-based week start. */
export function weekStart(isoDate: string): string {
  const dow = (d(isoDate).getUTCDay() + 6) % 7; // 0 = Monday
  return addDays(isoDate, -dow);
}

export function weekEnd(isoDate: string): string {
  return addDays(weekStart(isoDate), 6);
}

export function inRange(date: string, from: string, to: string): boolean {
  return date >= from && date <= to;
}

export function eachDay(from: string, to: string): string[] {
  const out: string[] = [];
  for (let cur = from; cur <= to; cur = addDays(cur, 1)) out.push(cur);
  return out;
}

/** Fractional months between two dates (30.44-day months), never negative. */
export function monthsBetween(from: string, to: string): number {
  return Math.max(0, diffDays(to, from) / 30.4375);
}

const MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
const MONTHS_LONG = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];

export function fmtDate(isoDate: string, opts: { year?: boolean } = {}): string {
  const { year, month } = ym(isoDate);
  const day = Number(isoDate.slice(8, 10));
  return `${day} ${MONTHS[month - 1]}${opts.year ? ` ${year}` : ""}`;
}

export function fmtMonth(year: number, month: number, long = true): string {
  return `${(long ? MONTHS_LONG : MONTHS)[month - 1]} ${year}`;
}

export function fmtMonthShort(key: string): string {
  const [y, m] = key.split("-").map(Number);
  return `${MONTHS[m - 1]} ${String(y).slice(2)}`;
}

export function weekdayShort(isoDate: string): string {
  return ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"][d(isoDate).getUTCDay()];
}

export function ymdMax(a: string, b: string): string {
  return a > b ? a : b;
}

export function ymdMin(a: string, b: string): string {
  return a < b ? a : b;
}

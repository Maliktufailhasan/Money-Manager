import type { Snapshot } from "../types";
import { summarize, type PeriodSummary } from "./aggregate";
import { budgetReport } from "./budget";
import { addDays, addMonths, fmtDate, fmtMonth, isoFromYM, monthEnd, weekStart, ym } from "./dates";
import { goalMetrics } from "./goals";
import { generateInsights, type Insight } from "./insights";
import { round2, sum } from "./money";
import { financialPosition } from "./position";
import { recurringMonthlyBurden, subscriptionMonthlyCost } from "./schedule";
import { detectWaste } from "./waste";

const fmt = (n: number) => `₹${Math.round(n).toLocaleString("en-IN")}`;

export interface WeeklyReview {
  from: string;
  to: string;
  label: string;
  summary: PeriodSummary;
  previous: PeriodSummary;
  topCategory: { name: string; amount: number } | null;
  unnecessary: number; // wants
  budgetStatus: string;
  goalProgress: number; // contributions this week
  suggestion: string;
}

export function weeklyReview(s: Snapshot, anyDayInWeek: string, today: string): WeeklyReview {
  const from = weekStart(anyDayInWeek);
  const to = addDays(from, 6);
  const summary = summarize(s.transactions, from, to);
  const previous = summarize(s.transactions, addDays(from, -7), addDays(from, -1));
  const { year, month } = ym(to > today ? today : to);
  const br = budgetReport(s.budgets, s.transactions, year, month, today);
  const over = br.rows.filter((r) => r.state === "over").map((r) => r.category);
  const near = br.rows.filter((r) => r.state === "near").map((r) => r.category);
  const budgetStatus = !br.hasBudget ? "No budget set" : over.length ? `Over budget: ${over.join(", ")}` : near.length ? `Near limit: ${near.join(", ")}` : "Within budget";
  const goalProgress = sum(s.contributions.filter((c) => c.date >= from && c.date <= to).map((c) => c.amount));

  const wasteTop = detectWaste(s.transactions.filter((t) => t.date <= to), [], to)[0];
  let suggestion = "Keep logging every expense — consistent tracking is what makes the numbers useful.";
  if (wasteTop) suggestion = `Reducing ${wasteTop.title.toLowerCase()} could increase weekly savings by about ${fmt(wasteTop.monthlySaving / 4.35)}.`;
  else if (summary.wants > summary.needs && summary.wants > 0) suggestion = "Wants outweighed needs this week — try planning one no-spend day next week.";
  else if (summary.saved > previous.saved && summary.saved > 0) suggestion = "You saved more than last week. Consider moving the extra into a goal.";

  return {
    from,
    to,
    label: `${fmtDate(from)} – ${fmtDate(to)}`,
    summary,
    previous,
    topCategory: summary.byCategory[0] ? { name: summary.byCategory[0].name, amount: summary.byCategory[0].amount } : null,
    unnecessary: summary.wants,
    budgetStatus,
    goalProgress,
    suggestion,
  };
}

export interface MonthlyReport {
  year: number;
  month: number;
  label: string;
  summary: PeriodSummary;
  previous: PeriodSummary;
  budget: ReturnType<typeof budgetReport>;
  goals: { name: string; target: number; saved: number; addedThisMonth: number; pct: number; status: string }[];
  subscriptionsMonthly: number;
  recurringMonthly: number;
  insights: Insight[];
  adjustments: string[];
  highest: { name: string; amount: number } | null;
  lowest: { name: string; amount: number } | null;
}

export function monthlyReport(s: Snapshot, year: number, month: number, today: string): MonthlyReport {
  const from = isoFromYM(year, month, 1);
  const to = monthEnd(from);
  const summary = summarize(s.transactions, from, to);
  const prevFrom = addMonths(from, -1);
  const previous = summarize(s.transactions, prevFrom, monthEnd(prevFrom));
  const budget = budgetReport(s.budgets, s.transactions, year, month, today);
  const refDay = to < today ? to : today;
  const pos = financialPosition(s, refDay);

  const goals = s.goals.map((g) => {
    const m = goalMetrics(g, s.contributions, refDay);
    return {
      name: g.name,
      target: g.target_amount,
      saved: g.current_amount,
      addedThisMonth: sum(s.contributions.filter((c) => c.goal_id === g.id && c.date >= from && c.date <= to).map((c) => c.amount)),
      pct: m.progressPct,
      status: m.status.replace("_", " "),
    };
  });

  const adjustments: string[] = [];
  for (const r of budget.rows.filter((r) => r.state === "over")) adjustments.push(`${r.category} went ${fmt(r.spent - r.budget)} over budget — either raise the ${r.category} budget to about ${fmt(Math.ceil(r.spent / 100) * 100)} or plan specific cuts.`);
  for (const r of budget.rows.filter((r) => r.state === "unbudgeted" && r.spent >= 300)) adjustments.push(`Add a budget for ${r.category} (you spent ${fmt(r.spent)} without one).`);
  for (const w of detectWaste(s.transactions.filter((t) => t.date <= to), s.subscriptions, refDay, summary.received).slice(0, 2)) adjustments.push(`${w.title}: ${w.alternatives[0]} — could save ~${fmt(w.monthlySaving)}/month.`);
  if (summary.savingsRate !== null && summary.savingsRate < 20) adjustments.push(`Savings rate was ${Math.round(summary.savingsRate)}%. Aim for 20% next month by setting a Savings budget of ${fmt(summary.received * 0.2)}.`);
  if (!adjustments.length) adjustments.push("Good month. Keep the same budget and consider raising your savings target slightly.");

  const nonZero = summary.byCategory.filter((c) => c.amount > 0);
  return {
    year,
    month,
    label: fmtMonth(year, month),
    summary,
    previous,
    budget,
    goals,
    subscriptionsMonthly: round2(sum(s.subscriptions.map(subscriptionMonthlyCost))),
    recurringMonthly: recurringMonthlyBurden(s),
    insights: generateInsights({ ...s, transactions: s.transactions.filter((t) => t.date <= to) }, refDay, pos),
    adjustments,
    highest: nonZero[0] ? { name: nonZero[0].name, amount: nonZero[0].amount } : null,
    lowest: nonZero.length > 1 ? { name: nonZero[nonZero.length - 1].name, amount: nonZero[nonZero.length - 1].amount } : null,
  };
}

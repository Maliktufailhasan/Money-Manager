import type { BillingCycle, Reminder, ReminderRecurrence, Snapshot, Subscription } from "../types";
import { addDays, addMonths, diffDays } from "./dates";
import { sum } from "./money";

export function advance(date: string, cycle: BillingCycle | ReminderRecurrence, times = 1): string {
  switch (cycle) {
    case "weekly":
      return addDays(date, 7 * times);
    case "monthly":
      return addMonths(date, times);
    case "quarterly":
      return addMonths(date, 3 * times);
    case "yearly":
      return addMonths(date, 12 * times);
    default:
      return date;
  }
}

/** How many times per month a cycle bills. */
export function monthlyFactor(cycle: BillingCycle | ReminderRecurrence): number {
  switch (cycle) {
    case "weekly":
      return 52 / 12;
    case "monthly":
      return 1;
    case "quarterly":
      return 1 / 3;
    case "yearly":
      return 1 / 12;
    default:
      return 0;
  }
}

export function subscriptionMonthlyCost(s: Subscription): number {
  return s.status === "active" ? s.amount * monthlyFactor(s.billing_cycle) : 0;
}

export interface UpcomingPayment {
  key: string;
  source: "subscription" | "reminder";
  refId: string;
  title: string;
  amount: number;
  date: string;
  daysAway: number; // negative = overdue
  category: string;
  kind: string;
}

/** Expand active subscriptions and open reminders into dated payments within [from, to]. Overdue reminders are always included. */
export function upcomingPayments(s: Pick<Snapshot, "subscriptions" | "reminders">, today: string, to: string): UpcomingPayment[] {
  const out: UpcomingPayment[] = [];
  for (const sub of s.subscriptions) {
    if (sub.status !== "active") continue;
    let date = sub.next_payment_date;
    // a stale next_payment_date is rolled forward to the next real occurrence
    let guard = 0;
    while (date < today && guard++ < 500) date = advance(date, sub.billing_cycle);
    while (date <= to && guard++ < 1000) {
      out.push({ key: `s-${sub.id}-${date}`, source: "subscription", refId: sub.id, title: sub.name, amount: sub.amount, date, daysAway: diffDays(date, today), category: sub.category, kind: "Subscription" });
      date = advance(date, sub.billing_cycle);
    }
  }
  for (const r of s.reminders) {
    if (r.completed) continue;
    let date = r.due_date;
    let first = true;
    let guard = 0;
    while (date <= to && guard++ < 1000) {
      if (date >= today || first) {
        out.push({ key: `r-${r.id}-${date}`, source: "reminder", refId: r.id, title: r.title, amount: r.amount, date, daysAway: diffDays(date, today), category: r.category, kind: r.kind });
      }
      first = false;
      if (r.recurring === "none") break;
      date = advance(date, r.recurring);
    }
  }
  return out.sort((a, b) => a.date.localeCompare(b.date) || b.amount - a.amount);
}

export function totalDue(list: UpcomingPayment[]): number {
  return sum(list.map((p) => p.amount));
}

/** Monthly cost of all recurring commitments (subscriptions + recurring reminders). */
export function recurringMonthlyBurden(s: Pick<Snapshot, "subscriptions" | "reminders">): number {
  const subs = s.subscriptions.map(subscriptionMonthlyCost);
  const rems = s.reminders.filter((r: Reminder) => r.recurring !== "none" && !r.completed).map((r) => r.amount * monthlyFactor(r.recurring));
  return sum([...subs, ...rems]);
}

import type { Goal, Snapshot } from "../types";
import { currentBalance, summarize } from "./aggregate";
import { addMonths, diffDays, monthEnd, monthStart, monthsBetween, ymdMax } from "./dates";
import { round2, sum } from "./money";
import { recurringMonthlyBurden } from "./schedule";

export type DataQuality = "none" | "limited" | "good";

export interface FinancialPosition {
  today: string;
  balance: number;
  /** average monthly money received (excl. refunds) */
  avgMonthlyIncome: number;
  avgMonthlyExpense: number;
  avgNeeds: number;
  avgWants: number;
  /** wants + unclassified non-essential spending that could be reduced */
  reducibleMonthly: number;
  recurringMonthly: number;
  savingCapacity: number; // avgIncome - avgExpense
  savingsRate: number | null;
  /** monthly saving already needed by other active goals with deadlines */
  committedToGoals: number;
  monthsOfData: number;
  basis: string; // human description of where averages come from
  dataQuality: DataQuality;
  isEstimate: boolean;
}

/**
 * Builds the student's financial position from recorded data. Uses up to the
 * last three complete months; with less history it falls back to the current
 * month (expenses projected to a full month) plus the onboarding estimate for
 * income, and says so.
 */
export function financialPosition(s: Snapshot, today: string): FinancialPosition {
  const balance = currentBalance(s);
  const firstDate = s.totals.first_date;
  const recurringMonthly = recurringMonthlyBurden(s);
  const committedToGoals = goalsMonthlyCommitment(s.goals, today);

  const base = { today, balance, recurringMonthly, committedToGoals };

  if (!firstDate || s.totals.tx_count === 0) {
    const inc = Number(s.profile.monthly_income_estimate || 0);
    return {
      ...base,
      avgMonthlyIncome: inc,
      avgMonthlyExpense: recurringMonthly,
      avgNeeds: recurringMonthly,
      avgWants: 0,
      reducibleMonthly: 0,
      savingCapacity: round2(inc - recurringMonthly),
      savingsRate: inc ? round2(((inc - recurringMonthly) / inc) * 100) : null,
      monthsOfData: 0,
      basis: inc ? "No transactions yet — using the monthly income you entered during setup." : "No transactions recorded yet.",
      dataQuality: "none",
      isEstimate: true,
    };
  }

  // complete months between first transaction and last month
  const thisMonth = monthStart(today);
  const firstMonth = monthStart(firstDate);
  const full: string[] = [];
  for (let i = 1; i <= 3; i++) {
    const m = addMonths(thisMonth, -i);
    if (m >= firstMonth) full.push(m);
  }

  if (full.length > 0) {
    const sums = full.map((m) => summarize(s.transactions, m, monthEnd(m)));
    const n = sums.length;
    const avg = (f: (x: (typeof sums)[number]) => number) => round2(sum(sums.map(f)) / n);
    const avgMonthlyIncome = avg((x) => x.received);
    const avgMonthlyExpense = avg((x) => x.spent);
    const avgWants = avg((x) => x.wants);
    return {
      ...base,
      avgMonthlyIncome,
      avgMonthlyExpense,
      avgNeeds: avg((x) => x.needs),
      avgWants,
      reducibleMonthly: round2(Math.max(avgWants, avg((x) => x.nonEssential))),
      savingCapacity: round2(avgMonthlyIncome - avgMonthlyExpense),
      savingsRate: avgMonthlyIncome ? round2(((avgMonthlyIncome - avgMonthlyExpense) / avgMonthlyIncome) * 100) : null,
      monthsOfData: n,
      basis: `Average of your last ${n} complete month${n > 1 ? "s" : ""} of recorded transactions.`,
      dataQuality: n >= 2 ? "good" : "limited",
      isEstimate: false,
    };
  }

  // only the current, partial month: project expenses, take the larger of
  // recorded income and the setup estimate (income is lumpy, don't project it)
  const from = ymdMax(firstDate, thisMonth);
  const elapsed = diffDays(today, from) + 1;
  const mtd = summarize(s.transactions, thisMonth, today);
  const scale = elapsed >= 1 ? 30.4375 / Math.max(elapsed, 7) : 1;
  const est = Number(s.profile.monthly_income_estimate || 0);
  const avgMonthlyIncome = Math.max(mtd.received, est);
  const avgMonthlyExpense = round2(Math.max(mtd.spent * scale, recurringMonthly));
  const avgWants = round2(mtd.wants * scale);
  return {
    ...base,
    avgMonthlyIncome,
    avgMonthlyExpense,
    avgNeeds: round2(mtd.needs * scale),
    avgWants,
    reducibleMonthly: round2(Math.max(avgWants, mtd.nonEssential * scale)),
    savingCapacity: round2(avgMonthlyIncome - avgMonthlyExpense),
    savingsRate: avgMonthlyIncome ? round2(((avgMonthlyIncome - avgMonthlyExpense) / avgMonthlyIncome) * 100) : null,
    monthsOfData: round2(monthsBetween(from, today)),
    basis: `Only ${elapsed} day${elapsed > 1 ? "s" : ""} of data — expenses projected to a full month${avgMonthlyIncome === est && est > 0 ? ", income from your setup estimate" : ""}. Estimates will improve as you record more.`,
    dataQuality: "limited",
    isEstimate: true,
  };
}

/** Sum of monthly saving needed by active goals with a target date. */
export function goalsMonthlyCommitment(goals: Goal[], today: string, excludeId?: string): number {
  return round2(
    sum(
      goals
        .filter((g) => g.status === "active" && g.target_date && g.id !== excludeId)
        .map((g) => {
          const remaining = Math.max(0, g.target_amount - g.current_amount);
          const months = Math.max(1, monthsBetween(today, g.target_date!));
          return remaining / months;
        }),
    ),
  );
}

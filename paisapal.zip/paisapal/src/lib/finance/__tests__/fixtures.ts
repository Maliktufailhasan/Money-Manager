import type { Snapshot, Transaction } from "@/lib/types";

let n = 0;
export function tx(p: Partial<Transaction> & Pick<Transaction, "type" | "amount" | "category" | "date">): Transaction {
  n++;
  return {
    id: `t${n}`,
    subcategory: null,
    income_type: null,
    description: null,
    time: null,
    merchant: null,
    payment_method: null,
    need_or_want: null,
    essential: null,
    recurring: false,
    recurrence: null,
    recurrence_days: null,
    earning_source_id: null,
    notes: null,
    created_at: `${p.date}T10:00:00Z`,
    ...p,
  };
}

export function snapshot(transactions: Transaction[], over: Partial<Snapshot> = {}): Snapshot {
  const inc = transactions.filter((t) => t.type === "income").reduce((a, t) => a + t.amount, 0);
  const exp = transactions.filter((t) => t.type === "expense").reduce((a, t) => a + t.amount, 0);
  const dates = transactions.map((t) => t.date).sort();
  return {
    profile: { id: "u", name: "Test", email: null, currency: "INR", opening_balance: 0, monthly_income_estimate: 0, daily_limit: null, onboarded: true, preferences: {}, created_at: "2026-01-01" },
    totals: { total_income: inc, total_expense: exp, first_date: dates[0] ?? null, tx_count: transactions.length },
    transactions,
    windowStart: "2025-01-01",
    budgets: [],
    goals: [],
    contributions: [],
    subscriptions: [],
    reminders: [],
    noSpendRules: [],
    earningSources: [],
    categories: [],
    ...over,
  };
}

import { describe, expect, it } from "vitest";
import {
  addMonths, affordability, budgetReport, currentBalance, detectWaste, financialPosition, goalMetrics, monthlySeries,
  planFromZero, ruleProgress, safeToSpend, suggestBudget, summarize, upcomingPayments, weekStart, whatIf, streaks,
  computeAlerts, generateInsights, sum, todayISO, balanceSeries, violatedRules,
} from "@/lib/finance";
import type { Goal, NoSpendRule } from "@/lib/types";
import { snapshot, tx } from "./fixtures";

const TODAY = "2026-10-15";

describe("money & dates", () => {
  it("sums without float drift", () => {
    expect(sum([0.1, 0.2, 0.3])).toBe(0.6);
    expect(sum(Array(1000).fill(0.01))).toBe(10);
  });
  it("clamps month arithmetic", () => {
    expect(addMonths("2026-01-31", 1)).toBe("2026-02-28");
    expect(addMonths("2028-01-31", 1)).toBe("2028-02-29");
    expect(addMonths("2026-12-15", 1)).toBe("2027-01-15");
    expect(addMonths("2026-01-15", -1)).toBe("2025-12-15");
  });
  it("uses Monday week starts", () => {
    expect(weekStart("2026-10-15")).toBe("2026-10-12"); // Thursday → Monday
    expect(weekStart("2026-10-18")).toBe("2026-10-12"); // Sunday
  });
  it("computes today in IST", () => {
    expect(todayISO("Asia/Kolkata", new Date("2026-10-02T20:00:00Z"))).toBe("2026-10-03");
  });
});

describe("summaries & balance", () => {
  const txs = [
    tx({ type: "income", amount: 15000, category: "Pocket Money", date: "2026-10-01" }),
    tx({ type: "expense", amount: 4000, category: "Food", subcategory: "Mess", date: "2026-10-02", need_or_want: "need", essential: true }),
    tx({ type: "expense", amount: 2550, category: "Social", subcategory: "Cafes", date: "2026-10-05", need_or_want: "want", essential: false }),
    tx({ type: "income", amount: 500, category: "Refunds", date: "2026-10-06" }),
  ];
  it("treats refunds as negative spending, not money received", () => {
    const s = summarize(txs, "2026-10-01", "2026-10-31");
    expect(s.received).toBe(15000);
    expect(s.grossSpent).toBe(6550);
    expect(s.spent).toBe(6050);
    expect(s.saved).toBe(8950);
    expect(s.savingsRate).toBeCloseTo(59.67, 2);
    expect(s.needs).toBe(4000);
    expect(s.wants).toBe(2550);
    expect(s.byCategory[0]).toMatchObject({ name: "Food", amount: 4000 });
  });
  it("balance = opening + income - expenses", () => {
    const snap = snapshot(txs);
    snap.profile.opening_balance = 1000;
    expect(currentBalance(snap)).toBe(1000 + 15500 - 6550);
  });
  it("savings rate is null with zero income", () => {
    const s = summarize([tx({ type: "expense", amount: 10, category: "Food", date: "2026-10-01" })], "2026-10-01", "2026-10-31");
    expect(s.savingsRate).toBeNull();
    expect(s.saved).toBe(-10);
  });
  it("monthly series has one point per month", () => {
    const series = monthlySeries(txs, 6, TODAY);
    expect(series).toHaveLength(6);
    expect(series.at(-1)).toMatchObject({ key: "2026-10", income: 15000, expense: 6050 });
  });
  it("balance series ends at current balance", () => {
    const snap = snapshot(txs);
    const series = balanceSeries(snap, "2026-09-30", TODAY);
    expect(series[0].balance).toBe(0);
    expect(series.at(-1)!.balance).toBe(currentBalance(snap));
  });
});

describe("budgets & safe-to-spend", () => {
  const txs = [
    tx({ type: "income", amount: 15000, category: "Pocket Money", date: "2026-10-01" }),
    tx({ type: "expense", amount: 2610, category: "Food", date: "2026-10-10" }),
    tx({ type: "expense", amount: 1600, category: "Travel", date: "2026-10-11" }),
    tx({ type: "expense", amount: 300, category: "Social", date: "2026-10-11" }),
  ];
  const budgets = [
    { id: "1", category: "Food", amount: 3000, month: 10, year: 2026 },
    { id: "2", category: "Travel", amount: 1500, month: 10, year: 2026 },
    { id: "3", category: "Savings", amount: 7000, month: 10, year: 2026 },
  ];
  it("classifies under/near/over and unbudgeted", () => {
    const r = budgetReport(budgets, txs, 2026, 10, TODAY);
    const by = Object.fromEntries(r.rows.map((x) => [x.category, x.state]));
    expect(by).toEqual({ Food: "near", Travel: "over", Social: "unbudgeted" });
    expect(r.savingsTarget).toBe(7000);
    expect(r.totalBudget).toBe(4500);
  });
  it("safe-to-spend subtracts bills and unmet savings target, capped by budget", () => {
    const snap = snapshot(txs, {
      budgets,
      reminders: [{ id: "r", title: "Internet", amount: 499, due_date: "2026-10-20", recurring: "monthly", kind: "Internet", category: "Technology", completed: false, notes: null, created_at: "" }],
    });
    const bal = currentBalance(snap); // 10490
    const sts = safeToSpend(snap, TODAY, bal);
    expect(sts.upcomingThisMonth).toBe(499);
    expect(sts.daysLeft).toBe(17);
    // saved so far 10490 >= 7000, so nothing still to set aside; budgeted lines have
    // 4500 − (2610 + 1600) = 290 left; the Internet bill is in an unbudgeted category
    expect(sts.savingsStillToSet).toBe(0);
    expect(sts.limitedBy).toBe("budget");
    expect(sts.remainingBudget).toBe(290);
    expect(sts.daily).toBe(Math.floor(290 / 17));
  });
  it("ignores bills in unbudgeted categories when capping by budget", () => {
    const snap = snapshot([tx({ type: "income", amount: 20000, category: "Parents", date: "2026-10-01" }), tx({ type: "expense", amount: 500, category: "Food", date: "2026-10-02" })], {
      budgets: [{ id: "1", category: "Food", amount: 3000, month: 10, year: 2026 }],
      reminders: [{ id: "r", title: "Hostel", amount: 5000, due_date: "2026-10-20", recurring: "none", kind: "Hostel Fees", category: "Housing", completed: false, notes: null, created_at: "" }],
    });
    const sts = safeToSpend(snap, TODAY, currentBalance(snap));
    expect(sts.limitedBy).toBe("budget");
    expect(sts.remainingBudget).toBe(2500);
    expect(sts.daily).toBe(Math.floor(2500 / 17));
  });
  it("suggests a budget that fits the income", () => {
    const b = suggestBudget({ income: 15000, typicalFood: 3000, typicalTravel: 1500, recurring: [{ category: "Technology", amount: 499 }] });
    const total = b.reduce((a, x) => a + x.amount, 0);
    expect(total).toBeLessThanOrEqual(15000);
    expect(b.find((x) => x.category === "Savings")!.amount).toBeGreaterThan(0);
    expect(b.find((x) => x.category === "Food")!.amount).toBe(3000);
  });
  it("scales discretionary lines down when the income is tight", () => {
    const b = suggestBudget({ income: 3000, typicalFood: 5000, recurring: [{ category: "Housing", amount: 2000 }] });
    expect(b.reduce((a, x) => a + x.amount, 0)).toBeLessThanOrEqual(3000);
  });
});

describe("recurring payments", () => {
  it("expands subscriptions and rolls stale dates forward", () => {
    const snap = snapshot([], {
      subscriptions: [{ id: "s", name: "Spotify", amount: 59, billing_cycle: "monthly", next_payment_date: "2026-08-05", category: "Technology", status: "active", remind_days_before: 2, notes: null, created_at: "" }],
    });
    const list = upcomingPayments(snap, TODAY, "2026-12-31");
    expect(list.map((p) => p.date)).toEqual(["2026-11-05", "2026-12-05"]);
  });
  it("keeps overdue reminders", () => {
    const snap = snapshot([], { reminders: [{ id: "r", title: "Hostel", amount: 5000, due_date: "2026-10-10", recurring: "none", kind: "Hostel Fees", category: "Housing", completed: false, notes: null, created_at: "" }] });
    const list = upcomingPayments(snap, TODAY, "2026-10-31");
    expect(list).toHaveLength(1);
    expect(list[0].daysAway).toBe(-5);
  });
});

describe("goals & planning", () => {
  const goal: Goal = { id: "g", name: "New Phone", target_amount: 25000, current_amount: 5000, target_date: "2027-06-30", priority: "high", category: "Phone", is_emergency: false, status: "active", notes: null, created_at: "" };
  it("computes remaining and required saving", () => {
    const m = goalMetrics(goal, [], "2026-09-30");
    expect(m.remaining).toBe(20000);
    expect(m.progressPct).toBe(20);
    expect(m.requiredMonthly).toBeGreaterThan(2200);
    expect(m.requiredMonthly).toBeLessThan(2300);
  });
  it("marks overdue and completed goals", () => {
    expect(goalMetrics({ ...goal, target_date: "2026-01-01" }, [], TODAY).status).toBe("overdue");
    expect(goalMetrics({ ...goal, current_amount: 25000 }, [], TODAY).status).toBe("completed");
  });
  it("affordability scenarios match the spec example", () => {
    const r = affordability({ price: 60000, currentMoney: 5000, monthlyIncome: 15000, monthlyExpenses: 8000, targetMonths: 8, reduction: 2000, extraIncome: 3000 }, TODAY);
    expect(r.required).toBe(55000);
    expect(r.monthlyNeeded).toBe(6875);
    expect(r.scenarios.map((s) => s.monthlySaving)).toEqual([7000, 9000, 10000, 12000]);
    expect(r.verdict).toBe("on_track");
    expect(r.scenarios[2].speculative).toBe(true);
  });
  it("affordability flags unrealistic plans", () => {
    const r = affordability({ price: 100000, currentMoney: 0, monthlyIncome: 5000, monthlyExpenses: 6000, targetMonths: 3, reduction: 500, extraIncome: 1000 }, TODAY);
    expect(r.verdict).toBe("unrealistic");
    expect(r.scenarios[0].months).toBeNull();
  });
  it("plans from ₹0 with savings + cuts + extra income", () => {
    const pos = { today: TODAY, balance: 0, avgMonthlyIncome: 12000, avgMonthlyExpense: 8000, avgNeeds: 3000, avgWants: 5000, reducibleMonthly: 5000, recurringMonthly: 0, savingCapacity: 4000, savingsRate: 33, committedToGoals: 0, monthsOfData: 3, basis: "test", dataQuality: "good" as const, isEstimate: false };
    const p = planFromZero({ item: "Laptop", price: 40000, months: 6, startingAmount: 0, incomePotential: 2000 }, pos);
    expect(p.savingPart).toBe(4000);
    expect(p.reduction).toBe(1500);
    expect(p.extraIncome).toBe(1200);
    expect(p.totals.total).toBeGreaterThanOrEqual(40000);
    expect(p.feasibility).toBe("needs_income");
    expect(p.steps).toHaveLength(9);
  });
  it("what-if matches the spec arithmetic", () => {
    expect(whatIf({ kind: "stop_daily", amount: 100 })).toMatchObject({ monthly: 3000, yearly: 36000 });
    expect(whatIf({ kind: "reduce_category", category: "Food", percent: 20, categoryMonthly: 3000 }).monthly).toBe(600);
  });
});

describe("position", () => {
  it("averages complete months", () => {
    const txs = [
      tx({ type: "income", amount: 10000, category: "Parents", date: "2026-08-01" }),
      tx({ type: "expense", amount: 6000, category: "Food", date: "2026-08-10", need_or_want: "want" }),
      tx({ type: "income", amount: 12000, category: "Parents", date: "2026-09-01" }),
      tx({ type: "expense", amount: 8000, category: "Food", date: "2026-09-10", need_or_want: "need" }),
    ];
    const pos = financialPosition(snapshot(txs), TODAY);
    expect(pos.avgMonthlyIncome).toBe(11000);
    expect(pos.avgMonthlyExpense).toBe(7000);
    expect(pos.savingCapacity).toBe(4000);
    expect(pos.dataQuality).toBe("good");
  });
  it("is explicit about having no data", () => {
    const snap = snapshot([]);
    snap.profile.monthly_income_estimate = 8000;
    const pos = financialPosition(snap, TODAY);
    expect(pos.dataQuality).toBe("none");
    expect(pos.isEstimate).toBe(true);
    expect(pos.avgMonthlyIncome).toBe(8000);
  });
});

describe("waste, no-spend, streaks, alerts, insights", () => {
  const days = Array.from({ length: 12 }, (_, i) => `2026-10-${String(i + 1).padStart(2, "0")}`);
  const txs = [
    tx({ type: "income", amount: 15000, category: "Pocket Money", date: "2026-09-01" }),
    tx({ type: "expense", amount: 9000, category: "Food", date: "2026-09-03" }),
    tx({ type: "income", amount: 15000, category: "Pocket Money", date: "2026-10-01" }),
    ...days.map((d) => tx({ type: "expense", amount: 60, category: "Food", subcategory: "Snacks", date: d, need_or_want: "want" })),
    ...days.slice(0, 4).map((d) => tx({ type: "expense", amount: 350, category: "Food", subcategory: "Delivery", merchant: "Swiggy", date: d, need_or_want: "want" })),
  ];
  it("finds delivery and snack patterns with savings estimates", () => {
    const w = detectWaste(txs, [], TODAY);
    const ids = w.map((x) => x.id);
    expect(ids).toContain("delivery");
    expect(ids).toContain("snacks");
    const delivery = w.find((x) => x.id === "delivery")!;
    expect(delivery.amount).toBe(1400);
    expect(delivery.monthlySaving).toBe(700);
  });
  it("tracks no-spend rule savings and violations", () => {
    const rule: NoSpendRule = { id: "n", title: "No delivery", category: "Food", subcategory: "Delivery", start_date: "2026-10-05", end_date: "2026-10-31", limit_amount: 0, baseline_monthly: 3000, active: true, created_at: "" };
    const p = ruleProgress(rule, txs, TODAY);
    expect(p.state).toBe("active");
    expect(p.spent).toBe(0); // deliveries were on 1st-4th
    expect(p.daysElapsed).toBe(11);
    expect(p.estimatedSaved).toBeCloseTo((3000 / 30.4375) * 11, 0);
    expect(violatedRules([rule], { category: "Food", subcategory: "Delivery", date: TODAY })).toHaveLength(1);
    expect(violatedRules([rule], { category: "Food", subcategory: "Mess", date: TODAY })).toHaveLength(0);
  });
  it("counts tracking streaks", () => {
    const st = streaks(txs, [], "2026-10-13", null, "2026-09-01");
    expect(st.trackingDays).toBe(12); // 1st..12th, today not yet logged
    expect(st.savingsMonths).toBe(1);
  });
  it("raises budget alerts at 87%", () => {
    const snap = snapshot([tx({ type: "expense", amount: 2610, category: "Food", date: "2026-10-10" })], { budgets: [{ id: "b", category: "Food", amount: 3000, month: 10, year: 2026 }] });
    const alerts = computeAlerts(snap, TODAY, 0, null);
    expect(alerts.find((a) => a.kind === "budget")!.text).toContain("87%");
  });
  it("respects disabled alert preferences", () => {
    const snap = snapshot([tx({ type: "expense", amount: 2610, category: "Food", date: "2026-10-10" })], { budgets: [{ id: "b", category: "Food", amount: 3000, month: 10, year: 2026 }] });
    snap.profile.preferences = { alerts: { budget: false } };
    expect(computeAlerts(snap, TODAY, 0, null).some((a) => a.kind === "budget")).toBe(false);
  });
  it("skips percentage comparisons in the first days of a month", () => {
    const snap = snapshot([
      tx({ type: "expense", amount: 35, category: "Travel", date: "2026-09-02" }),
      tx({ type: "expense", amount: 415, category: "Travel", date: "2026-10-02" }),
    ]);
    expect(generateInsights(snap, "2026-10-03", financialPosition(snap, "2026-10-03")).some((i) => i.id.startsWith("cat-"))).toBe(false);
  });
  it("generates comparison insights from data", () => {
    const snap = snapshot([
      tx({ type: "expense", amount: 1000, category: "Food", date: "2026-09-05" }),
      tx({ type: "expense", amount: 1220, category: "Food", date: "2026-10-05" }),
      tx({ type: "income", amount: 5000, category: "Parents", date: "2026-10-01" }),
    ]);
    const ins = generateInsights(snap, TODAY, financialPosition(snap, TODAY));
    expect(ins.find((i) => i.id === "cat-Food")!.text).toContain("increased 22%");
  });
});

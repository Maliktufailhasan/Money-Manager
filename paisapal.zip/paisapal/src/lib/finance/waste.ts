import type { Subscription, Transaction } from "../types";
import { isExpense, txInRange } from "./aggregate";
import { addDays } from "./dates";
import { round2, sum } from "./money";
import { subscriptionMonthlyCost } from "./schedule";

export interface WasteFinding {
  id: string;
  title: string;
  detail: string;
  amount: number; // spent in the window
  count: number;
  /** suggested reduction share */
  cutPct: number;
  monthlySaving: number;
  yearlySaving: number;
  alternatives: string[];
  severity: "high" | "medium" | "low";
}

const has = (t: Transaction, re: RegExp) => re.test(`${t.merchant ?? ""} ${t.description ?? ""}`);
const DELIVERY = /swiggy|zomato|zepto|blinkit|instamart|dunzo|eatsure|delivery/i;
const CAFE = /starbucks|ccd|cafe coffee day|chaayos|third wave|blue tokai|barista|costa|cafe|café/i;
const SHOP = /amazon|flipkart|myntra|ajio|meesho|nykaa|shopping/i;

interface Pattern {
  id: string;
  title: string;
  match: (t: Transaction) => boolean;
  minCount: number;
  minAmount: number;
  cutPct: number;
  alternatives: string[];
  describe: (amount: number, count: number) => string;
}

const fmt = (n: number) => `₹${Math.round(n).toLocaleString("en-IN")}`;

const PATTERNS: Pattern[] = [
  {
    id: "delivery",
    title: "Food delivery",
    match: (t) => t.subcategory === "Delivery" || has(t, DELIVERY),
    minCount: 3,
    minAmount: 500,
    cutPct: 50,
    alternatives: ["Keep delivery for one planned treat a week", "Cook simple meals or eat at the mess on weekdays", "Order with friends to split delivery fees", "Delete the app from your home screen for a month"],
    describe: (a, c) => `You ordered food delivery ${c} times, spending ${fmt(a)} in the last 30 days.`,
  },
  {
    id: "cafe",
    title: "Café & tea/coffee runs",
    match: (t) => t.subcategory === "Tea/Coffee" || t.subcategory === "Cafes" || has(t, CAFE),
    minCount: 4,
    minAmount: 400,
    cutPct: 30,
    alternatives: ["Carry a flask from the hostel/mess", "Use the college canteen instead of branded cafés", "Make café visits a weekly social plan, not a daily habit"],
    describe: (a, c) => `${c} café/tea/coffee purchases added up to ${fmt(a)} in the last 30 days.`,
  },
  {
    id: "snacks",
    title: "Snacks & fast food",
    match: (t) => t.subcategory === "Snacks" || t.subcategory === "Fast Food" || t.subcategory === "Street Food",
    minCount: 5,
    minAmount: 500,
    cutPct: 30,
    alternatives: ["Buy snacks in bulk from a grocery store instead of single packs", "Keep fruit or homemade snacks in your bag", "Set a weekly snack allowance"],
    describe: (a, c) => `${c} snack/fast-food purchases cost ${fmt(a)} in the last 30 days.`,
  },
  {
    id: "shopping",
    title: "Frequent shopping",
    match: (t) => ["Shopping", "Clothes", "Accessories", "Perfume", "Beauty"].includes(t.subcategory ?? "") || has(t, SHOP),
    minCount: 3,
    minAmount: 1000,
    cutPct: 40,
    alternatives: ["Use a 48-hour rule before buying non-essentials", "Unsubscribe from sale notifications", "Make a needs list before opening shopping apps"],
    describe: (a, c) => `${c} shopping purchases totalled ${fmt(a)} in the last 30 days.`,
  },
  {
    id: "entertainment",
    title: "Entertainment & outings",
    match: (t) => ["Entertainment", "Movies", "Parties", "Events"].includes(t.subcategory ?? ""),
    minCount: 3,
    minAmount: 800,
    cutPct: 30,
    alternatives: ["Look for student discounts and weekday shows", "Try free campus events and clubs", "Plan one paid outing a week and keep the rest free"],
    describe: (a, c) => `${c} entertainment/outing expenses came to ${fmt(a)} in the last 30 days.`,
  },
  {
    id: "transport",
    title: "Cabs & autos",
    match: (t) => t.category === "Travel" && ["Cab", "Auto"].includes(t.subcategory ?? ""),
    minCount: 4,
    minAmount: 600,
    cutPct: 40,
    alternatives: ["Use bus/metro passes for regular routes", "Share rides with classmates going the same way", "Leave 15 minutes earlier to avoid last-minute cabs"],
    describe: (a, c) => `${c} cab/auto rides cost ${fmt(a)} in the last 30 days.`,
  },
];

/**
 * Finds spending patterns worth reviewing over the last 30 days. Every number
 * comes from recorded transactions; suggestions are framed as options.
 */
export function detectWaste(txs: Transaction[], subscriptions: Subscription[], today: string, monthlyIncome = 0): WasteFinding[] {
  const from = addDays(today, -29);
  const window = txInRange(txs, from, today).filter(isExpense);
  const totalSpent = sum(window.map((t) => t.amount));
  const out: WasteFinding[] = [];
  const claimed = new Set<string>();

  for (const p of PATTERNS) {
    const hits = window.filter((t) => !claimed.has(t.id) && p.match(t));
    const amount = sum(hits.map((t) => t.amount));
    if (hits.length >= p.minCount || amount >= p.minAmount) {
      if (amount < 200) continue;
      hits.forEach((t) => claimed.add(t.id));
      const monthlySaving = round2((amount * p.cutPct) / 100);
      out.push({
        id: p.id,
        title: p.title,
        detail: `${p.describe(amount, hits.length)} Reducing this by ${p.cutPct}% could save about ${fmt(monthlySaving)}/month.`,
        amount,
        count: hits.length,
        cutPct: p.cutPct,
        monthlySaving,
        yearlySaving: round2(monthlySaving * 12),
        alternatives: p.alternatives,
        severity: totalSpent && amount / totalSpent > 0.15 ? "high" : amount / Math.max(totalSpent, 1) > 0.07 ? "medium" : "low",
      });
    }
  }

  // many small purchases (< ₹100)
  const small = window.filter((t) => t.amount < 100);
  const smallAmt = sum(small.map((t) => t.amount));
  if (small.length >= 10 && smallAmt >= 500) {
    const monthlySaving = round2(smallAmt * 0.25);
    out.push({
      id: "small",
      title: "Frequent small purchases",
      detail: `${small.length} purchases under ₹100 added up to ${fmt(smallAmt)} in the last 30 days${totalSpent ? ` (${Math.round((smallAmt / totalSpent) * 100)}% of spending)` : ""}. Cutting a quarter of them saves ~${fmt(monthlySaving)}/month.`,
      amount: smallAmt,
      count: small.length,
      cutPct: 25,
      monthlySaving,
      yearlySaving: round2(monthlySaving * 12),
      alternatives: ["Set a small daily cash/UPI allowance for little things", "Pause and log before each small purchase — awareness alone cuts many"],
      severity: smallAmt / Math.max(totalSpent, 1) > 0.15 ? "high" : "medium",
    });
  }

  // impulse: non-recurring wants >= ₹500
  const impulse = window.filter((t) => t.need_or_want === "want" && !t.recurring && t.amount >= 500 && !claimed.has(t.id));
  const impulseAmt = sum(impulse.map((t) => t.amount));
  if (impulse.length >= 2) {
    const monthlySaving = round2(impulseAmt * 0.5);
    out.push({
      id: "impulse",
      title: "Possible impulse purchases",
      detail: `${impulse.length} one-off "want" purchases of ₹500+ totalled ${fmt(impulseAmt)} in the last 30 days.`,
      amount: impulseAmt,
      count: impulse.length,
      cutPct: 50,
      monthlySaving,
      yearlySaving: round2(monthlySaving * 12),
      alternatives: ["Add items to a wishlist and revisit after a week", "Link big wants to a goal so you save up for them first"],
      severity: "medium",
    });
  }

  // unplanned/miscellaneous spending
  const unplanned = window.filter((t) => (t.subcategory === "Miscellaneous" || t.category === "Other") && !["Medical", "Emergency", "EMI"].includes(t.subcategory ?? ""));
  const unplannedAmt = sum(unplanned.map((t) => t.amount));
  if (unplanned.length >= 3 && unplannedAmt >= 500) {
    out.push({
      id: "unplanned",
      title: "Unplanned / miscellaneous spending",
      detail: `${fmt(unplannedAmt)} across ${unplanned.length} miscellaneous expenses in the last 30 days. Categorising them helps spot what they really are.`,
      amount: unplannedAmt,
      count: unplanned.length,
      cutPct: 20,
      monthlySaving: round2(unplannedAmt * 0.2),
      yearlySaving: round2(unplannedAmt * 0.2 * 12),
      alternatives: ["Use specific categories when logging", "Keep a small buffer budget for genuine surprises"],
      severity: "low",
    });
  }

  // subscriptions: overlap in a category or high share of income
  const active = subscriptions.filter((s) => s.status === "active");
  const subsMonthly = sum(active.map(subscriptionMonthlyCost));
  const byCat = new Map<string, Subscription[]>();
  for (const s of active) byCat.set(s.category, [...(byCat.get(s.category) ?? []), s]);
  const overlaps = [...byCat.values()].filter((l) => l.length >= 2);
  if (overlaps.length || (monthlyIncome > 0 && subsMonthly / monthlyIncome > 0.05)) {
    const cheapest = overlaps.flatMap((l) => [...l].sort((a, b) => subscriptionMonthlyCost(a) - subscriptionMonthlyCost(b)).slice(0, l.length - 1));
    const saving = round2(sum(cheapest.map(subscriptionMonthlyCost)));
    out.push({
      id: "subscriptions",
      title: "Subscriptions to review",
      detail: `You pay ${fmt(subsMonthly)}/month (${fmt(subsMonthly * 12)}/year) for ${active.length} subscription${active.length === 1 ? "" : "s"}.${overlaps.length ? ` Overlapping services: ${overlaps.map((l) => l.map((s) => s.name).join(" + ")).join("; ")}.` : ""}`,
      amount: subsMonthly,
      count: active.length,
      cutPct: subsMonthly ? Math.round((saving / subsMonthly) * 100) : 0,
      monthlySaving: saving,
      yearlySaving: round2(saving * 12),
      alternatives: ["Cancel services you didn't use in the last 2 weeks", "Use student plans (Spotify/YouTube/Apple offer them)", "Share family plans with friends or siblings", "Rotate streaming services month by month"],
      severity: overlaps.length ? "medium" : "low",
    });
  }

  return out.sort((a, b) => b.monthlySaving - a.monthlySaving);
}

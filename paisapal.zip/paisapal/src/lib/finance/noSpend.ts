import type { NoSpendRule, Transaction } from "../types";
import { isExpense } from "./aggregate";
import { addDays, diffDays, ymdMin } from "./dates";
import { round2, sum } from "./money";

export function ruleMatches(rule: Pick<NoSpendRule, "category" | "subcategory">, t: Pick<Transaction, "category" | "subcategory">): boolean {
  return rule.category === t.category && (!rule.subcategory || rule.subcategory === t.subcategory);
}

export interface RuleProgress {
  rule: NoSpendRule;
  state: "upcoming" | "active" | "ended";
  daysTotal: number;
  daysElapsed: number;
  spent: number;
  matches: number;
  overLimit: boolean;
  /** typical monthly spend in this category before the rule started */
  baselineMonthly: number;
  baselineSource: "entered" | "history" | "none";
  estimatedSaved: number;
}

export function ruleProgress(rule: NoSpendRule, txs: Transaction[], today: string): RuleProgress {
  const state = today < rule.start_date ? "upcoming" : today > rule.end_date ? "ended" : "active";
  const daysTotal = diffDays(rule.end_date, rule.start_date) + 1;
  const daysElapsed = state === "upcoming" ? 0 : diffDays(ymdMin(today, rule.end_date), rule.start_date) + 1;
  const during = txs.filter((t) => isExpense(t) && ruleMatches(rule, t) && t.date >= rule.start_date && t.date <= ymdMin(today, rule.end_date));
  const spent = sum(during.map((t) => t.amount));

  let baselineMonthly = 0;
  let baselineSource: RuleProgress["baselineSource"] = "none";
  if (rule.baseline_monthly !== null && rule.baseline_monthly !== undefined) {
    baselineMonthly = rule.baseline_monthly;
    baselineSource = "entered";
  } else {
    const before = txs.filter((t) => isExpense(t) && ruleMatches(rule, t) && t.date >= addDays(rule.start_date, -60) && t.date < rule.start_date);
    if (before.length) {
      baselineMonthly = round2((sum(before.map((t) => t.amount)) / 60) * 30.4375);
      baselineSource = "history";
    }
  }
  const estimatedSaved = round2(Math.max(0, (baselineMonthly / 30.4375) * daysElapsed - spent));
  return { rule, state, daysTotal, daysElapsed, spent, matches: during.length, overLimit: spent > rule.limit_amount, baselineMonthly, baselineSource, estimatedSaved };
}

/** Active rules an about-to-be-saved expense would break. */
export function violatedRules(rules: NoSpendRule[], draft: { category: string; subcategory?: string | null; date: string }): NoSpendRule[] {
  return rules.filter((r) => r.active && draft.date >= r.start_date && draft.date <= r.end_date && ruleMatches(r, { category: draft.category, subcategory: draft.subcategory ?? null }));
}

/** Round to paise precision without floating point drift. */
export function round2(n: number): number {
  return Math.round((n + Number.EPSILON) * 100) / 100;
}

export function sum(values: number[]): number {
  // integer paise avoids accumulating float error over thousands of rows
  let paise = 0;
  for (const v of values) paise += Math.round(v * 100);
  return paise / 100;
}

/** Percentage of part/whole, or null when the whole is zero (undefined ratio). */
export function pct(part: number, whole: number): number | null {
  if (!whole) return null;
  return round2((part / whole) * 100);
}

const inrFormatter = new Intl.NumberFormat("en-IN", { maximumFractionDigits: 0 });
const inrFormatter2 = new Intl.NumberFormat("en-IN", { minimumFractionDigits: 0, maximumFractionDigits: 2 });

export function formatINR(n: number | null | undefined, opts: { decimals?: boolean; sign?: boolean } = {}): string {
  if (n === null || n === undefined || Number.isNaN(n)) return "—";
  const abs = Math.abs(n);
  const body = (opts.decimals ? inrFormatter2 : inrFormatter).format(opts.decimals ? abs : Math.round(abs));
  const sign = n < 0 ? "-" : opts.sign && n > 0 ? "+" : "";
  return `${sign}₹${body}`;
}

export function formatPct(n: number | null | undefined, decimals = 1): string {
  if (n === null || n === undefined || Number.isNaN(n)) return "—";
  return `${n.toFixed(decimals)}%`;
}

import type { Goal, Transaction } from "../types";
import { isExpense, summarize } from "./aggregate";
import { addDays, addMonths, diffDays, monthEnd, monthStart } from "./dates";
import { pct } from "./money";

export interface Streaks {
  trackingDays: number; // consecutive days with at least one entry, ending today or yesterday
  noSpendDaysThisMonth: number; // completed days this month with no expense
  currentNoSpendRun: number; // consecutive completed days with no expense
  savingsMonths: number; // consecutive completed months with positive savings
  underLimitDays: number | null; // consecutive completed days under the daily limit
  milestones: { goal: string; pct: number }[];
}

export function streaks(txs: Transaction[], goals: Goal[], today: string, dailyLimit: number | null, firstDate: string | null): Streaks {
  const days = new Set(txs.map((t) => t.date));
  const spentByDay = new Map<string, number>();
  for (const t of txs) if (isExpense(t)) spentByDay.set(t.date, (spentByDay.get(t.date) ?? 0) + t.amount);

  let trackingDays = 0;
  let cur = days.has(today) ? today : addDays(today, -1);
  while (days.has(cur)) {
    trackingDays++;
    cur = addDays(cur, -1);
  }

  const start = firstDate && firstDate > monthStart(today) ? firstDate : monthStart(today);
  let noSpendDaysThisMonth = 0;
  for (let x = start; x < today; x = addDays(x, 1)) if (!spentByDay.has(x)) noSpendDaysThisMonth++;

  let currentNoSpendRun = 0;
  for (let x = addDays(today, -1); firstDate && x >= firstDate && !spentByDay.has(x); x = addDays(x, -1)) currentNoSpendRun++;

  let savingsMonths = 0;
  for (let i = 1; i <= 24; i++) {
    const m = addMonths(monthStart(today), -i);
    if (!firstDate || monthEnd(m) < firstDate) break;
    if (summarize(txs, m, monthEnd(m)).saved > 0) savingsMonths++;
    else break;
  }

  let underLimitDays: number | null = null;
  if (dailyLimit && firstDate) {
    underLimitDays = 0;
    for (let x = addDays(today, -1); x >= firstDate && (spentByDay.get(x) ?? 0) <= dailyLimit; x = addDays(x, -1)) {
      underLimitDays++;
      if (diffDays(today, x) > 365) break;
    }
  }

  const milestones = goals
    .filter((g) => g.status !== "paused")
    .map((g) => ({ goal: g.name, pct: Math.min(100, Math.floor(pct(g.current_amount, g.target_amount) ?? 0)) }))
    .filter((m) => m.pct >= 25)
    .sort((a, b) => b.pct - a.pct);

  return { trackingDays, noSpendDaysThisMonth, currentNoSpendRun, savingsMonths, underLimitDays, milestones };
}

import type { Snapshot } from "../types";
import { upcomingPayments } from "./schedule";

export interface CalendarEvent {
  id: string;
  date: string;
  type: "income" | "expense" | "bill" | "subscription" | "goal_deadline" | "saving";
  title: string;
  amount: number | null;
  refId?: string;
}

export function calendarEvents(s: Snapshot, from: string, to: string, today: string): CalendarEvent[] {
  const out: CalendarEvent[] = [];
  for (const t of s.transactions) {
    if (t.date < from || t.date > to) continue;
    out.push({ id: `t-${t.id}`, date: t.date, type: t.type, title: t.type === "income" ? t.category : `${t.category}${t.subcategory ? ` → ${t.subcategory}` : ""}${t.description ? ` · ${t.description}` : ""}`, amount: t.amount, refId: t.id });
  }
  const start = from > today ? from : today;
  if (start <= to) {
    for (const p of upcomingPayments(s, start, to)) {
      out.push({ id: p.key, date: p.date, type: p.source === "subscription" ? "subscription" : "bill", title: p.title, amount: p.amount, refId: p.refId });
    }
  }
  // reminders already paid/overdue in the past range
  for (const r of s.reminders) {
    if (r.due_date >= from && r.due_date < start && r.due_date <= to) out.push({ id: `r-${r.id}`, date: r.due_date, type: "bill", title: `${r.title}${r.completed ? " (paid)" : ""}`, amount: r.amount, refId: r.id });
  }
  for (const g of s.goals) {
    if (g.target_date && g.target_date >= from && g.target_date <= to) out.push({ id: `g-${g.id}`, date: g.target_date, type: "goal_deadline", title: `Goal deadline: ${g.name}`, amount: g.target_amount, refId: g.id });
  }
  const goalName = new Map(s.goals.map((g) => [g.id, g.name]));
  for (const c of s.contributions) {
    if (c.date >= from && c.date <= to) out.push({ id: `c-${c.id}`, date: c.date, type: "saving", title: `${c.amount > 0 ? "Saved to" : "Withdrew from"} ${goalName.get(c.goal_id) ?? "goal"}`, amount: c.amount, refId: c.goal_id });
  }
  return out.sort((a, b) => a.date.localeCompare(b.date));
}

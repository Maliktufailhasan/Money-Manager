import type { Snapshot } from "../types";
import { summarize } from "./aggregate";
import { budgetReport } from "./budget";
import { addMonths, fmtMonthShort, monthEnd, monthKey, monthStart, ym } from "./dates";
import { pct, round2, sum } from "./money";
import { recurringMonthlyBurden } from "./schedule";

export interface HealthMonth {
  key: string;
  label: string;
  savingsRate: number | null;
  expenseToIncome: number | null;
  budgetAdherence: number | null;
  essentialShare: number | null; // needs as % of classified spending
  recurringBurden: number | null; // recurring spend as % of income
}

export interface HealthIndicator {
  key: string;
  label: string;
  value: number | null;
  unit: "%" | "₹";
  good: "high" | "low";
  target: string;
  status: "good" | "ok" | "poor" | "unknown";
  explain: string;
}

function grade(v: number | null, good: "high" | "low", okAt: number, goodAt: number): HealthIndicator["status"] {
  if (v === null) return "unknown";
  if (good === "high") return v >= goodAt ? "good" : v >= okAt ? "ok" : "poor";
  return v <= goodAt ? "good" : v <= okAt ? "ok" : "poor";
}

export function healthTrend(s: Snapshot, today: string, months = 6): HealthMonth[] {
  const out: HealthMonth[] = [];
  for (let i = months - 1; i >= 0; i--) {
    const m = addMonths(monthStart(today), -i);
    if (s.totals.first_date && monthEnd(m) < s.totals.first_date) continue;
    const sum_ = summarize(s.transactions, m, monthEnd(m));
    const { year, month } = ym(m);
    const br = budgetReport(s.budgets, s.transactions, year, month, today);
    const classified = sum_.needs + sum_.wants;
    out.push({
      key: monthKey(m),
      label: fmtMonthShort(monthKey(m)),
      savingsRate: sum_.savingsRate,
      expenseToIncome: pct(sum_.spent, sum_.received),
      budgetAdherence: br.adherence,
      essentialShare: pct(sum_.needs, classified),
      recurringBurden: pct(sum_.recurringSpent, sum_.received),
    });
  }
  return out;
}

export function healthIndicators(s: Snapshot, today: string): HealthIndicator[] {
  const trend = healthTrend(s, today, 6);
  const last3 = trend.slice(-3);
  const avg = (f: (m: HealthMonth) => number | null) => {
    const vals = last3.map(f).filter((v): v is number => v !== null);
    return vals.length ? round2(vals.reduce((a, b) => a + b, 0) / vals.length) : null;
  };

  // income stability: 100 - coefficient of variation of monthly income
  const incomes = trend.map((m) => summarize(s.transactions, `${m.key}-01`, monthEnd(`${m.key}-01`)).received).filter((v) => v > 0);
  let stability: number | null = null;
  if (incomes.length >= 2) {
    const mean = incomes.reduce((a, b) => a + b, 0) / incomes.length;
    const sd = Math.sqrt(incomes.reduce((a, b) => a + (b - mean) ** 2, 0) / incomes.length);
    stability = round2(Math.max(0, 100 - (sd / mean) * 100));
  }

  const emergency = s.goals.find((g) => g.is_emergency);
  const active = s.goals.filter((g) => g.status !== "paused" && !g.is_emergency);
  const goalProgress = active.length ? pct(sum(active.map((g) => Math.min(g.current_amount, g.target_amount))), sum(active.map((g) => g.target_amount))) : null;
  const monthIncome = summarize(s.transactions, monthStart(today), monthEnd(today)).received || Number(s.profile.monthly_income_estimate) || 0;
  const recurring = monthIncome ? pct(recurringMonthlyBurden(s), monthIncome) : null;

  const ind = (key: string, label: string, value: number | null, good: "high" | "low", okAt: number, goodAt: number, target: string, explain: string): HealthIndicator => ({
    key, label, value, unit: "%", good, target, status: grade(value, good, okAt, goodAt), explain,
  });

  return [
    ind("savingsRate", "Savings rate", avg((m) => m.savingsRate), "high", 10, 20, "20%+", "Share of money received that you kept (last 3 months)."),
    ind("expenseToIncome", "Expense-to-income", avg((m) => m.expenseToIncome), "low", 90, 80, "under 80%", "Spending as a share of money received."),
    ind("budgetAdherence", "Budget adherence", avg((m) => m.budgetAdherence), "high", 60, 85, "85%+", "Share of budget categories kept within their limit."),
    ind("essentialShare", "Needs share of spending", avg((m) => m.essentialShare), "high", 50, 65, "65%+", "Needs vs wants among classified expenses."),
    ind("goalProgress", "Goal progress", goalProgress, "high", 25, 50, "steady growth", "Saved so far across active goals."),
    ind("recurringBurden", "Recurring expense burden", recurring, "low", 50, 35, "under 35%", "Subscriptions + recurring bills as a share of monthly income."),
    ind("emergency", "Emergency fund", emergency ? Math.min(100, pct(emergency.current_amount, emergency.target_amount) ?? 0) : null, "high", 30, 100, "100%", emergency ? `${emergency.name}: progress towards target.` : "No emergency fund goal yet."),
    ind("stability", "Income stability", stability, "high", 60, 85, "85%+", "How consistent your monthly income is (100 = identical every month)."),
  ];
}

import { EXPENSE_CATEGORIES } from "../constants";
import type { Snapshot } from "../types";
import { currentBalance, isExpense, summarize } from "./aggregate";
import { safeToSpend } from "./budget";
import { addMonths, monthEnd, monthStart, weekStart } from "./dates";
import { affordability, planFromZero } from "./goals";
import { formatINR as f, sum } from "./money";
import { financialPosition } from "./position";
import { detectWaste } from "./waste";

/** Parse "₹40,000", "40k", "1.5 lakh" → number */
export function parseAmount(text: string): number | null {
  const m = text.toLowerCase().replace(/,/g, "").match(/(?:₹|rs\.?|inr)?\s*(\d+(?:\.\d+)?)\s*(k|lakh|lac|l)?\b/);
  if (!m) return null;
  let n = Number(m[1]);
  if (m[2] === "k") n *= 1000;
  if (m[2] && m[2] !== "k") n *= 100000;
  return n;
}

function parseMonths(text: string): number | null {
  const m = text.toLowerCase().match(/(\d+(?:\.\d+)?)\s*(month|months|mo|year|years|yr|week|weeks)/);
  if (!m) return null;
  const n = Number(m[1]);
  if (m[2].startsWith("y")) return n * 12;
  if (m[2].startsWith("w")) return n / 4.345;
  return n;
}

/**
 * Rule-based answers used when no AI key is configured. Covers the common
 * questions with exact numbers from the student's data.
 */
export function offlineAnswer(question: string, s: Snapshot, today: string): string {
  const q = question.toLowerCase();
  const pos = financialPosition(s, today);
  const month = summarize(s.transactions, monthStart(today), today);
  const lm = addMonths(monthStart(today), -1);
  const last = summarize(s.transactions, lm, monthEnd(lm));
  const amount = parseAmount(q);
  const months = parseMonths(q);
  const footer = pos.dataQuality !== "good" ? `\n\n_Note: ${pos.basis}_` : "";

  if (s.totals.tx_count === 0) return "You haven't recorded any transactions yet, so I can't answer from your data. Add some income and expenses first, then ask again.";

  // spend on a specific category/subcategory/merchant
  const subMatch = Object.entries(EXPENSE_CATEGORIES).flatMap(([c, subs]) => subs.map((sub) => ({ c, sub }))).find(({ sub }) => q.includes(sub.toLowerCase()) && sub !== "Other");
  const catMatch = Object.keys(EXPENSE_CATEGORIES).find((c) => q.includes(c.toLowerCase()));
  if (/how much.*(spend|spent)|spent on|spending on/.test(q) && (subMatch || catMatch || /swiggy|zomato|uber|ola|amazon|flipkart/.test(q))) {
    const merchant = q.match(/swiggy|zomato|uber|ola|amazon|flipkart/)?.[0];
    const rows = s.transactions.filter((t) => isExpense(t) && t.date >= monthStart(today) && t.date <= today && (merchant ? (t.merchant ?? "").toLowerCase().includes(merchant) : subMatch ? t.subcategory === subMatch.sub : t.category === catMatch));
    const label = merchant ?? (subMatch ? `${subMatch.c} → ${subMatch.sub}` : catMatch);
    return `**Recorded:** you spent **${f(sum(rows.map((t) => t.amount)))}** on ${label} this month across ${rows.length} transaction${rows.length === 1 ? "" : "s"}.${footer}`;
  }

  if (/most|biggest|highest|where did i spend/.test(q) && /spend|spent|expense|category/.test(q) && !/unnecessary/.test(q)) {
    const tops = month.byCategory.slice(0, 3).map((c, i) => `${i + 1}. ${c.name}: ${f(c.amount)} (${Math.round(c.share ?? 0)}%)`).join("\n");
    return tops ? `**Recorded — top spending this month:**\n${tops}` : "No expenses recorded this month yet.";
  }

  if (/unnecessary|waste|reduce|cut|save more|unable to save|can't save|cannot save|why.*sav/.test(q)) {
    const w = detectWaste(s.transactions, s.subscriptions, today, pos.avgMonthlyIncome);
    const wants = month.wants;
    const biggestWant = s.transactions.filter((t) => isExpense(t) && t.need_or_want === "want" && t.date >= monthStart(today)).sort((a, b) => b.amount - a.amount)[0];
    const lines = w.slice(0, 4).map((x) => `- **${x.title}:** ${f(x.amount)} in 30 days → cut ${x.cutPct}% to save ~${f(x.monthlySaving)}/month. _Try: ${x.alternatives[0]}._`);
    return [
      `**Calculated:** your average monthly saving capacity is ${f(pos.savingCapacity)} (income ${f(pos.avgMonthlyIncome)} − expenses ${f(pos.avgMonthlyExpense)}).`,
      wants > 0 ? `This month ${f(wants)} went on wants.` : "",
      biggestWant ? `Biggest "want" this month: ${f(biggestWant.amount)} on ${biggestWant.subcategory ?? biggestWant.category}${biggestWant.merchant ? ` at ${biggestWant.merchant}` : ""} (${biggestWant.date}).` : "",
      lines.length ? `\n**Suggestions:**\n${lines.join("\n")}` : "No clear wasteful patterns found in the last 30 days — nice.",
    ].filter(Boolean).join("\n") + footer;
  }

  if (/compare|last month|vs/.test(q)) {
    const diff = month.spent - last.spent;
    return `**Recorded:**\n| | This month (so far) | Last month |\n|---|---|---|\n| Received | ${f(month.received)} | ${f(last.received)} |\n| Spent | ${f(month.spent)} | ${f(last.spent)} |\n| Saved | ${f(month.saved)} | ${f(last.saved)} |\n\nYou've spent ${f(Math.abs(diff))} ${diff >= 0 ? "more" : "less"} so far than all of last month.`;
  }

  if (/per day|daily|weekend|this week|can i spend|safe to spend/.test(q)) {
    const sts = safeToSpend(s, today, currentBalance(s));
    const weekendDays = /weekend/.test(q) ? Math.min(2, sts.daysLeft) : null;
    return `**Calculated:** you can safely spend about **${f(sts.daily)}/day** for the remaining ${sts.daysLeft} days of this month${weekendDays ? ` — about **${f(sts.daily * weekendDays)}** for the weekend` : ""}.\n\n- Balance: ${f(sts.balance)}\n- Bills & subscriptions still due this month: ${f(sts.upcomingThisMonth)}\n- Savings target still to set aside: ${f(sts.savingsStillToSet)}${sts.limitedBy === "budget" ? "\n- Limited by your remaining monthly budget." : ""}`;
  }

  if (/sav(e|ed).*(this month|month)|how much.*sav/.test(q) && !amount) {
    return `**Recorded:** this month you received ${f(month.received)} and spent ${f(month.spent)}, so you saved **${f(month.saved)}**${month.savingsRate !== null ? ` (${Math.round(month.savingsRate)}% savings rate)` : ""}.`;
  }

  if (amount && (/afford|buy|plan|reach|goal|how long|₹0|zero|save/.test(q))) {
    const potential = sum(s.earningSources.filter((e) => e.status !== "stopped").map((e) => e.expected_income));
    if (months) {
      const p = planFromZero({ item: "your goal", price: amount, months: Math.max(1, Math.round(months)), startingAmount: 0, incomePotential: potential }, pos);
      return `**Plan to reach ${f(amount)} in ${p.months} months (starting from ₹0):**\n${p.steps.map((st) => `- **${st.label}:** ${st.value}${st.note ? ` _(${st.note})_` : ""}`).join("\n")}\n\n| Source | Total |\n|---|---|\n| Savings | ${f(p.totals.savings)} |\n| Expense reduction | ${f(p.totals.reduction)} |\n| Extra income (not guaranteed) | ${f(p.totals.income)} |\n| **Total** | **${f(p.totals.total)}** |`;
    }
    const a = affordability({ price: amount, currentMoney: 0, monthlyIncome: pos.avgMonthlyIncome, monthlyExpenses: pos.avgMonthlyExpense, targetMonths: null, reduction: Math.round(pos.reducibleMonthly * 0.3), extraIncome: potential }, today);
    return `**Estimate for ${f(amount)}:** ${a.verdictText}\n\n${a.scenarios.map((sc) => `- **${sc.name}:** save ${f(sc.monthlySaving)}/month → ${sc.months === null ? "never at this rate" : `${sc.months} months`}${sc.speculative ? " _(relies on extra income)_" : ""}`).join("\n")}${footer}`;
  }

  if (/balance|how much (money )?do i have/.test(q)) return `**Recorded:** your current balance is **${f(currentBalance(s))}**.`;
  if (/week/.test(q)) {
    const w = summarize(s.transactions, weekStart(today), today);
    return `**Recorded this week:** received ${f(w.received)}, spent ${f(w.spent)}, saved ${f(w.saved)}.`;
  }

  return `I'm running in offline mode (no AI key configured), so I can answer common questions like:\n- "Where did I spend the most this month?"\n- "How much did I spend on food delivery?"\n- "How much can I spend per day?"\n- "Compare my spending with last month"\n- "Can I afford a ₹20,000 phone?"\n- "I have ₹0. How can I reach ₹30,000 in 6 months?"\n\nThis month so far: received ${f(month.received)}, spent ${f(month.spent)}, saved ${f(month.saved)}.`;
}

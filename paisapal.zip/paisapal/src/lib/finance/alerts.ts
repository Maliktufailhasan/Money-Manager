import type { AlertKind, Snapshot } from "../types";
import { isExpense, summarize, txInRange } from "./aggregate";
import { budgetReport } from "./budget";
import { addDays, diffDays, monthStart, ym } from "./dates";
import { goalMetrics } from "./goals";
import { sum } from "./money";
import { ruleProgress } from "./noSpend";
import { upcomingPayments } from "./schedule";

export interface Alert {
  id: string;
  kind: AlertKind;
  level: "danger" | "warning" | "info";
  text: string;
  href?: string;
}

const fmt = (n: number) => `₹${Math.round(n).toLocaleString("en-IN")}`;

export function computeAlerts(s: Snapshot, today: string, balance: number, dailyTarget: number | null): Alert[] {
  const prefs = s.profile.preferences?.alerts ?? {};
  const on = (k: AlertKind) => prefs[k] !== false;
  const out: Alert[] = [];
  const todaySpent = sum(s.transactions.filter((t) => isExpense(t) && t.date === today).map((t) => t.amount));

  if (on("daily_limit") && dailyTarget && todaySpent > dailyTarget) {
    out.push({ id: "daily", kind: "daily_limit", level: "warning", text: `You've spent ${fmt(todaySpent)} today — ${fmt(todaySpent - dailyTarget)} over today's target of ${fmt(dailyTarget)}.`, href: "/daily" });
  }

  if (on("budget")) {
    const { year, month } = ym(today);
    for (const r of budgetReport(s.budgets, s.transactions, year, month, today).rows) {
      if (r.state === "over") out.push({ id: `b-${r.category}`, kind: "budget", level: "danger", text: `${r.category} is over budget: ${fmt(r.spent)} of ${fmt(r.budget)} (${Math.round(r.usedPct ?? 0)}%).`, href: "/budget" });
      else if (r.state === "near") out.push({ id: `b-${r.category}`, kind: "budget", level: "warning", text: `You have used ${Math.round(r.usedPct ?? 0)}% of your ${r.category.toLowerCase()} budget this month (${fmt(r.spent)} of ${fmt(r.budget)}).`, href: "/budget" });
    }
  }

  if (on("unusual")) {
    const prior = txInRange(s.transactions, addDays(today, -30), addDays(today, -1)).filter(isExpense);
    const avgDaily = sum(prior.map((t) => t.amount)) / 30;
    if (prior.length >= 10 && todaySpent > Math.max(300, avgDaily * 2.5)) {
      out.push({ id: "unusual", kind: "unusual", level: "warning", text: `Unusual spending: ${fmt(todaySpent)} today vs your usual ${fmt(avgDaily)}/day.`, href: "/daily" });
    }
  }

  const upcoming = upcomingPayments(s, today, addDays(today, 7));
  if (on("upcoming_payment")) {
    for (const p of upcoming.filter((p) => p.source === "reminder" && p.daysAway <= 3)) {
      out.push({
        id: `u-${p.key}`,
        kind: "upcoming_payment",
        level: p.daysAway < 0 ? "danger" : "info",
        text: p.daysAway < 0 ? `${p.title} (${fmt(p.amount)}) was due ${-p.daysAway} day${p.daysAway === -1 ? "" : "s"} ago.` : `${p.title} (${fmt(p.amount)}) is due ${p.daysAway === 0 ? "today" : p.daysAway === 1 ? "tomorrow" : `in ${p.daysAway} days`}.`,
        href: "/bills",
      });
    }
  }
  if (on("subscription_renewal")) {
    for (const p of upcoming.filter((p) => p.source === "subscription")) {
      const sub = s.subscriptions.find((x) => x.id === p.refId);
      if (sub && p.daysAway <= sub.remind_days_before) out.push({ id: `s-${p.key}`, kind: "subscription_renewal", level: "info", text: `${p.title} renews ${p.daysAway === 0 ? "today" : p.daysAway === 1 ? "tomorrow" : `in ${p.daysAway} days`} (${fmt(p.amount)}).`, href: "/subscriptions" });
    }
  }

  if (on("low_balance")) {
    const threshold = s.profile.preferences?.low_balance_threshold ?? 1000;
    if (s.totals.tx_count > 0 && balance < threshold) out.push({ id: "low", kind: "low_balance", level: balance < 0 ? "danger" : "warning", text: balance < 0 ? `Your balance is negative (${fmt(balance)}). Check for missing income entries.` : `Low balance: ${fmt(balance)} left.`, href: "/" });
  }

  if (on("no_savings")) {
    const dayN = diffDays(today, monthStart(today)) + 1;
    const m = summarize(s.transactions, monthStart(today), today);
    if (dayN >= 20 && m.received > 0 && m.saved <= 0) out.push({ id: "nosave", kind: "no_savings", level: "warning", text: "You haven't saved anything this month yet — spending has matched or exceeded income.", href: "/savings" });
  }

  if (on("large_transaction")) {
    const big = s.profile.preferences?.large_txn_threshold ?? 2000;
    for (const t of s.transactions.filter((t) => isExpense(t) && t.amount >= big && t.date >= addDays(today, -2) && t.date <= today)) {
      out.push({ id: `l-${t.id}`, kind: "large_transaction", level: "info", text: `Large expense recorded: ${fmt(t.amount)} on ${t.subcategory ?? t.category}${t.merchant ? ` at ${t.merchant}` : ""}.`, href: "/transactions" });
    }
  }

  if (on("goal_behind")) {
    for (const g of s.goals.filter((g) => g.status === "active" && g.target_date)) {
      const m = goalMetrics(g, s.contributions, today);
      if (m.status === "behind" && m.recentPace > 0) out.push({ id: `g-${g.id}`, kind: "goal_behind", level: "warning", text: `${g.name} is falling behind: you need ${fmt(m.requiredMonthly ?? 0)}/month but have been adding ${fmt(m.recentPace)}/month.`, href: "/goals" });
      if (m.status === "overdue") out.push({ id: `g-${g.id}`, kind: "goal_behind", level: "warning", text: `${g.name} passed its target date with ${fmt(m.remaining)} still to go. Update the date or amount.`, href: "/goals" });
    }
  }

  if (on("no_spend")) {
    for (const r of s.noSpendRules.filter((r) => r.active)) {
      const p = ruleProgress(r, s.transactions, today);
      if (p.state === "active" && p.overLimit) out.push({ id: `n-${r.id}`, kind: "no_spend", level: "warning", text: `"${r.title}": ${fmt(p.spent)} spent on ${r.subcategory ?? r.category} since ${r.start_date} (limit ${fmt(r.limit_amount)}).`, href: "/dont-spend" });
    }
  }

  const order = { danger: 0, warning: 1, info: 2 };
  return out.sort((a, b) => order[a.level] - order[b.level]);
}

import { REFUND_CATEGORY } from "../constants";
import type { Snapshot, Transaction } from "../types";
import { addDays, eachDay, fmtDate, fmtMonthShort, inRange, monthKey, weekStart, addMonths, monthStart, monthEnd } from "./dates";
import { pct, round2, sum } from "./money";

export const isRefund = (t: Transaction) => t.type === "income" && t.category === REFUND_CATEGORY;
export const isExpense = (t: Transaction) => t.type === "expense";
export const isReceived = (t: Transaction) => t.type === "income" && !isRefund(t);

export function txInRange(txs: Transaction[], from: string, to: string): Transaction[] {
  return txs.filter((t) => inRange(t.date, from, to));
}

/**
 * Current balance = opening balance + all income (incl. refunds) - all expenses.
 * Uses database-side lifetime totals so it stays exact even if the snapshot
 * only carries recent rows.
 */
export function currentBalance(s: Pick<Snapshot, "profile" | "totals">): number {
  return round2(Number(s.profile.opening_balance || 0) + s.totals.total_income - s.totals.total_expense);
}

export interface Breakdown {
  name: string;
  amount: number;
  count: number;
  share: number | null; // % of total
}

function breakdown(items: { key: string; amount: number }[]): Breakdown[] {
  const map = new Map<string, { amount: number; count: number }>();
  for (const it of items) {
    const cur = map.get(it.key) ?? { amount: 0, count: 0 };
    cur.amount += Math.round(it.amount * 100);
    cur.count += 1;
    map.set(it.key, cur);
  }
  const total = [...map.values()].reduce((a, b) => a + b.amount, 0);
  return [...map.entries()]
    .map(([name, v]) => ({ name, amount: v.amount / 100, count: v.count, share: total ? round2((v.amount / total) * 100) : null }))
    .sort((a, b) => b.amount - a.amount);
}

export interface PeriodSummary {
  from: string;
  to: string;
  /** money received, excluding refunds */
  received: number;
  refunds: number;
  /** gross expenses recorded */
  grossSpent: number;
  /** spending net of refunds */
  spent: number;
  /** received - spent (equivalently income - expenses) */
  saved: number;
  savingsRate: number | null;
  expenseCount: number;
  incomeCount: number;
  byCategory: Breakdown[];
  bySubcategory: Breakdown[]; // "Food → Snacks"
  byPaymentMethod: Breakdown[];
  bySource: Breakdown[];
  byMerchant: Breakdown[];
  needs: number;
  wants: number;
  unclassified: number;
  essential: number;
  nonEssential: number;
  recurringSpent: number;
  largestExpenses: Transaction[];
}

export function summarize(txs: Transaction[], from: string, to: string): PeriodSummary {
  const inPeriod = txInRange(txs, from, to);
  const expenses = inPeriod.filter(isExpense);
  const received = inPeriod.filter(isReceived);
  const refunds = sum(inPeriod.filter(isRefund).map((t) => t.amount));
  const grossSpent = sum(expenses.map((t) => t.amount));
  const recv = sum(received.map((t) => t.amount));
  const spent = round2(grossSpent - refunds);
  const saved = round2(recv - spent);
  return {
    from,
    to,
    received: recv,
    refunds,
    grossSpent,
    spent,
    saved,
    savingsRate: pct(saved, recv),
    expenseCount: expenses.length,
    incomeCount: received.length,
    byCategory: breakdown(expenses.map((t) => ({ key: t.category, amount: t.amount }))),
    bySubcategory: breakdown(expenses.map((t) => ({ key: `${t.category} → ${t.subcategory || "Other"}`, amount: t.amount }))),
    byPaymentMethod: breakdown(expenses.map((t) => ({ key: t.payment_method || "Unspecified", amount: t.amount }))),
    bySource: breakdown(received.map((t) => ({ key: t.category, amount: t.amount }))),
    byMerchant: breakdown(expenses.filter((t) => t.merchant).map((t) => ({ key: t.merchant!.trim(), amount: t.amount }))),
    needs: sum(expenses.filter((t) => t.need_or_want === "need").map((t) => t.amount)),
    wants: sum(expenses.filter((t) => t.need_or_want === "want").map((t) => t.amount)),
    unclassified: sum(expenses.filter((t) => !t.need_or_want).map((t) => t.amount)),
    essential: sum(expenses.filter((t) => t.essential === true).map((t) => t.amount)),
    nonEssential: sum(expenses.filter((t) => t.essential === false).map((t) => t.amount)),
    recurringSpent: sum(expenses.filter((t) => t.recurring).map((t) => t.amount)),
    largestExpenses: [...expenses].sort((a, b) => b.amount - a.amount).slice(0, 5),
  };
}

export function monthRange(isoDate: string): [string, string] {
  return [monthStart(isoDate), monthEnd(isoDate)];
}

export function spentOn(txs: Transaction[], from: string, to: string, filter?: (t: Transaction) => boolean): number {
  const list = txInRange(txs, from, to);
  const exp = sum(list.filter((t) => isExpense(t) && (!filter || filter(t))).map((t) => t.amount));
  // refunds tagged with the same subcategory/merchant cannot be attributed to a
  // category reliably, so category-filtered totals use gross expenses
  if (filter) return exp;
  return round2(exp - sum(list.filter(isRefund).map((t) => t.amount)));
}

export interface SeriesPoint {
  key: string;
  label: string;
  income: number;
  expense: number;
  net: number;
}

/** Day-by-day series between from and to (inclusive). */
export function dailySeries(txs: Transaction[], from: string, to: string): SeriesPoint[] {
  const byDay = new Map<string, { i: number; e: number }>();
  for (const t of txInRange(txs, from, to)) {
    const cur = byDay.get(t.date) ?? { i: 0, e: 0 };
    if (isReceived(t)) cur.i += Math.round(t.amount * 100);
    else if (isExpense(t)) cur.e += Math.round(t.amount * 100);
    else if (isRefund(t)) cur.e -= Math.round(t.amount * 100);
    byDay.set(t.date, cur);
  }
  return eachDay(from, to).map((day) => {
    const v = byDay.get(day) ?? { i: 0, e: 0 };
    return { key: day, label: fmtDate(day), income: v.i / 100, expense: v.e / 100, net: (v.i - v.e) / 100 };
  });
}

export function weeklySeries(txs: Transaction[], weeks: number, today: string): SeriesPoint[] {
  const out: SeriesPoint[] = [];
  const thisWeek = weekStart(today);
  for (let w = weeks - 1; w >= 0; w--) {
    const from = addDays(thisWeek, -7 * w);
    const to = addDays(from, 6);
    const s = summarize(txs, from, to);
    out.push({ key: from, label: fmtDate(from), income: s.received, expense: s.spent, net: s.saved });
  }
  return out;
}

export function monthlySeries(txs: Transaction[], months: number, today: string): SeriesPoint[] {
  const out: SeriesPoint[] = [];
  for (let m = months - 1; m >= 0; m--) {
    const anchor = addMonths(monthStart(today), -m);
    const s = summarize(txs, anchor, monthEnd(anchor));
    out.push({ key: monthKey(anchor), label: fmtMonthShort(monthKey(anchor)), income: s.received, expense: s.spent, net: s.saved });
  }
  return out;
}

/** Category spending per month, for trend comparisons. */
export function categoryByMonth(txs: Transaction[], months: number, today: string): { key: string; label: string; [cat: string]: number | string }[] {
  const out: { key: string; label: string; [cat: string]: number | string }[] = [];
  for (let m = months - 1; m >= 0; m--) {
    const anchor = addMonths(monthStart(today), -m);
    const s = summarize(txs, anchor, monthEnd(anchor));
    const row: { key: string; label: string; [cat: string]: number | string } = { key: monthKey(anchor), label: fmtMonthShort(monthKey(anchor)) };
    for (const c of s.byCategory) row[c.name] = c.amount;
    out.push(row);
  }
  return out;
}

/** Running balance at the end of each day in the range. */
export function balanceSeries(s: Pick<Snapshot, "profile" | "totals" | "transactions">, from: string, to: string): { key: string; label: string; balance: number }[] {
  const end = currentBalance(s);
  // walk backwards from today's balance, undoing transactions after each day
  const after = new Map<string, number>();
  for (const t of s.transactions) {
    const delta = t.type === "income" ? t.amount : -t.amount;
    after.set(t.date, (after.get(t.date) ?? 0) + Math.round(delta * 100));
  }
  const days = eachDay(from, to);
  const futureDelta = [...after.entries()].filter(([k]) => k > to).reduce((a, [, v]) => a + v, 0);
  let bal = Math.round(end * 100) - futureDelta;
  const out: { key: string; label: string; balance: number }[] = [];
  for (let i = days.length - 1; i >= 0; i--) {
    out.unshift({ key: days[i], label: fmtDate(days[i]), balance: bal / 100 });
    bal -= after.get(days[i]) ?? 0;
  }
  return out;
}

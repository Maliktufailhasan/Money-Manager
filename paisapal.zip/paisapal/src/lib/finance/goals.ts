import type { Goal, GoalContribution } from "../types";
import { addDays, addMonths, diffDays, monthsBetween } from "./dates";
import { pct, round2, sum } from "./money";
import type { FinancialPosition } from "./position";

export type GoalStatus = "completed" | "on_track" | "behind" | "overdue" | "no_deadline" | "paused";

export interface GoalMetrics {
  goal: Goal;
  remaining: number;
  progressPct: number;
  daysLeft: number | null;
  monthsLeft: number | null;
  requiredMonthly: number | null;
  requiredWeekly: number | null;
  requiredDaily: number | null;
  /** average monthly amount added to this goal over the last 90 days */
  recentPace: number;
  /** months to finish at recent pace (or at free saving capacity if no pace yet) */
  etaMonths: number | null;
  etaDate: string | null;
  etaBasis: "goal pace" | "saving capacity" | null;
  status: GoalStatus;
}

export function goalMetrics(goal: Goal, contributions: GoalContribution[], today: string, freeCapacity?: number): GoalMetrics {
  const remaining = round2(Math.max(0, goal.target_amount - goal.current_amount));
  const progressPct = Math.min(100, pct(goal.current_amount, goal.target_amount) ?? 0);
  const daysLeft = goal.target_date ? diffDays(goal.target_date, today) : null;
  const monthsLeft = goal.target_date ? round2(monthsBetween(today, goal.target_date)) : null;

  let requiredMonthly: number | null = null;
  let requiredWeekly: number | null = null;
  let requiredDaily: number | null = null;
  if (daysLeft !== null && daysLeft > 0 && remaining > 0) {
    // never spread over less than one month — "per month" for a 10-day goal is the whole remainder
    requiredMonthly = round2(remaining / Math.max(1, monthsLeft!));
    requiredWeekly = round2(remaining / Math.max(1, daysLeft / 7));
    requiredDaily = round2(remaining / daysLeft);
  }

  const since = addDays(today, -90);
  const recent = sum(contributions.filter((c) => c.goal_id === goal.id && c.date > since && c.date <= today).map((c) => c.amount));
  const firstContribution = contributions.filter((c) => c.goal_id === goal.id).map((c) => c.date).sort()[0];
  const spanDays = firstContribution ? Math.min(90, Math.max(30, diffDays(today, firstContribution))) : 90;
  const recentPace = round2(Math.max(0, (recent / spanDays) * 30.4375));

  let etaMonths: number | null = null;
  let etaBasis: GoalMetrics["etaBasis"] = null;
  if (remaining === 0) etaMonths = 0;
  else if (recentPace > 0) {
    etaMonths = round2(remaining / recentPace);
    etaBasis = "goal pace";
  } else if (freeCapacity && freeCapacity > 0) {
    etaMonths = round2(remaining / freeCapacity);
    etaBasis = "saving capacity";
  }
  const etaDate = etaMonths !== null ? addDays(today, Math.ceil(etaMonths * 30.4375)) : null;

  let status: GoalStatus;
  if (goal.status === "completed" || remaining === 0) status = "completed";
  else if (goal.status === "paused") status = "paused";
  else if (!goal.target_date) status = "no_deadline";
  else if (daysLeft! < 0) status = "overdue";
  else if (etaDate && etaDate <= goal.target_date) status = "on_track";
  else status = "behind";

  return { goal, remaining, progressPct, daysLeft, monthsLeft, requiredMonthly, requiredWeekly, requiredDaily, recentPace, etaMonths, etaDate, etaBasis, status };
}

// ---------------------------------------------------------------------------
// "Can I afford it?" & scenario simulator
// ---------------------------------------------------------------------------

export interface Scenario {
  key: "current" | "reduce" | "income" | "combined";
  name: string;
  description: string;
  monthlySaving: number;
  months: number | null; // null = never at this rate
  date: string | null;
  meetsTarget: boolean | null;
  /** true when this scenario relies on income that isn't earned yet */
  speculative: boolean;
}

export interface AffordInput {
  price: number;
  currentMoney: number;
  monthlyIncome: number;
  monthlyExpenses: number;
  targetMonths: number | null;
  reduction: number; // extra monthly saving from cutting spending
  extraIncome: number; // potential extra monthly income (assumption)
}

export interface AffordResult {
  required: number;
  alreadyAffordable: boolean;
  currentMonthlySaving: number;
  monthlyNeeded: number | null;
  weeklyNeeded: number | null;
  dailyNeeded: number | null;
  scenarios: Scenario[];
  verdict: "affordable_now" | "on_track" | "needs_cuts" | "needs_income" | "needs_both" | "unrealistic" | "no_target";
  verdictText: string;
}

function monthsToReach(required: number, monthly: number): number | null {
  if (required <= 0) return 0;
  if (monthly <= 0) return null;
  return Math.ceil((required / monthly) * 10) / 10;
}

export function affordability(inp: AffordInput, today: string): AffordResult {
  const required = round2(Math.max(0, inp.price - inp.currentMoney));
  const current = round2(inp.monthlyIncome - inp.monthlyExpenses);
  const tm = inp.targetMonths && inp.targetMonths > 0 ? inp.targetMonths : null;
  const monthlyNeeded = tm ? round2(required / tm) : null;
  const days = tm ? Math.round(tm * 30.4375) : null;

  const mk = (key: Scenario["key"], name: string, description: string, monthly: number, speculative: boolean): Scenario => {
    const months = monthsToReach(required, monthly);
    return {
      key,
      name,
      description,
      monthlySaving: round2(monthly),
      months,
      date: months === null ? null : addDays(today, Math.ceil(months * 30.4375)),
      meetsTarget: tm === null ? null : months !== null && months <= tm,
      speculative,
    };
  };
  const scenarios = [
    mk("current", "Current plan", "No lifestyle changes — save what you save today.", Math.max(0, current), false),
    mk("reduce", "Reduced spending", `Cut ₹${Math.round(inp.reduction).toLocaleString("en-IN")}/month of non-essential spending.`, Math.max(0, current + inp.reduction), false),
    mk("income", "Extra income", `Earn an extra ₹${Math.round(inp.extraIncome).toLocaleString("en-IN")}/month (not guaranteed).`, Math.max(0, current + inp.extraIncome), true),
    mk("combined", "Combined", "Cut spending and earn extra income.", Math.max(0, current + inp.reduction + inp.extraIncome), true),
  ];

  let verdict: AffordResult["verdict"];
  let verdictText: string;
  if (required === 0) {
    verdict = "affordable_now";
    verdictText = "You already have enough money for this.";
  } else if (!tm) {
    verdict = "no_target";
    verdictText = scenarios[0].months !== null ? `At your current saving rate you could buy it in about ${scenarios[0].months} months.` : "You aren't saving anything at the moment, so this needs spending cuts or extra income.";
  } else if (scenarios[0].meetsTarget) {
    verdict = "on_track";
    verdictText = "Realistic — your current savings are enough to hit the target date.";
  } else if (scenarios[1].meetsTarget) {
    verdict = "needs_cuts";
    verdictText = "Realistic if you cut some non-essential spending.";
  } else if (scenarios[2].meetsTarget) {
    verdict = "needs_income";
    verdictText = "Only reachable with extra income — which isn't guaranteed.";
  } else if (scenarios[3].meetsTarget) {
    verdict = "needs_both";
    verdictText = "Reachable only by cutting spending AND earning extra.";
  } else {
    verdict = "unrealistic";
    const best = scenarios[3].months;
    verdictText = best !== null ? `Not realistic by the target date. Even the combined plan needs about ${best} months.` : "Not realistic with current numbers — expenses exceed income.";
  }

  return {
    required,
    alreadyAffordable: required === 0,
    currentMonthlySaving: current,
    monthlyNeeded,
    weeklyNeeded: days ? round2(required / Math.max(1, days / 7)) : null,
    dailyNeeded: days ? round2(required / Math.max(1, days)) : null,
    scenarios,
    verdict,
    verdictText,
  };
}

// ---------------------------------------------------------------------------
// "Start from ₹0" planner (AI goal planning algorithm, deterministic part)
// ---------------------------------------------------------------------------

export interface ZeroPlanInput {
  item: string;
  price: number;
  months: number;
  startingAmount: number;
  /** potential extra monthly income the student thinks is possible (from Earn tracker or entered) */
  incomePotential: number;
  /** max share of reducible (want) spending we propose cutting, 0-1 */
  maxCutShare?: number;
}

export interface ZeroPlanStep {
  label: string;
  value: string;
  note?: string;
}

export interface ZeroPlan {
  item: string;
  price: number;
  months: number;
  required: number;
  requiredMonthly: number;
  capacity: number; // free monthly saving after other goals
  gap: number;
  reduction: number; // proposed monthly cut
  extraIncome: number; // monthly income still needed
  savingPart: number; // monthly from existing capacity
  totals: { savings: number; reduction: number; income: number; starting: number; total: number };
  feasibility: "comfortable" | "needs_cuts" | "needs_income" | "stretch";
  etaWithoutIncomeMonths: number | null;
  suggestedMonths: number | null; // realistic duration without extra income
  steps: ZeroPlanStep[];
  assumptions: string[];
  weekly: number;
  daily: number;
}

const r50 = (n: number) => Math.ceil(n / 50) * 50;

export function planFromZero(inp: ZeroPlanInput, pos: FinancialPosition): ZeroPlan {
  const months = Math.max(1, inp.months);
  const required = round2(Math.max(0, inp.price - inp.startingAmount));
  const requiredMonthly = round2(required / months);
  const capacity = round2(Math.max(0, pos.savingCapacity - pos.committedToGoals));
  const savingPart = Math.min(capacity, requiredMonthly);
  const gap = round2(Math.max(0, requiredMonthly - capacity));
  const maxCut = Math.max(0, pos.reducibleMonthly * (inp.maxCutShare ?? 0.3));
  const reduction = gap > 0 ? Math.min(r50(gap), r50(maxCut)) : 0;
  const extraIncome = round2(Math.max(0, gap - reduction) > 0 ? r50(gap - reduction) : 0);

  let feasibility: ZeroPlan["feasibility"];
  if (gap === 0) feasibility = "comfortable";
  else if (extraIncome === 0) feasibility = "needs_cuts";
  else if (extraIncome <= Math.max(inp.incomePotential, 0)) feasibility = "needs_income";
  else feasibility = "stretch";

  const guaranteed = capacity + maxCut;
  const etaWithoutIncomeMonths = required === 0 ? 0 : guaranteed > 0 ? Math.ceil((required / guaranteed) * 10) / 10 : null;

  const totals = {
    starting: round2(inp.startingAmount),
    savings: round2(savingPart * months),
    reduction: round2(reduction * months),
    income: round2(extraIncome * months),
    total: 0,
  };
  totals.total = round2(totals.starting + totals.savings + totals.reduction + totals.income);

  const fmt = (n: number) => `₹${Math.round(n).toLocaleString("en-IN")}`;
  const steps: ZeroPlanStep[] = [
    { label: "Current financial position", value: `Balance ${fmt(pos.balance)} · income ${fmt(pos.avgMonthlyIncome)}/mo · expenses ${fmt(pos.avgMonthlyExpense)}/mo`, note: pos.basis },
    { label: "Required amount", value: fmt(required), note: inp.startingAmount > 0 ? `${fmt(inp.price)} − ${fmt(inp.startingAmount)} already set aside` : undefined },
    { label: "Required monthly savings", value: `${fmt(requiredMonthly)}/month for ${months} months` },
    { label: "Current monthly saving capacity", value: `${fmt(capacity)}/month`, note: pos.committedToGoals > 0 ? `after ${fmt(pos.committedToGoals)}/month already needed by your other goals` : undefined },
    { label: "Savings gap", value: gap > 0 ? `${fmt(gap)}/month` : "None — you can already afford this pace" },
    { label: "Possible expense reduction", value: reduction > 0 ? `${fmt(reduction)}/month` : "Not needed", note: pos.reducibleMonthly > 0 ? `up to ${Math.round((inp.maxCutShare ?? 0.3) * 100)}% of your ~${fmt(pos.reducibleMonthly)}/month non-essential spending` : "No non-essential spending recorded to cut from" },
    { label: "Additional income required", value: extraIncome > 0 ? `${fmt(extraIncome)}/month` : "Not needed", note: extraIncome > 0 ? "potential income — not guaranteed until earned" : undefined },
    { label: "Recommended monthly plan", value: [savingPart > 0 && `save ${fmt(savingPart)}`, reduction > 0 && `cut ${fmt(reduction)}`, extraIncome > 0 && `earn ${fmt(extraIncome)}`].filter(Boolean).join(" + ") || "Nothing needed" },
    {
      label: "Goal completion estimate",
      value: feasibility === "comfortable" || feasibility === "needs_cuts" ? `On time — about ${months} months` : etaWithoutIncomeMonths !== null ? `${months} months if the extra income happens; ~${etaWithoutIncomeMonths} months without it` : `${months} months only if the extra income happens`,
    },
  ];

  const assumptions = [pos.basis];
  if (pos.isEstimate) assumptions.push("Your averages are estimates because there's limited history.");
  if (extraIncome > 0) assumptions.push("Extra income is a target, not a guarantee. Track it in Earn to see if it's real.");
  if (reduction > 0) assumptions.push("Spending cuts assume you keep recording expenses so progress is measurable.");

  return {
    item: inp.item,
    price: inp.price,
    months,
    required,
    requiredMonthly,
    capacity,
    gap,
    reduction,
    extraIncome,
    savingPart: round2(savingPart),
    totals,
    feasibility,
    etaWithoutIncomeMonths,
    suggestedMonths: etaWithoutIncomeMonths !== null ? Math.ceil(etaWithoutIncomeMonths) : null,
    steps,
    assumptions,
    weekly: round2(required / Math.max(1, (months * 30.4375) / 7)),
    daily: round2(required / Math.max(1, months * 30.4375)),
  };
}

// ---------------------------------------------------------------------------
// "What if?" simulator
// ---------------------------------------------------------------------------

export type WhatIf =
  | { kind: "stop_daily"; amount: number }
  | { kind: "save_daily"; amount: number }
  | { kind: "earn_monthly"; amount: number }
  | { kind: "reduce_category"; category: string; percent: number; categoryMonthly: number }
  | { kind: "delay_goal"; months: number; remaining: number; monthsLeft: number };

export interface WhatIfResult {
  monthly: number;
  yearly: number;
  lines: string[];
}

export function whatIf(w: WhatIf, goalRemaining?: number): WhatIfResult {
  const fmt = (n: number) => `₹${Math.round(n).toLocaleString("en-IN")}`;
  let monthly = 0;
  const lines: string[] = [];
  switch (w.kind) {
    case "stop_daily":
    case "save_daily":
      monthly = w.amount * 30;
      lines.push(`${fmt(w.amount)} × 30 = ${fmt(monthly)}/month`, `${fmt(monthly)} × 12 = ${fmt(monthly * 12)}/year`);
      break;
    case "earn_monthly":
      monthly = w.amount;
      lines.push(`${fmt(monthly)}/month × 12 = ${fmt(monthly * 12)}/year`, "Only counts once the money is actually earned.");
      break;
    case "reduce_category":
      monthly = round2((w.categoryMonthly * w.percent) / 100);
      lines.push(`You spend about ${fmt(w.categoryMonthly)}/month on ${w.category}.`, `${w.percent}% less = ${fmt(monthly)}/month saved`, `${fmt(monthly)} × 12 = ${fmt(monthly * 12)}/year`);
      break;
    case "delay_goal": {
      const before = w.monthsLeft > 0 ? w.remaining / w.monthsLeft : w.remaining;
      const after = w.remaining / (Math.max(0, w.monthsLeft) + w.months);
      monthly = round2(before - after);
      lines.push(`Now: ${fmt(before)}/month for ${Math.max(0, Math.round(w.monthsLeft * 10) / 10)} months`, `Delayed ${w.months} months: ${fmt(after)}/month`, `That frees up ${fmt(monthly)}/month`);
      break;
    }
  }
  if (goalRemaining && monthly > 0 && w.kind !== "delay_goal") {
    lines.push(`Alone, this would cover your goal's remaining ${fmt(goalRemaining)} in about ${Math.ceil(goalRemaining / monthly)} months.`);
  }
  return { monthly: round2(monthly), yearly: round2(monthly * 12), lines };
}

export function addMonthsLabel(today: string, months: number): string {
  return addMonths(today, Math.ceil(months));
}

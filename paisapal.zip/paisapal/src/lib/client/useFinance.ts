"use client";
import { useMemo } from "react";
import useSWR from "swr";
import {
  budgetReport, computeAlerts, currentBalance, financialPosition, safeToSpend, todayISO, ym,
} from "@/lib/finance";
import type { Snapshot } from "@/lib/types";
import { fetcher } from "./api";

export function useSnapshot() {
  return useSWR<Snapshot>("/api/snapshot", fetcher, { revalidateOnFocus: true, dedupingInterval: 5000, keepPreviousData: true });
}

/**
 * The snapshot plus the derived numbers most screens need. All values are
 * recomputed from stored records whenever the snapshot changes.
 */
export function useFinance() {
  const { data, error, isLoading, mutate } = useSnapshot();
  const derived = useMemo(() => {
    if (!data) return null;
    const today = todayISO();
    const balance = currentBalance(data);
    const position = financialPosition(data, today);
    const sts = safeToSpend(data, today, balance);
    const { year, month } = ym(today);
    const budget = budgetReport(data.budgets, data.transactions, year, month, today);
    const dailyTarget = data.profile.daily_limit ?? (sts.daily > 0 ? sts.daily : null);
    const alerts = computeAlerts(data, today, balance, dailyTarget);
    return { s: data, today, balance, position, sts, budget, dailyTarget, alerts };
  }, [data]);
  return { data: derived, error: error as Error | undefined, isLoading, refresh: mutate };
}

export type FinanceData = NonNullable<ReturnType<typeof useFinance>["data"]>;

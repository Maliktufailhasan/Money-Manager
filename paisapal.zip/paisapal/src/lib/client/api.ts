"use client";
import { mutate } from "swr";

export class ApiError extends Error {
  constructor(public status: number, message: string) {
    super(message);
  }
}

export async function api<T = unknown>(path: string, init: RequestInit & { json?: unknown } = {}): Promise<T> {
  const { json, ...rest } = init;
  const res = await fetch(path, {
    ...rest,
    headers: { ...(json !== undefined ? { "content-type": "application/json" } : {}), ...(rest.headers ?? {}) },
    body: json !== undefined ? JSON.stringify(json) : rest.body,
  });
  if (res.status === 401 && typeof window !== "undefined") {
    window.location.assign(new URL(`/login?next=${encodeURIComponent(window.location.pathname)}`, window.location.origin).href);
  }
  const data = res.headers.get("content-type")?.includes("application/json") ? await res.json() : await res.text();
  if (!res.ok) throw new ApiError(res.status, (data && typeof data === "object" && "error" in data ? String(data.error) : null) ?? `Request failed (${res.status})`);
  return data as T;
}

export const fetcher = <T,>(url: string) => api<T>(url);

/** Refresh every cached view after a write (dashboard snapshot + paged lists). */
export function refreshAll() {
  return mutate((key) => typeof key === "string" && (key === "/api/snapshot" || key.startsWith("/api/data")), undefined, { revalidate: true });
}

type Resource = "transactions" | "budgets" | "goals" | "contributions" | "subscriptions" | "reminders" | "no-spend" | "earning-sources" | "categories";

export const db = {
  create: async <T = unknown>(resource: Resource, body: unknown) => {
    const r = await api<T>(`/api/data/${resource}`, { method: "POST", json: body });
    await refreshAll();
    return r;
  },
  update: async <T = unknown>(resource: Resource, id: string, patch: unknown) => {
    const r = await api<T>(`/api/data/${resource}/${id}`, { method: "PATCH", json: patch });
    await refreshAll();
    return r;
  },
  remove: async (resource: Resource, id: string) => {
    await api(`/api/data/${resource}/${id}`, { method: "DELETE" });
    await refreshAll();
  },
};

export async function updateProfile(patch: unknown) {
  const r = await api("/api/profile", { method: "PATCH", json: patch });
  await refreshAll();
  return r;
}

export async function payItem(source: "reminder" | "subscription", id: string, action: "pay" | "skip" = "pay", extra: { amount?: number; date?: string; payment_method?: string } = {}) {
  const r = await api("/api/pay", { method: "POST", json: { source, id, action, ...extra } });
  await refreshAll();
  return r;
}

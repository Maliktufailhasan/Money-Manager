import { EXPENSE_CATEGORIES, INCOME_SOURCES } from "@/lib/constants";
import type { CustomCategory } from "@/lib/types";

/** Built-in expense categories merged with the user's custom ones. */
export function expenseCategories(custom: CustomCategory[] = []): Record<string, string[]> {
  const out: Record<string, string[]> = Object.fromEntries(Object.entries(EXPENSE_CATEGORIES).map(([k, v]) => [k, [...v]]));
  for (const c of custom.filter((c) => c.kind === "expense")) {
    out[c.name] = Array.from(new Set([...(out[c.name] ?? []), ...c.subcategories]));
  }
  return out;
}

export function incomeSources(custom: CustomCategory[] = []): string[] {
  return Array.from(new Set([...INCOME_SOURCES, ...custom.filter((c) => c.kind === "income").map((c) => c.name)]));
}

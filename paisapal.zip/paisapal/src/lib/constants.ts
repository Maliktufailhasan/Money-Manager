export const EXPENSE_CATEGORIES: Record<string, string[]> = {
  Food: ["Mess", "Restaurant", "Fast Food", "Street Food", "Snacks", "Tea/Coffee", "Groceries", "Delivery", "Other"],
  Travel: ["Bus", "Metro", "Auto", "Cab", "Train", "Fuel", "Bike", "Parking", "Other"],
  Education: ["Books", "Courses", "Stationery", "Printing", "Projects", "College Fees", "Certifications", "Software"],
  Personal: ["Clothes", "Perfume", "Grooming", "Beauty", "Accessories", "Entertainment", "Shopping"],
  Technology: ["Mobile Recharge", "Internet", "Apps", "Subscriptions", "Software", "Gadgets"],
  Social: ["Friends", "Parties", "Movies", "Cafes", "Events", "Gifts"],
  Housing: ["Rent", "Hostel", "Electricity", "Laundry", "Other"],
  Other: ["Medical", "Emergency", "EMI", "Miscellaneous"],
};

export const INCOME_SOURCES = [
  "Pocket Money", "Parents", "Scholarship", "Internship", "Freelancing", "Part-time Work",
  "Stipend", "Business", "Selling Products", "Content Creation", "Affiliate Income",
  "Online Work", "Tutoring", "Gifts", "Refunds", "Other",
];

/** Income in this category is a refund: it reduces spending instead of counting as money received. */
export const REFUND_CATEGORY = "Refunds";

export const INCOME_TYPES = ["Allowance", "Earned", "Scholarship/Grant", "Gift", "Refund", "Other"];

export const PAYMENT_METHODS = ["UPI", "Cash", "Debit Card", "Credit Card", "Bank Transfer", "Wallet", "Other"];

export const QUICK_AMOUNTS = [20, 50, 100, 200, 500];

/** Default need/want guess for a category/subcategory; user can always override. */
export const WANT_SUBCATEGORIES = new Set([
  "Restaurant", "Fast Food", "Street Food", "Snacks", "Tea/Coffee", "Delivery",
  "Cab", "Perfume", "Beauty", "Accessories", "Entertainment", "Shopping", "Clothes",
  "Apps", "Subscriptions", "Gadgets", "Friends", "Parties", "Movies", "Cafes", "Events", "Gifts",
]);

export function defaultNeedOrWant(category: string, subcategory?: string | null): "need" | "want" {
  if (subcategory && WANT_SUBCATEGORIES.has(subcategory)) return "want";
  if (category === "Social" || category === "Personal") return "want";
  return "need";
}

export const GOAL_CATEGORIES = [
  "Phone", "Laptop", "Bike", "Car", "Book", "Course", "Camera", "Headphones", "Watch",
  "Perfume", "Clothes", "Trip", "Education", "Emergency Fund", "Custom",
];

export const EARNING_TYPES = [
  "Freelancing", "Tutoring", "Internship", "Part-time Job", "Content Creation", "Affiliate Marketing",
  "Digital Products", "Campus Work", "Coding Projects", "Design Services", "Video Editing", "Writing",
  "Online Services", "Other",
];

export const REMINDER_KINDS = ["Rent", "Hostel Fees", "Mobile Recharge", "Internet", "Subscription", "College Fees", "Loan/EMI", "Mess", "Transport", "Tuition", "Bill", "Other"];

export const CHART_COLORS = [
  "#6366f1", "#10b981", "#f59e0b", "#ef4444", "#06b6d4", "#8b5cf6", "#ec4899", "#84cc16", "#64748b", "#f97316",
];

import { z } from "zod";

const isoDate = z.string().regex(/^\d{4}-\d{2}-\d{2}$/, "Use YYYY-MM-DD");
const time = z.string().regex(/^\d{2}:\d{2}(:\d{2})?$/, "Use HH:mm");
const money = z.coerce.number().finite().min(0).max(100_000_000).transform((n) => Math.round(n * 100) / 100);
const positiveMoney = money.refine((n) => n > 0, "Amount must be greater than 0");
const text = (max: number) => z.string().trim().max(max);
const optText = (max: number) => z.string().trim().max(max).nullish().transform((v) => (v ? v : null));

export const transactionSchema = z.object({
  type: z.enum(["income", "expense"]),
  amount: positiveMoney,
  category: text(60).min(1, "Pick a category"),
  subcategory: optText(60),
  income_type: optText(40),
  description: optText(200),
  date: isoDate,
  time: time.nullish().transform((v) => v ?? null),
  merchant: optText(80),
  payment_method: optText(40),
  need_or_want: z.enum(["need", "want"]).nullish().transform((v) => v ?? null),
  essential: z.boolean().nullish().transform((v) => (v === undefined ? null : v)),
  recurring: z.boolean().default(false),
  recurrence: z.enum(["daily", "weekly", "monthly", "yearly", "custom"]).nullish().transform((v) => v ?? null),
  recurrence_days: z.coerce.number().int().min(1).max(366).nullish().transform((v) => v ?? null),
  earning_source_id: z.uuid().nullish().transform((v) => v ?? null),
  notes: optText(500),
});

export const budgetSchema = z.object({
  category: text(60).min(1),
  amount: money,
  month: z.coerce.number().int().min(1).max(12),
  year: z.coerce.number().int().min(2000).max(2100),
});

export const goalSchema = z.object({
  name: text(80).min(1, "Name your goal"),
  target_amount: positiveMoney,
  /** only accepted on create — becomes the first contribution */
  current_amount: money.optional(),
  target_date: isoDate.nullish().transform((v) => v ?? null),
  priority: z.enum(["high", "medium", "low"]).default("medium"),
  category: text(40).default("Custom"),
  is_emergency: z.boolean().default(false),
  status: z.enum(["active", "completed", "paused"]).default("active"),
  notes: optText(500),
});

export const contributionSchema = z.object({
  goal_id: z.uuid(),
  amount: z.coerce.number().finite().refine((n) => n !== 0, "Amount can't be 0").transform((n) => Math.round(n * 100) / 100),
  date: isoDate,
  note: optText(200),
});

export const subscriptionSchema = z.object({
  name: text(80).min(1),
  amount: money,
  billing_cycle: z.enum(["weekly", "monthly", "quarterly", "yearly"]),
  next_payment_date: isoDate,
  category: text(40).default("Technology"),
  status: z.enum(["active", "inactive"]).default("active"),
  remind_days_before: z.coerce.number().int().min(0).max(30).default(2),
  notes: optText(500),
});

export const reminderSchema = z.object({
  title: text(80).min(1),
  amount: money.default(0),
  due_date: isoDate,
  recurring: z.enum(["none", "weekly", "monthly", "quarterly", "yearly"]).default("none"),
  kind: text(40).default("Bill"),
  category: text(40).default("Other"),
  completed: z.boolean().default(false),
  notes: optText(500),
});

export const noSpendBase = z.object({
    title: text(80).min(1),
    category: text(60).min(1),
    subcategory: optText(60),
    start_date: isoDate,
    end_date: isoDate,
    limit_amount: money.default(0),
    baseline_monthly: money.nullish().transform((v) => v ?? null),
    active: z.boolean().default(true),
});
export const noSpendSchema = noSpendBase.refine((v) => v.end_date >= v.start_date, { message: "End date must be after start date", path: ["end_date"] });

export const earningSourceSchema = z.object({
  source: text(80).min(1),
  type: text(40).default("Other"),
  expected_income: money.default(0),
  hours: z.coerce.number().min(0).max(200).default(0),
  start_date: isoDate.nullish().transform((v) => v ?? null),
  status: z.enum(["idea", "active", "paused", "stopped"]).default("idea"),
  notes: optText(500),
});

export const categorySchema = z.object({
  kind: z.enum(["income", "expense"]),
  name: text(60).min(1),
  subcategories: z.array(text(60).min(1)).max(40).default([]),
});

export const profileSchema = z.object({
  name: text(80).optional(),
  currency: z.string().length(3).optional(),
  opening_balance: z.coerce.number().finite().min(-100_000_000).max(100_000_000).optional(),
  monthly_income_estimate: money.optional(),
  daily_limit: money.nullish(),
  onboarded: z.boolean().optional(),
  preferences: z
    .object({
      theme: z.enum(["light", "dark", "system"]).optional(),
      gamification: z.boolean().optional(),
      alerts: z.record(z.string(), z.boolean()).optional(),
      low_balance_threshold: money.optional(),
      large_txn_threshold: money.optional(),
      side_hustle_target: money.optional(),
    })
    .optional(),
});

export const onboardingSchema = z.object({
  name: text(80).min(1),
  currentMoney: z.coerce.number().finite().min(0).max(100_000_000),
  monthlyIncome: money,
  incomeSource: text(60).default("Pocket Money"),
  recurring: z.array(z.object({ title: text(80).min(1), amount: positiveMoney, kind: text(40), category: text(40), day: z.coerce.number().int().min(1).max(31) })).max(20).default([]),
  typicalFood: money.optional(),
  typicalTravel: money.optional(),
  currentSavings: money.default(0),
  goal: z
    .object({ name: text(80).min(1), category: text(40), target_amount: positiveMoney, target_date: isoDate.nullish() })
    .nullish(),
  emergencyTarget: money.nullish(),
  createBudget: z.boolean().default(true),
});

export type TransactionInput = z.infer<typeof transactionSchema>;

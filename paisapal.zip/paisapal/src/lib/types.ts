export type TxType = "income" | "expense";
export type NeedWant = "need" | "want";
export type Recurrence = "daily" | "weekly" | "monthly" | "yearly" | "custom";

export interface Profile {
  id: string;
  name: string;
  email: string | null;
  currency: string;
  opening_balance: number;
  monthly_income_estimate: number;
  daily_limit: number | null;
  onboarded: boolean;
  preferences: Preferences;
  created_at: string;
}

export interface Preferences {
  theme?: "light" | "dark" | "system";
  gamification?: boolean;
  alerts?: Partial<Record<AlertKind, boolean>>;
  low_balance_threshold?: number;
  large_txn_threshold?: number;
  side_hustle_target?: number;
}

export interface Transaction {
  id: string;
  user_id?: string;
  type: TxType;
  amount: number;
  category: string;
  subcategory: string | null;
  income_type: string | null;
  description: string | null;
  date: string; // yyyy-MM-dd
  time: string | null; // HH:mm[:ss]
  merchant: string | null;
  payment_method: string | null;
  need_or_want: NeedWant | null;
  essential: boolean | null;
  recurring: boolean;
  recurrence: Recurrence | null;
  recurrence_days: number | null;
  earning_source_id: string | null;
  notes: string | null;
  is_demo?: boolean;
  created_at: string;
}

export interface Budget {
  id: string;
  category: string; // expense category or "Savings"
  amount: number;
  month: number; // 1-12
  year: number;
}

export interface Goal {
  id: string;
  name: string;
  target_amount: number;
  current_amount: number;
  target_date: string | null;
  priority: "high" | "medium" | "low";
  category: string;
  is_emergency: boolean;
  status: "active" | "completed" | "paused";
  notes: string | null;
  created_at: string;
}

export interface GoalContribution {
  id: string;
  goal_id: string;
  amount: number;
  date: string;
  note: string | null;
  created_at: string;
}

export type BillingCycle = "weekly" | "monthly" | "quarterly" | "yearly";

export interface Subscription {
  id: string;
  name: string;
  amount: number;
  billing_cycle: BillingCycle;
  next_payment_date: string;
  category: string;
  status: "active" | "inactive";
  remind_days_before: number;
  notes: string | null;
  created_at: string;
}

export type ReminderRecurrence = "none" | "weekly" | "monthly" | "quarterly" | "yearly";

export interface Reminder {
  id: string;
  title: string;
  amount: number;
  due_date: string;
  recurring: ReminderRecurrence;
  kind: string;
  category: string;
  completed: boolean;
  notes: string | null;
  created_at: string;
}

export interface NoSpendRule {
  id: string;
  title: string;
  category: string;
  subcategory: string | null;
  start_date: string;
  end_date: string;
  limit_amount: number;
  baseline_monthly: number | null;
  active: boolean;
  created_at: string;
}

export interface EarningSource {
  id: string;
  source: string;
  type: string;
  expected_income: number;
  hours: number;
  start_date: string | null;
  status: "idea" | "active" | "paused" | "stopped";
  notes: string | null;
  created_at: string;
}

export interface CustomCategory {
  id: string;
  kind: TxType;
  name: string;
  subcategories: string[];
}

export interface LifetimeTotals {
  total_income: number;
  total_expense: number;
  first_date: string | null;
  tx_count: number;
}

/** Everything the dashboard needs, loaded in one request. */
export interface Snapshot {
  profile: Profile;
  totals: LifetimeTotals;
  /** transactions in the snapshot window (most recent ~13 months) */
  transactions: Transaction[];
  windowStart: string;
  budgets: Budget[];
  goals: Goal[];
  contributions: GoalContribution[];
  subscriptions: Subscription[];
  reminders: Reminder[];
  noSpendRules: NoSpendRule[];
  earningSources: EarningSource[];
  categories: CustomCategory[];
}

export type AlertKind =
  | "daily_limit"
  | "budget"
  | "unusual"
  | "upcoming_payment"
  | "goal_behind"
  | "subscription_renewal"
  | "low_balance"
  | "no_savings"
  | "large_transaction"
  | "no_spend";

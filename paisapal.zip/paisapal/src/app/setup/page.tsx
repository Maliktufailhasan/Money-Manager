import { isSupabaseConfigured } from "@/lib/supabase/env";
import { redirect } from "next/navigation";

export const dynamic = "force-dynamic";

export default function SetupPage() {
  if (isSupabaseConfigured) redirect("/");
  return (
    <div className="mx-auto max-w-xl px-4 py-16">
      <h1 className="text-2xl font-semibold">Almost there — connect a database</h1>
      <p className="mt-2 text-ink-2">PaisaPal stores your data in Supabase (PostgreSQL). Add these to <code>.env.local</code> and restart:</p>
      <pre className="mt-4 overflow-x-auto rounded-xl bg-surface-2 p-4 text-sm">{`NEXT_PUBLIC_SUPABASE_URL=https://xxxx.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=your-anon-key
# optional — enables the AI assistant
ANTHROPIC_API_KEY=sk-ant-...`}</pre>
      <p className="mt-4 text-ink-2">
        Then run the SQL in <code>supabase/migrations/0001_init.sql</code> in the Supabase SQL editor (or <code>supabase db push</code>). See the README for full steps.
      </p>
    </div>
  );
}

import { Wallet } from "lucide-react";

export default function AuthLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex min-h-dvh flex-col items-center justify-center px-4 py-10">
      <div className="mb-6 flex items-center gap-2 text-lg font-semibold">
        <span className="flex size-9 items-center justify-center rounded-xl bg-brand text-brand-ink">
          <Wallet className="size-4" />
        </span>
        PaisaPal
      </div>
      <div className="w-full max-w-sm rounded-3xl border border-line bg-surface p-6 shadow-sm">{children}</div>
      <p className="mt-6 max-w-sm text-center text-xs text-muted">Your money companion for college. Your data is private to your account.</p>
    </div>
  );
}

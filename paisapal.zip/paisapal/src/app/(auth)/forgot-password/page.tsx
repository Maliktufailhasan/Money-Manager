"use client";
import Link from "next/link";
import { useState } from "react";
import { Button, Field, Input } from "@/components/ui";
import { supabaseBrowser } from "@/lib/supabase/client";

export default function ForgotPasswordPage() {
  const [email, setEmail] = useState("");
  const [sent, setSent] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-lg font-semibold">Reset your password</h1>
        <p className="text-sm text-muted">We&apos;ll email you a link to set a new one.</p>
      </div>
      {sent ? (
        <p className="rounded-xl bg-good-soft p-3 text-sm text-good">If an account exists for {email}, a reset link is on its way.</p>
      ) : (
        <form
          className="space-y-3"
          onSubmit={async (e) => {
            e.preventDefault();
            setLoading(true);
            setError(null);
            const { error } = await supabaseBrowser().auth.resetPasswordForEmail(email, { redirectTo: `${location.origin}/auth/callback?next=/auth/update-password` });
            setLoading(false);
            if (error) setError(error.message);
            else setSent(true);
          }}
        >
          <Field label="Email">{(id) => <Input id={id} type="email" value={email} onChange={(e) => setEmail(e.target.value)} required />}</Field>
          {error && <p className="text-sm text-bad">{error}</p>}
          <Button type="submit" className="w-full" loading={loading}>
            Send reset link
          </Button>
        </form>
      )}
      <Link href="/login" className="block text-sm text-brand">
        Back to log in
      </Link>
    </div>
  );
}

import { addMonths, isoFromYM, todayISO, ym } from "@/lib/finance/dates";
import { suggestBudget } from "@/lib/finance/budget";
import { dbError, handle, parse, readJson, requireUser } from "@/lib/server/api";
import { onboardingSchema } from "@/lib/validation";

export const dynamic = "force-dynamic";

/** First-time setup: profile, recurring bills, goals and an initial budget. */
export const POST = handle(async (req: Request) => {
  const { supabase, user } = await requireUser();
  const inp = parse(onboardingSchema, await readJson(req));
  const today = todayISO();
  const { year, month } = ym(today);
  const day = Number(today.slice(8, 10));

  // money already put aside still belongs to the student, so it counts in the balance
  const prof = await supabase
    .from("profiles")
    .update({ name: inp.name, opening_balance: inp.currentMoney + inp.currentSavings, monthly_income_estimate: inp.monthlyIncome, onboarded: true })
    .eq("id", user.id);
  dbError(prof.error);

  if (inp.recurring.length) {
    const rows = inp.recurring.map((r) => {
      const thisMonth = isoFromYM(year, month, Math.min(r.day, 28));
      return { user_id: user.id, title: r.title, amount: r.amount, kind: r.kind, category: r.category, recurring: "monthly", due_date: r.day >= day ? thisMonth : addMonths(thisMonth, 1) };
    });
    dbError((await supabase.from("reminders").insert(rows)).error);
  }

  const goals: { name: string; category: string; target_amount: number; target_date: string | null; is_emergency: boolean; priority: string; start: number }[] = [];
  let savingsLeft = inp.currentSavings;
  if (inp.emergencyTarget && inp.emergencyTarget > 0) {
    const start = Math.min(savingsLeft, inp.emergencyTarget);
    savingsLeft -= start;
    goals.push({ name: "Emergency Fund", category: "Emergency Fund", target_amount: inp.emergencyTarget, target_date: null, is_emergency: true, priority: "high", start });
  }
  if (inp.goal) {
    const start = Math.min(savingsLeft, inp.goal.target_amount);
    savingsLeft -= start;
    goals.push({ name: inp.goal.name, category: inp.goal.category, target_amount: inp.goal.target_amount, target_date: inp.goal.target_date ?? null, is_emergency: false, priority: "high", start });
  }
  for (const g of goals) {
    const { start, ...goal } = g;
    const ins = await supabase.from("goals").insert({ ...goal, user_id: user.id }).select("id").single();
    dbError(ins.error);
    if (start > 0 && ins.data) dbError((await supabase.from("goal_contributions").insert({ user_id: user.id, goal_id: ins.data.id, amount: start, date: today, note: "Savings at setup" })).error);
  }

  if (inp.createBudget && inp.monthlyIncome > 0) {
    const lines = suggestBudget({
      income: inp.monthlyIncome,
      typicalFood: inp.typicalFood,
      typicalTravel: inp.typicalTravel,
      recurring: inp.recurring.map((r) => ({ category: r.category, amount: r.amount })),
    });
    const { error } = await supabase.from("budgets").upsert(lines.map((l) => ({ ...l, user_id: user.id, year, month })), { onConflict: "user_id,category,month,year" });
    dbError(error);
  }
  return { ok: true };
});

import { z } from "zod";
import { todayISO } from "@/lib/finance/dates";
import { offlineAnswer } from "@/lib/finance/offline";
import { aiConfigured, aiErrorMessage, askAssistant } from "@/lib/server/ai";
import { handle, parse, readJson, requireUser } from "@/lib/server/api";
import { loadSnapshot } from "@/lib/server/snapshot";

export const dynamic = "force-dynamic";
export const maxDuration = 120;

const schema = z.object({
  messages: z.array(z.object({ role: z.enum(["user", "assistant"]), content: z.string().trim().min(1).max(4000) })).min(1).max(30),
});

export const POST = handle(async (req: Request) => {
  const { supabase, user } = await requireUser();
  const { messages } = parse(schema, await readJson(req));
  // keep the last turns, always starting with a user message
  let history = messages.slice(-12);
  while (history.length && history[0].role !== "user") history = history.slice(1);
  const today = todayISO();
  const snap = await loadSnapshot(supabase, user.id, today);
  const question = history[history.length - 1].content;

  if (!aiConfigured()) return { text: offlineAnswer(question, snap, today), mode: "offline" };
  try {
    const { text, toolsUsed } = await askAssistant(history, snap, today);
    return { text, mode: "ai", toolsUsed };
  } catch (e) {
    console.error(e);
    return { text: `${aiErrorMessage(e)}\n\nHere's what I can calculate directly:\n\n${offlineAnswer(question, snap, today)}`, mode: "offline" };
  }
});

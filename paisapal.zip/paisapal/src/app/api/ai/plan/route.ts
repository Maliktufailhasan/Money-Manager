import { z } from "zod";
import { todayISO } from "@/lib/finance/dates";
import { financialPosition } from "@/lib/finance/position";
import { planFromZero } from "@/lib/finance/goals";
import { detectWaste } from "@/lib/finance/waste";
import { sum } from "@/lib/finance/money";
import { aiConfigured, aiErrorMessage, askAssistant } from "@/lib/server/ai";
import { handle, parse, readJson, requireUser } from "@/lib/server/api";
import { loadSnapshot } from "@/lib/server/snapshot";

export const dynamic = "force-dynamic";
export const maxDuration = 120;

const schema = z.object({
  item: z.string().trim().min(1).max(80),
  price: z.coerce.number().positive().max(100_000_000),
  months: z.coerce.number().min(1).max(120),
  startingAmount: z.coerce.number().min(0).max(100_000_000).default(0),
  incomePotential: z.coerce.number().min(0).max(10_000_000).nullish(),
  narrative: z.boolean().default(true),
});

/** "Start from ₹0" planner: exact numbers from the engine + an optional AI-written explanation. */
export const POST = handle(async (req: Request) => {
  const { supabase, user } = await requireUser();
  const inp = parse(schema, await readJson(req));
  const today = todayISO();
  const snap = await loadSnapshot(supabase, user.id, today);
  const pos = financialPosition(snap, today);
  const tracked = sum(snap.earningSources.filter((e) => e.status !== "stopped").map((e) => e.expected_income));
  const plan = planFromZero({ item: inp.item, price: inp.price, months: inp.months, startingAmount: inp.startingAmount, incomePotential: inp.incomePotential ?? tracked }, pos);
  const cuts = detectWaste(snap.transactions, snap.subscriptions, today, pos.avgMonthlyIncome).slice(0, 4);

  let narrative: string | null = null;
  let mode: "ai" | "offline" = "offline";
  let aiError: string | null = null;
  if (inp.narrative && aiConfigured()) {
    try {
      const r = await askAssistant(
        [{ role: "user", content: `Explain this savings plan to me and make it actionable. Plan (computed from my data — do not change these numbers):\n${JSON.stringify({ ...plan, steps: undefined })}\n\nMy biggest reducible spending patterns:\n${JSON.stringify(cuts.map((c) => ({ pattern: c.title, last30d: c.amount, saving_if_cut: c.monthlySaving })))}` }],
        snap,
        today,
        "Write: (1) one-sentence verdict on how realistic it is, (2) 'Where the cuts come from' — map the monthly cut to 2–4 specific habits from their real patterns with ₹ amounts, (3) 'Extra income ideas' only if extraIncome > 0 — 2–3 student-friendly options and label them as not guaranteed, referencing their tracked earning sources if any, (4) a simple month-by-month milestone line (e.g. Month 2: ₹X saved). Under 220 words. Do not call plan_purchase again.",
      );
      narrative = r.text;
      mode = "ai";
    } catch (e) {
      aiError = aiErrorMessage(e);
    }
  }
  return { plan, cuts, narrative, mode, aiError, position: { basis: pos.basis, dataQuality: pos.dataQuality } };
});

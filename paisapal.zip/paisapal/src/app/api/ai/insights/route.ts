import { todayISO } from "@/lib/finance/dates";
import { aiConfigured, aiErrorMessage, askAssistant } from "@/lib/server/ai";
import { handle, HttpError, requireUser } from "@/lib/server/api";
import { loadSnapshot } from "@/lib/server/snapshot";

export const dynamic = "force-dynamic";
export const maxDuration = 120;

/** AI-written summary of this month's spending, grounded in the computed context. */
export const POST = handle(async () => {
  const { supabase, user } = await requireUser();
  if (!aiConfigured()) throw new HttpError(503, "AI is not configured. Set ANTHROPIC_API_KEY to enable AI summaries.");
  const today = todayISO();
  const snap = await loadSnapshot(supabase, user.id, today);
  if (snap.totals.tx_count === 0) return { text: "Record a few transactions first — there's nothing to analyse yet." };
  try {
    const r = await askAssistant(
      [{ role: "user", content: "Analyse my spending so far this month compared with last month. Give me 4–6 short insights and 3 concrete adjustments for the rest of the month." }],
      snap,
      today,
      "Format: '### Insights' bullets (each tagged Recorded/Calculated/Estimate), then '### Adjustments' numbered list with ₹ impact. Under 250 words.",
    );
    return { text: r.text };
  } catch (e) {
    throw new HttpError(502, aiErrorMessage(e));
  }
});

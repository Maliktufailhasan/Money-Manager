import { z } from "zod";
import { dbError, handle, parse, readJson, requireUser } from "@/lib/server/api";

export const dynamic = "force-dynamic";

const schema = z.object({
  year: z.coerce.number().int().min(2000).max(2100),
  month: z.coerce.number().int().min(1).max(12),
  lines: z.array(z.object({ category: z.string().trim().min(1).max(60), amount: z.coerce.number().min(0).max(100_000_000) })).max(60),
});

/** Replace all budget lines for one month in a single call. */
export const PUT = handle(async (req: Request) => {
  const { supabase, user } = await requireUser();
  const { year, month, lines } = parse(schema, await readJson(req));
  const dedup = new Map<string, number>();
  for (const l of lines) dedup.set(l.category, Math.round(l.amount * 100) / 100);
  const keep = [...dedup.keys()];

  const del = supabase.from("budgets").delete().eq("year", year).eq("month", month);
  const { error: delErr } = keep.length ? await del.not("category", "in", `(${keep.map((k) => `"${k.replace(/"/g, "")}"`).join(",")})`) : await del;
  dbError(delErr);
  if (keep.length) {
    const { error } = await supabase
      .from("budgets")
      .upsert([...dedup.entries()].map(([category, amount]) => ({ user_id: user.id, category, amount, year, month })), { onConflict: "user_id,category,month,year" });
    dbError(error);
  }
  return { ok: true };
});

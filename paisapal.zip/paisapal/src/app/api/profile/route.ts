import { dbError, handle, HttpError, normalize, parse, readJson, requireUser } from "@/lib/server/api";
import { profileSchema } from "@/lib/validation";

export const dynamic = "force-dynamic";

export const PATCH = handle(async (req: Request) => {
  const { supabase, user } = await requireUser();
  const raw = await readJson(req);
  const patch = parse(profileSchema, raw) as Record<string, unknown>;
  if (patch.preferences) {
    // merge preferences instead of replacing them
    const { data } = await supabase.from("profiles").select("preferences").eq("id", user.id).single();
    const cur = (data?.preferences ?? {}) as Record<string, unknown>;
    const next = patch.preferences as Record<string, unknown>;
    patch.preferences = { ...cur, ...next, alerts: { ...((cur.alerts as object) ?? {}), ...((next.alerts as object) ?? {}) } };
  }
  if (!Object.keys(patch).length) throw new HttpError(400, "Nothing to update");
  const { data, error } = await supabase.from("profiles").update(patch).eq("id", user.id).select("*").single();
  dbError(error);
  return normalize(data);
});

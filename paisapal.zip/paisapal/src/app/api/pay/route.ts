import { z } from "zod";
import { EXPENSE_CATEGORIES, defaultNeedOrWant } from "@/lib/constants";
import { todayISO } from "@/lib/finance/dates";
import { advance } from "@/lib/finance/schedule";
import { dbError, handle, HttpError, parse, readJson, requireUser } from "@/lib/server/api";

export const dynamic = "force-dynamic";

const schema = z.object({
  source: z.enum(["reminder", "subscription"]),
  id: z.uuid(),
  action: z.enum(["pay", "skip"]).default("pay"),
  date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/).optional(),
  amount: z.coerce.number().positive().optional(),
  payment_method: z.string().max(40).optional(),
});

const KIND_TO_SUB: Record<string, string> = { Internet: "Internet", "Mobile Recharge": "Mobile Recharge", Subscription: "Subscriptions", Rent: "Rent", "Hostel Fees": "Hostel", "College Fees": "College Fees", "Loan/EMI": "EMI", Mess: "Mess", Transport: "Bus" };

/** Mark a bill or subscription as paid: records the expense and moves the due date forward. */
export const POST = handle(async (req: Request) => {
  const { supabase, user } = await requireUser();
  const body = parse(schema, await readJson(req));
  const date = body.date ?? todayISO();

  if (body.source === "reminder") {
    const { data: r, error } = await supabase.from("reminders").select("*").eq("id", body.id).maybeSingle();
    dbError(error);
    if (!r) throw new HttpError(404, "Reminder not found");
    let txId: string | null = null;
    if (body.action === "pay" && (body.amount ?? Number(r.amount)) > 0) {
      const sub = KIND_TO_SUB[r.kind] && (EXPENSE_CATEGORIES[r.category] ?? []).includes(KIND_TO_SUB[r.kind]) ? KIND_TO_SUB[r.kind] : null;
      const ins = await supabase.from("transactions").insert({
        user_id: user.id, type: "expense", amount: body.amount ?? Number(r.amount), category: r.category, subcategory: sub,
        description: r.title, date, payment_method: body.payment_method ?? null, need_or_want: "need", essential: true,
        recurring: r.recurring !== "none", recurrence: r.recurring === "none" || r.recurring === "quarterly" ? null : r.recurring,
      }).select("id").single();
      dbError(ins.error);
      txId = ins.data?.id ?? null;
    }
    const patch = r.recurring === "none" ? { completed: true } : { due_date: advance(r.due_date, r.recurring) };
    const up = await supabase.from("reminders").update(patch).eq("id", r.id);
    dbError(up.error);
    return { ok: true, transactionId: txId, ...patch };
  }

  const { data: s, error } = await supabase.from("subscriptions").select("*").eq("id", body.id).maybeSingle();
  dbError(error);
  if (!s) throw new HttpError(404, "Subscription not found");
  let txId: string | null = null;
  if (body.action === "pay" && (body.amount ?? Number(s.amount)) > 0) {
    const sub = (EXPENSE_CATEGORIES[s.category] ?? []).includes("Subscriptions") ? "Subscriptions" : null;
    const ins = await supabase.from("transactions").insert({
      user_id: user.id, type: "expense", amount: body.amount ?? Number(s.amount), category: s.category, subcategory: sub, description: s.name, merchant: s.name,
      date, payment_method: body.payment_method ?? null, need_or_want: defaultNeedOrWant(s.category, sub), essential: false, recurring: true,
      recurrence: s.billing_cycle === "quarterly" ? "custom" : s.billing_cycle, recurrence_days: s.billing_cycle === "quarterly" ? 91 : null,
    }).select("id").single();
    dbError(ins.error);
    txId = ins.data?.id ?? null;
  }
  let next = advance(s.next_payment_date, s.billing_cycle);
  let guard = 0;
  while (next <= date && guard++ < 200) next = advance(next, s.billing_cycle);
  const up = await supabase.from("subscriptions").update({ next_payment_date: next }).eq("id", s.id);
  dbError(up.error);
  return { ok: true, transactionId: txId, next_payment_date: next };
});

import { todayISO } from "@/lib/finance/dates";
import { dbError, handle, requireUser } from "@/lib/server/api";
import { buildDemoData } from "@/lib/server/demo";

export const dynamic = "force-dynamic";

const DEMO_TABLES = ["goal_contributions", "transactions", "budgets", "goals", "subscriptions", "reminders", "no_spend_rules", "earning_sources"];

export const POST = handle(async () => {
  const { supabase, user } = await requireUser();
  for (const t of DEMO_TABLES) dbError((await supabase.from(t).delete().eq("is_demo", true)).error);
  const d = buildDemoData(user.id, todayISO());

  const earn = await supabase.from("earning_sources").insert(d.earningSources, { defaultToNull: false }).select("id");
  dbError(earn.error);
  const hustleId = earn.data?.[0]?.id ?? null;
  const txs = d.transactions.map((t) => (t.category === "Freelancing" && hustleId ? { ...t, earning_source_id: hustleId } : t));
  for (let i = 0; i < txs.length; i += 500) dbError((await supabase.from("transactions").insert(txs.slice(i, i + 500), { defaultToNull: false })).error);

  // demo budget lines only fill categories the user hasn't budgeted themselves
  const { data: existing } = await supabase.from("budgets").select("category,year,month").eq("is_demo", false);
  const taken = new Set((existing ?? []).map((b) => `${b.category}|${b.year}|${b.month}`));
  const budgets = d.budgets.filter((b) => !taken.has(`${b.category}|${b.year}|${b.month}`));
  if (budgets.length) dbError((await supabase.from("budgets").insert(budgets)).error);

  const goals = await supabase.from("goals").insert(d.goals, { defaultToNull: false }).select("id");
  dbError(goals.error);
  const contribs = d.contributions((goals.data ?? []).map((g) => g.id));
  if (contribs.length) dbError((await supabase.from("goal_contributions").insert(contribs)).error);
  dbError((await supabase.from("subscriptions").insert(d.subscriptions)).error);
  dbError((await supabase.from("reminders").insert(d.reminders)).error);
  dbError((await supabase.from("no_spend_rules").insert(d.noSpend)).error);
  return { ok: true, transactions: txs.length };
});

export const DELETE = handle(async () => {
  const { supabase } = await requireUser();
  for (const t of DEMO_TABLES) dbError((await supabase.from(t).delete().eq("is_demo", true)).error);
  return { ok: true };
});

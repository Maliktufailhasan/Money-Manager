import { z } from "zod";
import { dbError, handle, HttpError, normalize, parse, readJson, requireUser } from "@/lib/server/api";
import { fetchAll } from "@/lib/server/snapshot";
import {
  budgetSchema, categorySchema, contributionSchema, earningSourceSchema, goalSchema, noSpendSchema, profileSchema, reminderSchema, subscriptionSchema, transactionSchema,
} from "@/lib/validation";

export const dynamic = "force-dynamic";

const TABLES = ["categories", "earning_sources", "goals", "goal_contributions", "transactions", "budgets", "subscriptions", "reminders", "no_spend_rules"] as const;

/** Full JSON backup of everything the user owns. */
export const GET = handle(async () => {
  const { supabase, user } = await requireUser();
  const out: Record<string, unknown> = { app: "paisapal", version: 1, exported_at: new Date().toISOString() };
  const prof = await supabase.from("profiles").select("name,currency,opening_balance,monthly_income_estimate,daily_limit,onboarded,preferences").eq("id", user.id).single();
  dbError(prof.error);
  out.profile = normalize(prof.data);
  for (const t of TABLES) {
    const r = await fetchAll(supabase, t, (q) => q.order("created_at"));
    dbError(r.error);
    out[t] = normalize((r.data ?? []).map((row) => {
      const rest = { ...row };
      delete rest.user_id;
      return rest;
    }));
  }
  return new Response(JSON.stringify(out, null, 2), {
    headers: { "content-type": "application/json", "content-disposition": `attachment; filename="paisapal-backup-${new Date().toISOString().slice(0, 10)}.json"` },
  });
});

const importSchema = z.object({
  mode: z.enum(["merge", "replace"]).default("merge"),
  backup: z.object({
    app: z.literal("paisapal"),
    version: z.literal(1),
    profile: z.unknown().optional(),
    categories: z.array(z.unknown()).default([]),
    earning_sources: z.array(z.unknown()).default([]),
    goals: z.array(z.unknown()).default([]),
    goal_contributions: z.array(z.unknown()).default([]),
    transactions: z.array(z.unknown()).default([]),
    budgets: z.array(z.unknown()).default([]),
    subscriptions: z.array(z.unknown()).default([]),
    reminders: z.array(z.unknown()).default([]),
    no_spend_rules: z.array(z.unknown()).default([]),
  }),
});

const idOf = (r: unknown) => (r && typeof r === "object" && "id" in r ? String((r as { id: unknown }).id) : null);

async function insertChunks(supabase: Awaited<ReturnType<typeof requireUser>>["supabase"], table: string, rows: Record<string, unknown>[], select = false) {
  const out: { id: string }[] = [];
  for (let i = 0; i < rows.length; i += 500) {
    const chunk = rows.slice(i, i + 500);
    const q = supabase.from(table).insert(chunk, { defaultToNull: false });
    const { data, error } = select ? await q.select("id") : await q;
    dbError(error);
    if (data) out.push(...(data as { id: string }[]));
  }
  return out;
}

/** Restore a JSON backup. Every row is re-validated and re-owned by the current user; ids are regenerated. */
export const POST = handle(async (req: Request) => {
  const { supabase, user } = await requireUser();
  const { mode, backup } = parse(importSchema, await readJson(req));
  const total = TABLES.reduce((a, t) => a + (backup[t]?.length ?? 0), 0);
  if (total > 60_000) throw new HttpError(413, "Backup too large");
  const own = (r: object) => ({ ...r, user_id: user.id });
  const val = <T extends z.ZodType>(s: T, rows: unknown[], label: string) =>
    rows.map((r, i) => {
      const p = s.safeParse(r);
      if (!p.success) throw new HttpError(400, `${label} #${i + 1}: ${p.error.issues[0]?.path.join(".")} ${p.error.issues[0]?.message}`);
      return p.data as Record<string, unknown>;
    });

  // validate everything before touching the database
  const categories = val(categorySchema, backup.categories, "category");
  const earning = val(earningSourceSchema, backup.earning_sources, "earning source");
  const goals = val(goalSchema.omit({ current_amount: true }), backup.goals, "goal");
  const contribs = val(contributionSchema.extend({ goal_id: z.string() }), backup.goal_contributions, "goal contribution");
  const txs = val(transactionSchema.extend({ earning_source_id: z.string().nullish() }), backup.transactions, "transaction");
  const budgets = val(budgetSchema, backup.budgets, "budget");
  const subs = val(subscriptionSchema, backup.subscriptions, "subscription");
  const rems = val(reminderSchema, backup.reminders, "reminder");
  const rules = val(noSpendSchema, backup.no_spend_rules, "don't-spend rule");
  const profile = backup.profile ? parse(profileSchema, backup.profile) : null;

  if (mode === "replace") {
    for (const t of [...TABLES].reverse()) dbError((await supabase.from(t).delete().eq("user_id", user.id)).error);
  }
  if (profile && mode === "replace") dbError((await supabase.from("profiles").update(profile).eq("id", user.id)).error);

  if (categories.length) dbError((await supabase.from("categories").upsert(categories.map(own), { onConflict: "user_id,kind,name", ignoreDuplicates: true })).error);

  const earnMap = new Map<string, string>();
  const newEarn = await insertChunks(supabase, "earning_sources", earning.map(own), true);
  backup.earning_sources.forEach((r, i) => idOf(r) && newEarn[i] && earnMap.set(idOf(r)!, newEarn[i].id));

  const goalMap = new Map<string, string>();
  const newGoals = await insertChunks(supabase, "goals", goals.map((g) => own({ ...g, status: g.status === "completed" ? "active" : g.status })), true);
  backup.goals.forEach((r, i) => idOf(r) && newGoals[i] && goalMap.set(idOf(r)!, newGoals[i].id));

  await insertChunks(supabase, "goal_contributions", contribs.filter((c) => goalMap.has(String(c.goal_id))).map((c) => own({ ...c, goal_id: goalMap.get(String(c.goal_id)) })));
  await insertChunks(supabase, "transactions", txs.map((t) => own({ ...t, earning_source_id: t.earning_source_id ? earnMap.get(String(t.earning_source_id)) ?? null : null })));
  if (budgets.length) dbError((await supabase.from("budgets").upsert(budgets.map(own), { onConflict: "user_id,category,month,year" })).error);
  await insertChunks(supabase, "subscriptions", subs.map(own));
  await insertChunks(supabase, "reminders", rems.map(own));
  await insertChunks(supabase, "no_spend_rules", rules.map(own));

  return { ok: true, imported: { transactions: txs.length, goals: goals.length, budgets: budgets.length, subscriptions: subs.length, reminders: rems.length } };
});

/** Delete all of the user's financial data (keeps the account). */
export const DELETE = handle(async () => {
  const { supabase, user } = await requireUser();
  for (const t of [...TABLES].reverse()) dbError((await supabase.from(t).delete().eq("user_id", user.id)).error);
  dbError((await supabase.from("profiles").update({ opening_balance: 0, onboarded: false }).eq("id", user.id)).error);
  return { ok: true };
});

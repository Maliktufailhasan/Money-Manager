import { NextResponse } from "next/server";
import { dbError, handle, HttpError, normalize, parse, readJson, requireUser } from "@/lib/server/api";
import { RESOURCES } from "@/lib/server/resources";

export const dynamic = "force-dynamic";

type Ctx = { params: Promise<{ resource: string }> };

function resource(name: string) {
  const def = RESOURCES[name];
  if (!def) throw new HttpError(404, "Unknown resource");
  return def;
}

/** Strip characters that have meaning inside a PostgREST or() filter. */
const safeTerm = (q: string) => q.replace(/[,()%*\\:."']/g, " ").trim().slice(0, 60);

export const GET = handle(async (req: Request, ctx: Ctx) => {
  const { resource: name } = await ctx.params;
  const def = resource(name);
  const { supabase } = await requireUser();
  const sp = new URL(req.url).searchParams;

  if (name !== "transactions") {
    let q = supabase.from(def.table).select("*");
    for (const o of def.order) q = q.order(o.column, { ascending: o.ascending });
    const { data, error } = await q.limit(2000);
    dbError(error);
    return normalize(data ?? []);
  }

  // transactions: search, filters, pagination
  const page = Math.max(1, Number(sp.get("page") ?? 1) || 1);
  const pageSize = Math.min(200, Math.max(5, Number(sp.get("pageSize") ?? 25) || 25));
  let q = supabase.from("transactions").select("*", { count: "exact" });
  const eq = (key: string) => sp.get(key) || null;
  if (eq("type")) q = q.eq("type", eq("type")!);
  if (eq("category")) q = q.eq("category", eq("category")!);
  if (eq("subcategory")) q = q.eq("subcategory", eq("subcategory")!);
  if (eq("payment_method")) q = q.eq("payment_method", eq("payment_method")!);
  if (eq("need_or_want")) q = q.eq("need_or_want", eq("need_or_want")!);
  if (eq("essential")) q = q.eq("essential", eq("essential") === "true");
  if (eq("from")) q = q.gte("date", eq("from")!);
  if (eq("to")) q = q.lte("date", eq("to")!);
  if (eq("min")) q = q.gte("amount", Number(eq("min")));
  if (eq("max")) q = q.lte("amount", Number(eq("max")));
  if (eq("merchant")) q = q.ilike("merchant", `%${safeTerm(eq("merchant")!)}%`);
  const term = eq("q") ? safeTerm(eq("q")!) : "";
  if (term) q = q.or(`description.ilike.%${term}%,merchant.ilike.%${term}%,notes.ilike.%${term}%,category.ilike.%${term}%,subcategory.ilike.%${term}%`);
  const sort = sp.get("sort") === "amount" ? "amount" : "date";
  const asc = sp.get("dir") === "asc";
  q = q.order(sort, { ascending: asc });
  if (sort === "date") q = q.order("time", { ascending: asc, nullsFirst: false }).order("created_at", { ascending: asc });
  const { data, error, count } = await q.range((page - 1) * pageSize, page * pageSize - 1);
  dbError(error);
  return { rows: normalize(data ?? []), total: count ?? 0, page, pageSize };
});

export const POST = handle(async (req: Request, ctx: Ctx) => {
  const { resource: name } = await ctx.params;
  const def = resource(name);
  const { supabase, user } = await requireUser();
  const body = await readJson(req);
  const items = Array.isArray(body) ? body : [body];
  if (items.length === 0 || items.length > 500) throw new HttpError(400, "Send 1–500 items");
  const rows = items.map((it) => ({ ...(parse(def.create, it) as Record<string, unknown>), user_id: user.id }));

  if (name === "goals") {
    // a starting amount is stored as the goal's first contribution so the
    // contribution history and goals.current_amount always agree
    const created = [];
    for (const row of rows) {
      const { current_amount, ...goal } = row as Record<string, unknown> & { current_amount?: number };
      const ins = await supabase.from("goals").insert(goal).select("*").single();
      dbError(ins.error);
      if (current_amount && current_amount > 0) {
        const c = await supabase.from("goal_contributions").insert({ user_id: user.id, goal_id: ins.data.id, amount: current_amount, date: new Date().toISOString().slice(0, 10), note: "Starting amount" });
        dbError(c.error);
      }
      created.push(ins.data);
    }
    return NextResponse.json(normalize(Array.isArray(body) ? created : created[0]), { status: 201 });
  }

  const { data, error } = await supabase.from(def.table).insert(rows, { defaultToNull: false }).select("*");
  dbError(error);
  return NextResponse.json(normalize(Array.isArray(body) ? data : data?.[0]), { status: 201 });
});

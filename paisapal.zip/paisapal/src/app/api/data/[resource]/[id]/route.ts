import { z } from "zod";
import { dbError, handle, HttpError, normalize, parse, readJson, requireUser } from "@/lib/server/api";
import { RESOURCES } from "@/lib/server/resources";

export const dynamic = "force-dynamic";

type Ctx = { params: Promise<{ resource: string; id: string }> };

async function target(ctx: Ctx) {
  const { resource, id } = await ctx.params;
  const def = RESOURCES[resource];
  if (!def) throw new HttpError(404, "Unknown resource");
  if (!z.uuid().safeParse(id).success) throw new HttpError(400, "Bad id");
  return { def, id };
}

export const PATCH = handle(async (req: Request, ctx: Ctx) => {
  const { def, id } = await target(ctx);
  const { supabase } = await requireUser();
  const raw = await readJson(req);
  if (!raw || typeof raw !== "object" || Array.isArray(raw)) throw new HttpError(400, "Send an object");
  const patch = parse(def.update, raw) as Record<string, unknown>;
  // strip keys the client did not send (zod defaults would otherwise overwrite them)
  for (const k of Object.keys(patch)) if (!(k in raw)) delete patch[k];
  delete patch.user_id;
  if (!Object.keys(patch).length) throw new HttpError(400, "Nothing to update");
  const { data, error } = await supabase.from(def.table).update(patch).eq("id", id).select("*").maybeSingle();
  dbError(error);
  if (!data) throw new HttpError(404, "Not found");
  return normalize(data);
});

export const DELETE = handle(async (_req: Request, ctx: Ctx) => {
  const { def, id } = await target(ctx);
  const { supabase } = await requireUser();
  const { data, error } = await supabase.from(def.table).delete().eq("id", id).select("id");
  dbError(error);
  if (!data?.length) throw new HttpError(404, "Not found");
  return { ok: true };
});

import { todayISO } from "@/lib/finance/dates";
import { handle, requireUser } from "@/lib/server/api";
import { loadSnapshot } from "@/lib/server/snapshot";

export const dynamic = "force-dynamic";

export const GET = handle(async () => {
  const { supabase, user } = await requireUser();
  return loadSnapshot(supabase, user.id, todayISO());
});

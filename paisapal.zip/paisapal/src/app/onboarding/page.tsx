"use client";
import { ArrowLeft, ArrowRight, Check, Sparkles, Wallet } from "lucide-react";
import { useRouter } from "next/navigation";
import { useState, type ReactNode } from "react";
import { RecurringEditor, type RecurringRow } from "@/components/manage/OnboardingParts";
import { errMsg, toNum } from "@/components/manage/shared";
import { Button, Chip, Field, Input, Money, MoneyInput, SourceTag, ToastProvider, cn, useToast } from "@/components/ui";
import { api, refreshAll } from "@/lib/client/api";
import { useSnapshot } from "@/lib/client/useFinance";
import { INCOME_SOURCES } from "@/lib/constants";
import { SAVINGS_BUDGET, suggestBudget, sum, todayISO } from "@/lib/finance";

const STEPS = ["Name", "Money now", "Income", "Fixed costs", "Food & travel", "Savings", "Goal", "Review"];
const GOAL_CHIPS = [
  { label: "Phone", category: "Phone" },
  { label: "Laptop", category: "Laptop" },
  { label: "Bike", category: "Bike" },
  { label: "Car", category: "Car" },
  { label: "Education", category: "Education" },
  { label: "Travel", category: "Trip" },
  { label: "Custom", category: "Custom" },
];
const EMERGENCY = ["5000", "10000", "25000"];

export default function OnboardingPage() {
  return (
    <ToastProvider>
      <Wizard />
    </ToastProvider>
  );
}

function Wizard() {
  const router = useRouter();
  const toast = useToast();
  const { data: snap } = useSnapshot();
  const [step, setStep] = useState(0);
  const [error, setError] = useState<string | null>(null);
  const [rowErrors, setRowErrors] = useState<Record<number, string>>({});
  const [saving, setSaving] = useState(false);

  const [nameInput, setName] = useState<string | null>(null);
  const name = nameInput ?? snap?.profile.name ?? "";
  const [wallet, setWallet] = useState("");
  const [bank, setBank] = useState("");
  const [income, setIncome] = useState("");
  const [source, setSource] = useState("Pocket Money");
  const [rows, setRows] = useState<RecurringRow[]>([]);
  const [food, setFood] = useState("");
  const [travel, setTravel] = useState("");
  const [savings, setSavings] = useState("");
  const [emergency, setEmergency] = useState<string>("skip");
  const [emergencyCustom, setEmergencyCustom] = useState("");
  const [goalCat, setGoalCat] = useState<string | null>(null);
  const [goalName, setGoalName] = useState("");
  const [goalPrice, setGoalPrice] = useState("");
  const [goalDate, setGoalDate] = useState("");

  const today = todayISO();
  const firstName = name.trim().split(/\s+/)[0];
  const recurring = rows.map((r) => ({ title: r.title.trim(), amount: toNum(r.amount) ?? 0, kind: r.kind, category: r.category, day: Number(r.day) || 1 }));
  const emergencyTarget = emergency === "skip" ? null : emergency === "custom" ? toNum(emergencyCustom) : Number(emergency);
  const incomeNum = toNum(income) ?? 0;
  const budget = incomeNum > 0 ? suggestBudget({ income: incomeNum, typicalFood: toNum(food) ?? undefined, typicalTravel: toNum(travel) ?? undefined, recurring }) : [];

  function validate(): boolean {
    setError(null);
    setRowErrors({});
    switch (step) {
      case 0:
        if (!name.trim()) return fail("What should we call you?");
        return true;
      case 1:
        if ((wallet && toNum(wallet) === null) || (bank && toNum(bank) === null)) return fail("Enter amounts as numbers");
        return true;
      case 2:
        if (toNum(income) === null) return fail("Enter your usual monthly income — put 0 if you don't have any right now");
        return true;
      case 3: {
        const errs: Record<number, string> = {};
        for (const r of rows) {
          const day = Number(r.day);
          if (!r.title.trim()) errs[r.key] = "Give it a name";
          else if (!(toNum(r.amount) ?? 0)) errs[r.key] = "Enter the monthly amount";
          else if (!day || day < 1 || day > 31) errs[r.key] = "Day must be 1–31";
        }
        setRowErrors(errs);
        if (Object.keys(errs).length) return fail("Fix the highlighted rows, or remove them");
        return true;
      }
      case 5:
        if (savings && toNum(savings) === null) return fail("Enter savings as a number");
        if (emergency === "custom" && !(toNum(emergencyCustom) ?? 0)) return fail("Enter your emergency fund target");
        return true;
      case 6:
        if (goalCat) {
          if (!goalName.trim()) return fail("Name your goal");
          if (!(toNum(goalPrice) ?? 0)) return fail("How much does it cost?");
          if (goalDate && goalDate <= today) return fail("Pick a date in the future");
        }
        return true;
      default:
        return true;
    }
  }
  function fail(msg: string) {
    setError(msg);
    return false;
  }

  function next() {
    if (validate()) setStep((s) => Math.min(STEPS.length - 1, s + 1));
  }
  function back() {
    setError(null);
    setStep((s) => Math.max(0, s - 1));
  }
  function skipSetup() {
    try {
      sessionStorage.setItem("pp-skip-onboarding", "1");
    } catch {}
    router.replace("/");
  }

  async function submit() {
    setSaving(true);
    try {
      await api("/api/onboarding", {
        method: "POST",
        json: {
          name: name.trim(),
          currentMoney: (toNum(wallet) ?? 0) + (toNum(bank) ?? 0),
          monthlyIncome: incomeNum,
          incomeSource: source,
          recurring,
          typicalFood: toNum(food) ?? undefined,
          typicalTravel: toNum(travel) ?? undefined,
          currentSavings: toNum(savings) ?? 0,
          goal: goalCat ? { name: goalName.trim(), category: goalCat, target_amount: toNum(goalPrice), target_date: goalDate || null } : null,
          emergencyTarget,
          createBudget: true,
        },
      });
      await refreshAll();
      toast("All set! Welcome to PaisaPal");
      router.replace("/");
    } catch (e) {
      toast(errMsg(e), "bad");
      setSaving(false);
    }
  }

  const last = step === STEPS.length - 1;

  return (
    <div className="flex min-h-dvh flex-col items-center px-4 py-6 sm:py-10">
      <div className="w-full max-w-lg">
        <div className="mb-6 flex items-center justify-between">
          <span className="flex items-center gap-2 font-semibold">
            <span className="flex size-8 items-center justify-center rounded-xl bg-brand text-brand-ink">
              <Wallet className="size-4" />
            </span>
            PaisaPal
          </span>
          <button type="button" onClick={skipSetup} className="text-xs font-medium text-muted hover:text-ink">
            Skip setup
          </button>
        </div>

        <div className="mb-1 flex items-center justify-between text-xs text-muted">
          <span>
            Step {step + 1} of {STEPS.length}
          </span>
          <span>{STEPS[step]}</span>
        </div>
        <div className="mb-6 flex gap-1" aria-hidden>
          {STEPS.map((s, i) => (
            <div key={s} className={cn("h-1.5 flex-1 rounded-full transition-colors", i <= step ? "bg-brand" : "bg-surface-2")} />
          ))}
        </div>

        <div className="animate-in rounded-3xl border border-line bg-surface p-5 shadow-sm sm:p-6" key={step}>
          {step === 0 && (
            <Step title="Hi! Let's set things up" sub="Takes about 2 minutes. You can change everything later.">
              <Field label="What should we call you?" error={error}>
                {(id) => <Input id={id} value={name} onChange={(e) => setName(e.target.value)} placeholder="Your name" maxLength={80} autoComplete="given-name" onKeyDown={(e) => e.key === "Enter" && next()} />}
              </Field>
            </Step>
          )}

          {step === 1 && (
            <Step title={`How much money do you have right now${firstName ? `, ${firstName}` : ""}?`} sub="A rough number is fine. This becomes your starting balance.">
              <div className="grid grid-cols-2 gap-3">
                <Field label="Cash in wallet">{(id) => <MoneyInput id={id} value={wallet} onChange={setWallet} placeholder="0" />}</Field>
                <Field label="In bank / UPI">{(id) => <MoneyInput id={id} value={bank} onChange={setBank} placeholder="0" />}</Field>
              </div>
              <Total label="Total" value={(toNum(wallet) ?? 0) + (toNum(bank) ?? 0)} />
              {error && <p className="text-xs text-bad">{error}</p>}
            </Step>
          )}

          {step === 2 && (
            <Step title="How much money comes in each month?" sub="On average — pocket money, stipend, part-time pay, everything.">
              <Field label="Average monthly income" error={error}>
                {(id) => <MoneyInput id={id} value={income} onChange={setIncome} placeholder="e.g. 8000" />}
              </Field>
              <div>
                <p className="mb-1.5 text-xs font-medium text-ink-2">Main source</p>
                <div className="flex flex-wrap gap-1.5">
                  {INCOME_SOURCES.filter((x) => x !== "Refunds").map((x) => (
                    <Chip key={x} active={source === x} onClick={() => setSource(x)}>
                      {x}
                    </Chip>
                  ))}
                </div>
              </div>
            </Step>
          )}

          {step === 3 && (
            <Step title="Any fixed monthly costs?" sub="Rent, hostel, mess, recharges… We'll remind you before they're due. Skip if none.">
              <RecurringEditor rows={rows} onChange={setRows} errors={rowErrors} />
              {rows.length > 0 && <Total label="Fixed costs per month" value={sum(recurring.map((r) => r.amount))} />}
              {error && <p className="text-xs text-bad">{error}</p>}
            </Step>
          )}

          {step === 4 && (
            <Step title="What do you usually spend on food & travel?" sub="Per month, outside the fixed costs. Leave blank and we'll estimate.">
              <div className="grid grid-cols-2 gap-3">
                <Field label="Food & snacks">{(id) => <MoneyInput id={id} value={food} onChange={setFood} placeholder="e.g. 2500" />}</Field>
                <Field label="Travel">{(id) => <MoneyInput id={id} value={travel} onChange={setTravel} placeholder="e.g. 800" />}</Field>
              </div>
            </Step>
          )}

          {step === 5 && (
            <Step title="Have you already saved something?" sub="Money you've put aside and don't plan to spend.">
              <Field label="Current savings" hint="This is counted in your balance too — it's still your money.">
                {(id) => <MoneyInput id={id} value={savings} onChange={setSavings} placeholder="0" />}
              </Field>
              <div>
                <p className="mb-1.5 text-xs font-medium text-ink-2">Emergency fund target</p>
                <div className="flex flex-wrap gap-1.5">
                  {EMERGENCY.map((v) => (
                    <Chip key={v} active={emergency === v} onClick={() => setEmergency(v)}>
                      ₹{Number(v).toLocaleString("en-IN")}
                    </Chip>
                  ))}
                  <Chip active={emergency === "custom"} onClick={() => setEmergency("custom")}>
                    Custom
                  </Chip>
                  <Chip active={emergency === "skip"} onClick={() => setEmergency("skip")}>
                    Skip
                  </Chip>
                </div>
                {emergency === "custom" && (
                  <div className="mt-2">
                    <MoneyInput aria-label="Custom emergency fund target" value={emergencyCustom} onChange={setEmergencyCustom} placeholder="Target amount" />
                  </div>
                )}
                <p className="mt-1.5 text-xs text-muted">A small cushion for surprises — medical bills, a broken phone, a late stipend.</p>
              </div>
              {error && <p className="text-xs text-bad">{error}</p>}
            </Step>
          )}

          {step === 6 && (
            <Step title="What are you saving for?" sub="Pick one to start — you can add more goals later.">
              <div className="flex flex-wrap gap-1.5">
                {GOAL_CHIPS.map((g) => (
                  <Chip
                    key={g.label}
                    active={goalCat === g.category}
                    onClick={() => {
                      setGoalCat(g.category);
                      if (!goalName.trim() || GOAL_CHIPS.some((x) => `New ${x.label}` === goalName)) setGoalName(g.category === "Custom" ? "" : `New ${g.label}`);
                    }}
                  >
                    {g.label}
                  </Chip>
                ))}
                <Chip active={goalCat === null} onClick={() => setGoalCat(null)}>
                  Skip for now
                </Chip>
              </div>
              {goalCat && (
                <div className="space-y-3">
                  <Field label="Goal name">{(id) => <Input id={id} value={goalName} onChange={(e) => setGoalName(e.target.value)} placeholder="e.g. MacBook Air" maxLength={80} />}</Field>
                  <div className="grid grid-cols-2 gap-3">
                    <Field label="Price">{(id) => <MoneyInput id={id} value={goalPrice} onChange={setGoalPrice} placeholder="0" />}</Field>
                    <Field label="Target date (optional)">{(id) => <Input id={id} type="date" min={today} value={goalDate} onChange={(e) => setGoalDate(e.target.value)} />}</Field>
                  </div>
                </div>
              )}
              {error && <p className="text-xs text-bad">{error}</p>}
            </Step>
          )}

          {step === 7 && (
            <Step title={`Looking good${firstName ? `, ${firstName}` : ""}!`} sub="Here's your starting point. Everything can be edited later.">
              <dl className="divide-y divide-line rounded-2xl bg-surface-2 px-4 text-sm">
                <Row label="Starting balance">
                  <Money value={(toNum(wallet) ?? 0) + (toNum(bank) ?? 0) + (toNum(savings) ?? 0)} />
                </Row>
                <Row label="Monthly income">
                  <Money value={incomeNum} /> <span className="text-xs text-muted">· {source}</span>
                </Row>
                <Row label="Fixed costs">{recurring.length ? <><Money value={sum(recurring.map((r) => r.amount))} /> <span className="text-xs text-muted">· {recurring.length} reminder{recurring.length === 1 ? "" : "s"}</span></> : <span className="text-muted">None</span>}</Row>
                <Row label="Emergency fund">{emergencyTarget ? <Money value={emergencyTarget} /> : <span className="text-muted">Skipped</span>}</Row>
                <Row label="Goal">{goalCat ? <>{goalName} · <Money value={toNum(goalPrice)} /></> : <span className="text-muted">Skipped</span>}</Row>
              </dl>

              <div>
                <div className="mb-2 flex items-center justify-between gap-2">
                  <p className="flex items-center gap-1.5 text-sm font-semibold">
                    <Sparkles className="size-4 text-brand" /> Your first monthly budget
                  </p>
                  <SourceTag kind="calculated" />
                </div>
                {budget.length ? (
                  <>
                    <ul className="space-y-1.5 text-sm">
                      {budget.map((b) => (
                        <li key={b.category} className={cn("flex justify-between gap-2", b.category === SAVINGS_BUDGET && "mt-2 border-t border-line pt-2 font-medium text-good")}>
                          <span>{b.category === SAVINGS_BUDGET ? "Savings target" : b.category}</span>
                          <Money value={b.amount} />
                        </li>
                      ))}
                    </ul>
                    <p className="mt-2 text-xs text-muted">Built from your answers: fixed costs as entered, your food & travel numbers, small defaults for the rest, and whatever&apos;s left goes to savings.</p>
                  </>
                ) : (
                  <p className="text-sm text-muted">Add a monthly income to get a suggested budget. You can create one later from the Budget page.</p>
                )}
              </div>
            </Step>
          )}

          <div className="mt-6 flex items-center justify-between gap-2">
            {step > 0 ? (
              <Button variant="ghost" onClick={back} disabled={saving}>
                <ArrowLeft className="size-4" /> Back
              </Button>
            ) : (
              <span />
            )}
            {last ? (
              <Button onClick={submit} loading={saving} size="lg">
                <Check className="size-4" /> Finish setup
              </Button>
            ) : (
              <Button onClick={next} size="lg">
                {step === 3 && rows.length === 0 ? "Skip" : step === 6 && !goalCat ? "Skip" : "Next"} <ArrowRight className="size-4" />
              </Button>
            )}
          </div>
        </div>
        <p className="mt-4 text-center text-xs text-muted">Your answers stay private and only power your own numbers.</p>
      </div>
    </div>
  );
}

function Step({ title, sub, children }: { title: string; sub?: string; children: ReactNode }) {
  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-xl font-semibold tracking-tight">{title}</h1>
        {sub && <p className="mt-1 text-sm text-muted">{sub}</p>}
      </div>
      {children}
    </div>
  );
}

function Total({ label, value }: { label: string; value: number }) {
  return (
    <div className="flex items-center justify-between rounded-xl bg-surface-2 px-3 py-2 text-sm">
      <span className="text-ink-2">{label}</span>
      <Money value={value} className="font-semibold" />
    </div>
  );
}

function Row({ label, children }: { label: string; children: ReactNode }) {
  return (
    <div className="flex items-center justify-between gap-3 py-2.5">
      <dt className="text-ink-2">{label}</dt>
      <dd className="text-right">{children}</dd>
    </div>
  );
}

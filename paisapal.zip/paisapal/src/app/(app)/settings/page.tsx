"use client";
import { Bell, ChevronRight, KeyRound, LogOut } from "lucide-react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { CategoriesCard } from "@/components/manage/SettingsCategories";
import { DangerCard, DataCard } from "@/components/manage/SettingsData";
import { PreferencesCard, ProfileCard } from "@/components/manage/SettingsProfile";
import { errMsg } from "@/components/manage/shared";
import { Button, Card, CardTitle, ErrorState, PageHeader, PageSkeleton, useToast } from "@/components/ui";
import { useFinance } from "@/lib/client/useFinance";
import { supabaseBrowser } from "@/lib/supabase/client";

export default function SettingsPage() {
  const { data, error, refresh } = useFinance();
  if (!data) return error ? <ErrorState error={error} retry={() => refresh()} /> : <PageSkeleton />;
  const { s, today } = data;
  const demoCount = s.transactions.filter((t) => t.is_demo).length;
  return (
    <div className="space-y-4">
      <PageHeader title="Settings" subtitle="Your profile, preferences and data." />
      <ProfileCard key={`${s.profile.name}|${s.profile.opening_balance}|${s.profile.monthly_income_estimate}|${s.profile.daily_limit}`} profile={s.profile} />
      <div className="grid gap-4 lg:grid-cols-2">
        <PreferencesCard profile={s.profile} />
        <Card>
          <CardTitle>Notifications</CardTitle>
          <Link href="/alerts" className="-mx-2 flex items-center gap-3 rounded-xl px-2 py-2 hover:bg-surface-2">
            <Bell className="size-4 text-brand" />
            <span className="flex-1 text-sm">
              Alert settings
              <span className="block text-xs text-muted">Choose which alerts you get and set thresholds</span>
            </span>
            <ChevronRight className="size-4 text-muted" />
          </Link>
        </Card>
      </div>
      <CategoriesCard custom={s.categories} />
      <DataCard today={today} demoCount={demoCount} />
      <AccountCard />
      <DangerCard />
    </div>
  );
}

function AccountCard() {
  const router = useRouter();
  const toast = useToast();
  const [busy, setBusy] = useState(false);
  async function logout() {
    setBusy(true);
    try {
      await supabaseBrowser().auth.signOut();
      router.replace("/login");
      router.refresh();
    } catch (e) {
      toast(errMsg(e), "bad");
      setBusy(false);
    }
  }
  return (
    <Card>
      <CardTitle>Account</CardTitle>
      <div className="flex flex-wrap gap-2">
        <Link href="/auth/update-password" className="inline-flex h-10 items-center gap-1.5 rounded-xl border border-line bg-surface px-4 text-sm font-medium hover:bg-surface-2">
          <KeyRound className="size-4" /> Change password
        </Link>
        <Button variant="ghost" onClick={logout} loading={busy}>
          <LogOut className="size-4" /> Log out
        </Button>
      </div>
    </Card>
  );
}

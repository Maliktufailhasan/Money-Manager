"use client";
import { AlertOctagon, AlertTriangle, BellRing, ChevronRight, Info, PartyPopper } from "lucide-react";
import Link from "next/link";
import { AlertSettings } from "@/components/analysis/AlertSettings";
import { Card, CardTitle, EmptyState, ErrorState, PageHeader, PageSkeleton, cn } from "@/components/ui";
import type { Alert } from "@/lib/finance";
import { useFinance } from "@/lib/client/useFinance";

const LEVELS = [
  { level: "danger", title: "Needs attention now", icon: AlertOctagon, cls: "bg-bad-soft text-bad" },
  { level: "warning", title: "Heads-up", icon: AlertTriangle, cls: "bg-warn-soft text-warn" },
  { level: "info", title: "For your information", icon: Info, cls: "bg-brand-soft text-brand" },
] as const;

export default function AlertsPage() {
  const { data, error, refresh } = useFinance();
  if (!data) return error ? <ErrorState error={error} retry={refresh} /> : <PageSkeleton />;
  const { alerts } = data;

  return (
    <>
      <PageHeader title="Smart alerts" subtitle="Calculated from your recorded transactions, budgets, bills and goals." />

      {alerts.length === 0 ? (
        <EmptyState icon={<PartyPopper className="size-8" />} title="All clear">
          No alerts right now. We&apos;ll flag budgets close to their limit, upcoming bills, unusual spending and more.
        </EmptyState>
      ) : (
        <div className="space-y-5">
          {LEVELS.map(({ level, title, icon: Icon, cls }) => {
            const list = alerts.filter((a) => a.level === level);
            if (!list.length) return null;
            return (
              <section key={level} aria-label={title}>
                <h2 className="mb-2 flex items-center gap-2 text-sm font-semibold">
                  <Icon className="size-4" aria-hidden /> {title} <span className="text-muted">({list.length})</span>
                </h2>
                <ul className="space-y-2">
                  {list.map((a) => (
                    <AlertRow key={a.id} alert={a} icon={<Icon className="size-4" aria-hidden />} cls={cls} />
                  ))}
                </ul>
              </section>
            );
          })}
        </div>
      )}

      <Card className="mt-8">
        <CardTitle hint="Choose which alerts you want to see. Changes save instantly.">
          <span className="flex items-center gap-2">
            <BellRing className="size-4" /> Notification settings
          </span>
        </CardTitle>
        <AlertSettings profile={data.s.profile} />
      </Card>
    </>
  );
}

function AlertRow({ alert, icon, cls }: { alert: Alert; icon: React.ReactNode; cls: string }) {
  const body = (
    <>
      <span className={cn("mt-0.5 flex size-7 shrink-0 items-center justify-center rounded-lg", cls)}>{icon}</span>
      <span className="min-w-0 flex-1 text-sm">{alert.text}</span>
      {alert.href && <ChevronRight className="mt-1 size-4 shrink-0 text-muted" aria-hidden />}
    </>
  );
  const base = "flex items-start gap-3 rounded-2xl border border-line bg-surface p-3";
  return (
    <li>
      {alert.href ? (
        <Link href={alert.href} className={cn(base, "transition-colors hover:bg-surface-2")}>
          {body}
        </Link>
      ) : (
        <div className={base}>{body}</div>
      )}
    </li>
  );
}

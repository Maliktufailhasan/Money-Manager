"use client";
import { AlertTriangle, BellRing, Check, Pencil, Plus, Repeat, SkipForward, Trash2 } from "lucide-react";
import Link from "next/link";
import { useMemo, useState } from "react";
import { KIND_CATEGORY, RECUR_LABEL, ReminderModal, type ReminderDraft } from "@/components/manage/ReminderModal";
import { DueBadge, Figure, RowMenu, errMsg } from "@/components/manage/shared";
import {
  Badge, Button, Card, CardTitle, EmptyState, ErrorState, Money, PageHeader, PageSkeleton, SourceTag, cn, confirmAction, useToast,
} from "@/components/ui";
import { db, payItem } from "@/lib/client/api";
import { useFinance, type FinanceData } from "@/lib/client/useFinance";
import {
  addDays, advance, diffDays, fmtDate, monthEnd, monthlyFactor, recurringMonthlyBurden, round2, subscriptionMonthlyCost, sum, totalDue, upcomingPayments, type UpcomingPayment,
} from "@/lib/finance";
import type { Reminder, ReminderRecurrence, Transaction } from "@/lib/types";

export default function BillsPage() {
  const { data, error, refresh } = useFinance();
  if (!data) return error ? <ErrorState error={error} retry={() => refresh()} /> : <PageSkeleton />;
  return <Bills data={data} />;
}

function whenLabel(p: UpcomingPayment) {
  if (p.daysAway < 0) return "Overdue";
  if (p.daysAway === 0) return "Today";
  if (p.daysAway === 1) return "Tomorrow";
  return fmtDate(p.date);
}

function Bills({ data }: { data: FinanceData }) {
  const { s, today } = data;
  const toast = useToast();
  const [modal, setModal] = useState<{ reminder: Reminder | null; draft?: ReminderDraft; n: number } | null>(null);
  const [busy, setBusy] = useState<string | null>(null);

  const upcoming = useMemo(() => upcomingPayments(s, today, addDays(today, 30)), [s, today]);
  const dueThisMonth = useMemo(() => totalDue(upcomingPayments(s, today, monthEnd(today))), [s, today]);
  const overdue = upcoming.filter((p) => p.daysAway < 0);
  const remById = new Map(s.reminders.map((r) => [r.id, r]));

  const recurringRems = s.reminders.filter((r) => r.recurring !== "none" && !r.completed);
  const remMonthly = sum(recurringRems.map((r) => round2(r.amount * monthlyFactor(r.recurring))));
  const subMonthly = sum(s.subscriptions.map(subscriptionMonthlyCost));
  const burden = recurringMonthlyBurden(s);

  const openRems = [...s.reminders].filter((r) => !r.completed).sort((a, b) => a.due_date.localeCompare(b.due_date));
  const doneRems = s.reminders.filter((r) => r.completed);

  async function run(key: string, fn: () => Promise<unknown>, ok: string) {
    setBusy(key);
    try {
      await fn();
      toast(ok);
    } catch (e) {
      toast(errMsg(e), "bad");
    } finally {
      setBusy(null);
    }
  }
  const pay = (src: "reminder" | "subscription", id: string, title: string) => run(`p-${id}`, () => payItem(src, id), `${title} paid — expense recorded`);
  const skip = (src: "reminder" | "subscription", id: string) => run(`s-${id}`, () => payItem(src, id, "skip"), "Skipped this one");
  const remove = (r: Reminder) => confirmAction(`Delete the reminder "${r.title}"?`) && run(`d-${r.id}`, () => db.remove("reminders", r.id), "Reminder deleted");
  const add = () => setModal({ reminder: null, n: Date.now() });

  const seen = new Set<string>();

  return (
    <div className="space-y-4">
      <PageHeader
        title="Bills & recurring"
        subtitle="Rent, hostel, recharges and every regular payment — never miss a due date."
        actions={
          <Button onClick={add}>
            <Plus className="size-4" /> Add reminder
          </Button>
        }
      />

      <div className="grid grid-cols-2 gap-3 lg:grid-cols-3">
        <Card className="p-4">
          <Figure label="Still due this month" hint="Bills + subscriptions">
            <Money value={dueThisMonth} />
          </Figure>
        </Card>
        <Card className="p-4">
          <Figure label="Recurring per month" hint="Monthly equivalent">
            <Money value={burden} />
          </Figure>
        </Card>
        <div className={cn("col-span-2 rounded-2xl border p-4 lg:col-span-1", overdue.length ? "border-bad/40 bg-bad-soft" : "border-line bg-surface")}>
          <Figure label="Overdue" hint={overdue.length ? `${overdue.length} payment${overdue.length === 1 ? "" : "s"} past due` : "All caught up"}>
            <Money value={totalDue(overdue)} className={overdue.length ? "text-bad" : ""} />
          </Figure>
        </div>
      </div>

      <Card>
        <CardTitle hint="Next 30 days · bills and subscriptions">
          <span className="flex items-center gap-1.5">
            <BellRing className="size-4 text-brand" /> Upcoming
          </span>
        </CardTitle>
        {upcoming.length === 0 ? (
          <EmptyState
            title="Nothing due in the next 30 days"
            action={
              <Button variant="soft" size="sm" onClick={add}>
                <Plus className="size-3.5" /> Add a bill
              </Button>
            }
          >
            Add rent, hostel fees, internet or recharges so they&apos;re counted in your safe-to-spend.
          </EmptyState>
        ) : (
          <ul className="divide-y divide-line">
            {upcoming.map((p) => {
              const first = !seen.has(p.refId);
              seen.add(p.refId);
              const rem = p.source === "reminder" ? remById.get(p.refId) : undefined;
              return (
                <li key={p.key} className={cn("flex items-center gap-3 py-2.5", p.daysAway < 0 && "-mx-2 rounded-xl bg-bad-soft px-2")}>
                  <div className={cn("w-20 shrink-0 text-xs font-medium", p.daysAway < 0 ? "text-bad" : p.daysAway <= 1 ? "text-warn" : "text-ink-2")}>
                    {p.daysAway < 0 && <AlertTriangle className="mr-1 inline size-3" />}
                    {whenLabel(p)}
                    {p.daysAway < 0 && <span className="block font-normal text-muted">{fmtDate(p.date)}</span>}
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm">
                      {p.title} <Money value={p.amount} className="font-semibold" />
                    </p>
                    <p className="text-xs text-muted">
                      {p.kind} · {p.category}
                    </p>
                  </div>
                  {first && (
                    <div className="flex shrink-0 items-center gap-1">
                      <Button size="sm" variant="soft" loading={busy === `p-${p.refId}`} onClick={() => pay(p.source, p.refId, p.title)}>
                        <Check className="size-3.5" /> Paid
                      </Button>
                      <RowMenu
                        items={[
                          { label: "Skip", icon: <SkipForward className="size-3.5" />, onClick: () => skip(p.source, p.refId) },
                          ...(rem
                            ? [
                                { label: "Edit", icon: <Pencil className="size-3.5" />, onClick: () => setModal({ reminder: rem, n: Date.now() }) },
                                { label: "Delete", icon: <Trash2 className="size-3.5" />, onClick: () => remove(rem), danger: true },
                              ]
                            : []),
                        ]}
                      />
                    </div>
                  )}
                </li>
              );
            })}
          </ul>
        )}
        {upcoming.some((p) => p.source === "subscription") && (
          <p className="mt-3 text-xs text-muted">
            Manage subscriptions on the{" "}
            <Link href="/subscriptions" className="text-brand underline-offset-2 hover:underline">
              Subscriptions
            </Link>{" "}
            page.
          </p>
        )}
      </Card>

      <div className="grid gap-4 lg:grid-cols-2">
        <Card>
          <CardTitle hint="Monthly-equivalent cost of each recurring bill">
            <span className="flex items-center gap-1.5">
              <Repeat className="size-4 text-brand" /> Recurring expenses
            </span>
          </CardTitle>
          {recurringRems.length === 0 && subMonthly === 0 ? (
            <p className="py-6 text-center text-sm text-muted">No recurring bills yet. Set a reminder to repeat weekly, monthly, quarterly or yearly.</p>
          ) : (
            <>
              <ul className="space-y-2 text-sm">
                {recurringRems.map((r) => (
                  <li key={r.id} className="flex items-center justify-between gap-2">
                    <span className="min-w-0">
                      <span className="block truncate">{r.title}</span>
                      <span className="text-xs text-muted">
                        <Money value={r.amount} /> {RECUR_LABEL[r.recurring].toLowerCase()}
                      </span>
                    </span>
                    <span className="shrink-0 tabular">
                      <Money value={r.amount * monthlyFactor(r.recurring)} />
                      <span className="text-xs text-muted">/mo</span>
                    </span>
                  </li>
                ))}
                {subMonthly > 0 && (
                  <li className="flex items-center justify-between gap-2">
                    <Link href="/subscriptions" className="text-brand hover:underline">
                      Subscriptions (all active)
                    </Link>
                    <span className="shrink-0 tabular">
                      <Money value={subMonthly} />
                      <span className="text-xs text-muted">/mo</span>
                    </span>
                  </li>
                )}
              </ul>
              <div className="mt-3 flex items-center justify-between rounded-xl bg-surface-2 px-3 py-2.5 text-sm">
                <span className="font-medium">Total recurring burden</span>
                <span className="flex items-center gap-2">
                  <SourceTag kind="calculated" />
                  <Money value={burden} className="font-semibold" />
                  <span className="text-xs text-muted">/mo</span>
                </span>
              </div>
              <p className="mt-2 text-xs text-muted">
                Bills <Money value={remMonthly} /> + subscriptions <Money value={subMonthly} />. These are already set aside in your safe-to-spend and used in budget planning.
              </p>
            </>
          )}
        </Card>

        <RecordedRecurring txs={s.transactions} reminders={s.reminders} subNames={s.subscriptions.map((x) => x.name)} today={today} onCreate={(draft) => setModal({ reminder: null, draft, n: Date.now() })} />
      </div>

      <Card>
        <CardTitle hint={`${openRems.length} open${doneRems.length ? ` · ${doneRems.length} completed` : ""}`}>All reminders</CardTitle>
        {openRems.length === 0 ? (
          <p className="py-6 text-center text-sm text-muted">No open reminders.</p>
        ) : (
          <ul className="divide-y divide-line">
            {openRems.map((r) => (
              <li key={r.id} className="flex items-center gap-3 py-2.5">
                <div className="min-w-0 flex-1">
                  <div className="flex flex-wrap items-center gap-1.5">
                    <span className="truncate text-sm font-medium">{r.title}</span>
                    <Badge>{r.kind}</Badge>
                    {r.recurring !== "none" && <Badge tone="brand">{RECUR_LABEL[r.recurring]}</Badge>}
                  </div>
                  <p className="mt-0.5 flex flex-wrap items-center gap-1.5 text-xs text-muted">
                    <Money value={r.amount} className="text-ink" /> · due {fmtDate(r.due_date, { year: true })} · {r.category}
                    <DueBadge daysAway={diffDays(r.due_date, today)} />
                  </p>
                </div>
                <RowMenu
                  items={[
                    { label: "Mark paid", icon: <Check className="size-3.5" />, onClick: () => pay("reminder", r.id, r.title) },
                    { label: "Skip", icon: <SkipForward className="size-3.5" />, onClick: () => skip("reminder", r.id) },
                    { label: "Edit", icon: <Pencil className="size-3.5" />, onClick: () => setModal({ reminder: r, n: Date.now() }) },
                    { label: "Delete", icon: <Trash2 className="size-3.5" />, onClick: () => remove(r), danger: true },
                  ]}
                />
              </li>
            ))}
          </ul>
        )}
        {doneRems.length > 0 && (
          <details className="mt-3 text-sm">
            <summary className="cursor-pointer text-xs font-medium text-muted">Completed one-time reminders</summary>
            <ul className="mt-2 space-y-1.5">
              {doneRems.map((r) => (
                <li key={r.id} className="flex items-center justify-between gap-2 text-ink-2">
                  <span className="truncate line-through">{r.title}</span>
                  <span className="flex shrink-0 items-center gap-1">
                    <Money value={r.amount} />
                    <Button size="sm" variant="ghost" onClick={() => remove(r)} aria-label={`Delete ${r.title}`}>
                      <Trash2 className="size-3.5" />
                    </Button>
                  </span>
                </li>
              ))}
            </ul>
          </details>
        )}
      </Card>

      {modal && <ReminderModal key={modal.n} open onClose={() => setModal(null)} reminder={modal.reminder} draft={modal.draft} today={today} custom={s.categories} />}
    </div>
  );
}

const TX_TO_REMINDER: Record<string, ReminderRecurrence> = { weekly: "weekly", monthly: "monthly", yearly: "yearly" };

function RecordedRecurring({ txs, reminders, subNames, today, onCreate }: { txs: Transaction[]; reminders: Reminder[]; subNames: string[]; today: string; onCreate: (d: ReminderDraft) => void }) {
  const items = useMemo(() => {
    const since = addDays(today, -60);
    const latest = new Map<string, Transaction>();
    for (const t of txs) {
      if (t.type !== "expense" || !t.recurring || t.date < since || t.date > today) continue;
      const key = `${(t.description || t.merchant || t.subcategory || t.category).toLowerCase()}|${t.category}`;
      const cur = latest.get(key);
      if (!cur || t.date > cur.date) latest.set(key, t);
    }
    return [...latest.values()].sort((a, b) => b.date.localeCompare(a.date));
  }, [txs, today]);
  const scheduled = new Set([...reminders.filter((r) => !r.completed).map((r) => r.title.toLowerCase()), ...subNames.map((n) => n.toLowerCase())]);

  function draftFor(t: Transaction): ReminderDraft {
    const cycle: ReminderRecurrence = (t.recurrence && TX_TO_REMINDER[t.recurrence]) || "monthly";
    let due = advance(t.date, cycle);
    let guard = 0;
    while (due < today && guard++ < 100) due = advance(due, cycle);
    const kind = Object.entries(KIND_CATEGORY).find(([k]) => k.toLowerCase() === (t.subcategory ?? "").toLowerCase())?.[0] ?? "Bill";
    return { title: t.description || t.merchant || t.subcategory || t.category, amount: t.amount, due_date: due, recurring: cycle, kind, category: t.category };
  }

  return (
    <Card>
      <CardTitle hint="Expenses you marked as recurring in the last 60 days">Recorded recurring payments</CardTitle>
      {items.length === 0 ? (
        <p className="py-6 text-center text-sm text-muted">None yet. Tick &ldquo;Recurring&rdquo; when you add an expense and it will show up here.</p>
      ) : (
        <ul className="divide-y divide-line">
          {items.map((t) => {
            const d = draftFor(t);
            const done = scheduled.has((d.title ?? "").toLowerCase());
            return (
              <li key={t.id} className="flex items-center gap-3 py-2.5">
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm">{d.title}</p>
                  <p className="text-xs text-muted">
                    <Money value={t.amount} /> · last on {fmtDate(t.date)} · {t.recurrence ?? "repeats"}
                  </p>
                </div>
                {done ? (
                  <Badge tone="good">
                    <Check className="size-3" /> Scheduled
                  </Badge>
                ) : (
                  <Button size="sm" variant="secondary" onClick={() => onCreate(d)}>
                    <Plus className="size-3.5" /> Create reminder
                  </Button>
                )}
              </li>
            );
          })}
        </ul>
      )}
    </Card>
  );
}

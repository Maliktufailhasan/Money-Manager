"use client";
import { Info } from "lucide-react";
import Link from "next/link";
import { useMemo, useState } from "react";
import { BarsChart, COLORS, ChartBox, Donut, RankBars, categoryColor } from "@/components/charts";
import { sourceColorFor } from "@/components/home/DashboardCharts";
import { Delta, PeriodSwitcher, TxAmount, txTitle } from "@/components/home/shared";
import { Card, CardTitle, EmptyState, ErrorState, Money, PageHeader, PageSkeleton, Stat } from "@/components/ui";
import { incomeSources } from "@/lib/client/categories";
import { useFinance } from "@/lib/client/useFinance";
import { addMonths, dailySeries, fmtDate, fmtMonth, formatINR, formatPct, monthEnd, monthStart, monthlyReport, ym } from "@/lib/finance";

export default function MonthlyPage() {
  const { data, error, refresh } = useFinance();
  const [picked, setPicked] = useState<string | null>(null); // month start, yyyy-MM-01
  const cur = data ? monthStart(data.today) : "";
  const month = picked && picked <= cur ? picked : cur;
  const report = useMemo(() => {
    if (!data) return null;
    const { year, month: m } = ym(month);
    const r = monthlyReport(data.s, year, m, data.today);
    const to = monthEnd(month) < data.today ? monthEnd(month) : data.today;
    const daily = month <= data.today ? dailySeries(data.s.transactions, month, to).map((p) => ({ ...p })) : [];
    return { r, daily };
  }, [data, month]);

  if (!data || !report) return error ? <ErrorState error={error} retry={refresh} /> : <PageSkeleton />;

  const { s } = data;
  const { r, daily } = report;
  const { summary: sm, previous: pv } = r;
  const windowMonth = monthStart(s.windowStart);
  const atWindowStart = month <= windowMonth;
  const partialWindow = month < s.windowStart; // window starts mid-month
  const isCurrent = month === cur;
  const empty = sm.expenseCount === 0 && sm.incomeCount === 0 && sm.refunds === 0;
  const sourceColor = sourceColorFor(incomeSources(s.categories));
  const { year, month: m } = ym(month);
  const prevMonth = addMonths(month, -1);

  return (
    <div className="space-y-4">
      <PageHeader
        title="Monthly summary"
        subtitle={isCurrent ? `${r.label} · so far` : r.label}
        actions={<PeriodSwitcher label={fmtMonth(year, m, false)} onPrev={() => setPicked(addMonths(month, -1))} onNext={() => setPicked(addMonths(month, 1))} prevDisabled={atWindowStart} nextDisabled={isCurrent} />}
      />

      {(atWindowStart || partialWindow) && (
        <p className="flex items-start gap-2 rounded-xl bg-surface-2 px-3 py-2 text-xs text-ink-2">
          <Info className="mt-0.5 size-3.5 shrink-0" />
          <span>
            Monthly summaries cover your recent history from {fmtDate(s.windowStart, { year: true })} onwards
            {partialWindow ? `, so ${fmtMonth(year, m)} may be incomplete` : ""}. Older entries are still in{" "}
            <Link href="/transactions" className="text-brand hover:underline">
              Transactions
            </Link>
            .
          </span>
        </p>
      )}

      {empty ? (
        <EmptyState title={`Nothing recorded in ${r.label}`}>{isCurrent ? "Add your income and expenses as they happen and this page builds itself." : "Try another month."}</EmptyState>
      ) : (
        <>
          <div className="grid grid-cols-2 gap-3 sm:gap-4 lg:grid-cols-4">
            <Stat label="Received" value={<Money value={sm.received} />} sub={<Delta now={sm.received} before={pv.received} higherIsGood />} />
            <Stat label="Spent" value={<Money value={sm.spent} />} sub={<Delta now={sm.spent} before={pv.spent} higherIsGood={false} />} />
            <Stat label="Saved" value={<Money value={sm.saved} />} tone={sm.saved < 0 ? "bad" : sm.saved > 0 ? "good" : undefined} sub={<Delta now={sm.saved} before={pv.saved} higherIsGood />} />
            <Stat
              label="Savings rate"
              value={formatPct(sm.savingsRate, 0)}
              tone={sm.savingsRate === null ? undefined : sm.savingsRate >= 20 ? "good" : sm.savingsRate < 0 ? "bad" : "warn"}
              sub={pv.savingsRate !== null ? `Last month ${formatPct(pv.savingsRate, 0)}` : "Share of income kept"}
            />
            <Stat label="Highest category" value={r.highest ? r.highest.name : "—"} sub={r.highest ? formatINR(r.highest.amount) : "No expenses"} className="col-span-1" />
            <Stat label="Lowest category" value={r.lowest ? r.lowest.name : "—"} sub={r.lowest ? formatINR(r.lowest.amount) : "Needs 2+ categories"} />
            <Stat label="Needs" value={<Money value={sm.needs} />} sub={sm.grossSpent ? `${Math.round((sm.needs / sm.grossSpent) * 100)}% of spending` : undefined} />
            <Stat label="Wants" value={<Money value={sm.wants} />} tone={sm.wants > sm.needs && sm.wants > 0 ? "warn" : undefined} sub={sm.grossSpent ? `${Math.round((sm.wants / sm.grossSpent) * 100)}% of spending` : undefined} />
          </div>

          <div className="grid gap-4 lg:grid-cols-2">
            <ChartBox title="Spending by category" table={{ columns: ["Category", "Spent", "Share"], rows: sm.byCategory.map((c) => [c.name, c.amount, formatPct(c.share, 0)]) }}>
              <Donut data={sm.byCategory.map((c) => ({ name: c.name, value: c.amount }))} centerLabel={<><span className="text-xs text-muted">Spent</span><span className="text-sm font-semibold">{formatINR(sm.grossSpent)}</span></>} />
            </ChartBox>
            <Card>
              <CardTitle hint="Ranked, with change vs last month">Category ranking</CardTitle>
              <RankBars
                items={sm.byCategory.map((c) => {
                  const before = pv.byCategory.find((p) => p.name === c.name)?.amount ?? 0;
                  const diff = Math.round(c.amount - before);
                  return { name: c.name, value: c.amount, sub: before ? `${diff >= 0 ? "+" : "−"}${formatINR(Math.abs(diff))}` : "new" };
                })}
                colorFor={categoryColor}
              />
            </Card>

            <ChartBox title="Daily spending" hint={r.label} table={{ columns: ["Day", "Spent", "Received"], rows: daily.filter((p) => p.expense || p.income).map((p) => [p.label, p.expense, p.income]) }}>
              <BarsChart data={daily} xKey="label" series={[{ key: "expense", label: "Spent", color: COLORS.expense }]} height={200} />
            </ChartBox>

            <ChartBox title="Needs vs wants" hint="Based on how you tagged each expense" table={{ columns: ["Type", "Amount"], rows: [["Needs", sm.needs], ["Wants", sm.wants], ["Not tagged", sm.unclassified]] }}>
              <Donut
                height={160}
                data={[
                  { name: "Needs", value: sm.needs },
                  { name: "Wants", value: sm.wants },
                  { name: "Not tagged", value: sm.unclassified },
                ]}
                colorFor={(n) => (n === "Needs" ? COLORS.income : n === "Wants" ? COLORS.expense : "var(--muted)")}
              />
            </ChartBox>

            <Card>
              <CardTitle hint="Compared with the previous month">Month vs last month</CardTitle>
              <table className="w-full text-sm">
                <thead className="text-xs text-muted">
                  <tr>
                    <th className="py-1.5 text-left font-medium" />
                    <th className="py-1.5 text-right font-medium">{fmtMonth(ym(prevMonth).year, ym(prevMonth).month, false)}</th>
                    <th className="py-1.5 text-right font-medium">{fmtMonth(year, m, false)}</th>
                  </tr>
                </thead>
                <tbody className="tabular">
                  {([
                    ["Received", pv.received, sm.received, true],
                    ["Spent", pv.spent, sm.spent, false],
                    ["Saved", pv.saved, sm.saved, true],
                    ["Wants", pv.wants, sm.wants, false],
                  ] as const).map(([label, before, now, good]) => (
                    <tr key={label} className="border-t border-line">
                      <td className="py-2">{label}</td>
                      <td className="py-2 text-right text-muted">{formatINR(before)}</td>
                      <td className="py-2 text-right">
                        <div>{formatINR(now)}</div>
                        <Delta now={now} before={before} higherIsGood={good} />
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </Card>

            <ChartBox title="Income sources" table={{ columns: ["Source", "Received"], rows: sm.bySource.map((b) => [b.name, b.amount]) }}>
              {sm.bySource.length ? <RankBars items={sm.bySource.map((b) => ({ name: b.name, value: b.amount }))} colorFor={sourceColor} /> : <p className="py-6 text-center text-sm text-muted">No income recorded this month.</p>}
            </ChartBox>

            <Card className="lg:col-span-2">
              <CardTitle hint="Top 5 expenses">Largest transactions</CardTitle>
              {sm.largestExpenses.length === 0 ? (
                <p className="py-4 text-center text-sm text-muted">No expenses this month.</p>
              ) : (
                <ul className="divide-y divide-line">
                  {sm.largestExpenses.map((t) => (
                    <li key={t.id} className="flex items-center justify-between gap-3 py-2">
                      <div className="min-w-0">
                        <p className="truncate text-sm font-medium">{txTitle(t)}</p>
                        <p className="text-xs text-muted">
                          {fmtDate(t.date)} · {t.category}
                          {t.need_or_want ? ` · ${t.need_or_want}` : ""}
                        </p>
                      </div>
                      <TxAmount tx={t} className="text-sm" />
                    </li>
                  ))}
                </ul>
              )}
            </Card>
          </div>
        </>
      )}
    </div>
  );
}

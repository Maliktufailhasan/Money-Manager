"use client";
import { LogOut } from "lucide-react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { NAV } from "@/components/nav";
import { ThemeToggle } from "@/components/ThemeToggle";
import { Button, Card, PageHeader, useToast } from "@/components/ui";
import { useFinance } from "@/lib/client/useFinance";
import { supabaseBrowser } from "@/lib/supabase/client";

export default function MorePage() {
  const router = useRouter();
  const toast = useToast();
  const { data } = useFinance();
  const [leaving, setLeaving] = useState(false);
  const alertCount = data?.alerts.filter((a) => a.level !== "info").length ?? 0;

  async function signOut() {
    setLeaving(true);
    try {
      await supabaseBrowser().auth.signOut();
      router.replace("/login");
      router.refresh();
    } catch (e) {
      toast(e instanceof Error ? e.message : "Couldn't log out", "bad");
      setLeaving(false);
    }
  }

  return (
    <div className="space-y-5">
      <PageHeader title="More" subtitle={data?.s.profile.name ? `Signed in as ${data.s.profile.name}` : "All sections of PaisaPal"} />

      <nav aria-label="All sections" className="grid grid-cols-3 gap-2 sm:grid-cols-4 lg:grid-cols-6">
        {NAV.map(({ href, label, icon: Icon }) => (
          <Link key={href} href={href} className="relative flex flex-col items-center gap-1.5 rounded-2xl border border-line bg-surface px-2 py-4 text-center text-xs font-medium text-ink-2 transition-colors hover:bg-surface-2 hover:text-ink">
            <span className="flex size-9 items-center justify-center rounded-xl bg-brand-soft text-brand">
              <Icon className="size-4.5" />
            </span>
            <span className="leading-tight">{label}</span>
            {href === "/alerts" && alertCount > 0 && <span className="absolute top-2 right-2 rounded-full bg-bad px-1.5 text-[10px] font-semibold text-white">{alertCount}</span>}
          </Link>
        ))}
      </nav>

      <Card className="space-y-4">
        <div className="flex items-center justify-between gap-3">
          <div>
            <p className="text-sm font-medium">Appearance</p>
            <p className="text-xs text-muted">Light, system or dark</p>
          </div>
          <ThemeToggle />
        </div>
        <div className="border-t border-line pt-4">
          <Button variant="secondary" className="w-full" onClick={signOut} loading={leaving}>
            {!leaving && <LogOut className="size-4" />} Log out
          </Button>
        </div>
      </Card>
    </div>
  );
}

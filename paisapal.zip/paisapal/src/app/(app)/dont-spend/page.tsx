"use client";
import { ChevronDown, Pencil, Plus, ShieldBan, Trash2 } from "lucide-react";
import { useMemo, useState } from "react";
import { NoSpendModal, NO_SPEND_SUGGESTIONS } from "@/components/manage/NoSpendModal";
import { Figure, RowMenu, errMsg } from "@/components/manage/shared";
import {
  Badge, Button, Card, EmptyState, ErrorState, Money, PageHeader, PageSkeleton, Progress, SourceTag, cn, confirmAction, useToast,
} from "@/components/ui";
import { db } from "@/lib/client/api";
import { useFinance, type FinanceData } from "@/lib/client/useFinance";
import { fmtDate, formatINR, isExpense, ruleMatches, ruleProgress, sum, ymdMin, type RuleProgress } from "@/lib/finance";
import type { NoSpendRule, Transaction } from "@/lib/types";

export default function DontSpendPage() {
  const { data, error, refresh } = useFinance();
  if (!data) return error ? <ErrorState error={error} retry={() => refresh()} /> : <PageSkeleton />;
  return <DontSpend data={data} />;
}

const STATE_ORDER = { active: 0, upcoming: 1, ended: 2 } as const;

function DontSpend({ data }: { data: FinanceData }) {
  const { s, today } = data;
  const toast = useToast();
  const [modal, setModal] = useState<{ rule: NoSpendRule | null; n: number } | null>(null);

  const progress = useMemo(
    () =>
      s.noSpendRules
        .map((r) => ruleProgress(r, s.transactions, today))
        .sort((a, b) => Number(b.rule.active) - Number(a.rule.active) || STATE_ORDER[a.state] - STATE_ORDER[b.state] || a.rule.end_date.localeCompare(b.rule.end_date)),
    [s, today],
  );
  const counted = progress.filter((p) => p.rule.active);
  const totalSaved = sum(counted.map((p) => p.estimatedSaved));
  const activeCount = counted.filter((p) => p.state === "active").length;
  const brokenCount = counted.filter((p) => p.state === "active" && p.overLimit).length;

  async function remove(r: NoSpendRule) {
    if (!confirmAction(`Delete the rule "${r.title}"?`)) return;
    try {
      await db.remove("no-spend", r.id);
      toast("Rule deleted");
    } catch (e) {
      toast(errMsg(e), "bad");
    }
  }
  async function toggle(r: NoSpendRule) {
    try {
      await db.update("no-spend", r.id, { active: !r.active });
      toast(r.active ? "Rule paused" : "Rule turned on");
    } catch (e) {
      toast(errMsg(e), "bad");
    }
  }

  const add = () => setModal({ rule: null, n: Date.now() });

  return (
    <div className="space-y-4">
      <PageHeader
        title="Don't spend"
        subtitle="Pick habits to cut for a while — we'll track how you're doing and what it saves."
        actions={
          <Button onClick={add}>
            <Plus className="size-4" /> New rule
          </Button>
        }
      />

      {progress.length === 0 ? (
        <EmptyState
          icon={<ShieldBan className="size-8" />}
          title="No don't-spend rules yet"
          action={
            <Button onClick={add}>
              <Plus className="size-4" /> Create a rule
            </Button>
          }
        >
          Try a 30-day challenge like ❌ Food Delivery or ❌ Daily Café. You&apos;ll get a heads-up if an expense breaks the rule.
          <div className="mt-3 flex flex-wrap justify-center gap-1.5">
            {NO_SPEND_SUGGESTIONS.slice(0, 3).map((x) => (
              <Badge key={x.title}>❌ {x.title}</Badge>
            ))}
          </div>
        </EmptyState>
      ) : (
        <>
          <section className="rounded-2xl border border-good/30 bg-good-soft p-4 sm:p-5">
            <div className="flex flex-wrap items-end justify-between gap-4">
              <div>
                <div className="flex items-center gap-2">
                  <p className="text-xs font-medium text-muted">Saved by avoiding</p>
                  <SourceTag kind="estimate" />
                </div>
                <p className="mt-1 text-3xl font-semibold tracking-tight text-good">
                  <Money value={totalSaved} />
                </p>
                <p className="mt-0.5 text-xs text-muted">Typical spend for the days so far minus what you actually spent, across rules that are on.</p>
              </div>
              <div className="flex gap-6">
                <Figure label="Active now">{activeCount}</Figure>
                <Figure label="Over limit">
                  <span className={brokenCount ? "text-bad" : ""}>{brokenCount}</span>
                </Figure>
              </div>
            </div>
          </section>

          <div className="grid gap-3 lg:grid-cols-2">
            {progress.map((p) => (
              <RuleCard key={p.rule.id} p={p} txs={s.transactions} today={today} onEdit={() => setModal({ rule: p.rule, n: Date.now() })} onDelete={() => remove(p.rule)} onToggle={() => toggle(p.rule)} />
            ))}
          </div>
        </>
      )}

      {modal && <NoSpendModal key={modal.n} open onClose={() => setModal(null)} rule={modal.rule} today={today} custom={s.categories} />}
    </div>
  );
}

function RuleCard({ p, txs, today, onEdit, onDelete, onToggle }: { p: RuleProgress; txs: Transaction[]; today: string; onEdit: () => void; onDelete: () => void; onToggle: () => void }) {
  const [open, setOpen] = useState(false);
  const r = p.rule;
  const matches = useMemo(
    () => (open ? txs.filter((t) => isExpense(t) && ruleMatches(r, t) && t.date >= r.start_date && t.date <= ymdMin(today, r.end_date)).sort((a, b) => b.date.localeCompare(a.date)) : []),
    [open, txs, r, today],
  );
  const stateBadge = !r.active ? <Badge>Off</Badge> : p.state === "active" ? <Badge tone="brand">Active</Badge> : p.state === "upcoming" ? <Badge>Starts {fmtDate(r.start_date)}</Badge> : <Badge>Ended</Badge>;
  const usedPct = r.limit_amount > 0 ? (p.spent / r.limit_amount) * 100 : p.spent > 0 ? 100 : 0;
  const tone = p.overLimit ? "bad" : usedPct >= 80 ? "warn" : "good";
  const basis =
    p.baselineSource === "entered"
      ? `Based on the ${formatINR(p.baselineMonthly)}/month typical spend you entered.`
      : p.baselineSource === "history"
        ? `Based on your spending here in the 60 days before the rule (≈${formatINR(p.baselineMonthly)}/month).`
        : "No spending history before this rule — add a typical monthly spend to estimate savings.";

  return (
    <Card className={cn(!r.active && "opacity-70")}>
      <div className="flex items-start justify-between gap-2">
        <div className="min-w-0">
          <div className="flex flex-wrap items-center gap-1.5">
            <h3 className="font-semibold">❌ {r.title}</h3>
            {stateBadge}
            {p.overLimit && p.state !== "upcoming" && <Badge tone="bad">Over limit</Badge>}
          </div>
          <p className="mt-0.5 text-xs text-muted">
            {r.category}
            {r.subcategory ? ` → ${r.subcategory}` : " (whole category)"} · {fmtDate(r.start_date)} – {fmtDate(r.end_date, { year: true })}
          </p>
        </div>
        <RowMenu
          items={[
            { label: "Edit", icon: <Pencil className="size-3.5" />, onClick: onEdit },
            { label: r.active ? "Turn off" : "Turn on", icon: <ShieldBan className="size-3.5" />, onClick: onToggle },
            { label: "Delete", icon: <Trash2 className="size-3.5" />, onClick: onDelete, danger: true },
          ]}
        />
      </div>

      <div className="mt-4 space-y-3">
        <div>
          <div className="mb-1 flex justify-between text-xs">
            <span className="text-ink-2">
              Spent <Money value={p.spent} className="font-medium text-ink" /> of {r.limit_amount > 0 ? <Money value={r.limit_amount} /> : "₹0 (avoid completely)"}
            </span>
            <span className="text-muted">{p.matches} purchase{p.matches === 1 ? "" : "s"}</span>
          </div>
          <Progress value={usedPct} tone={tone} label="Spent vs limit" />
        </div>
        <div>
          <div className="mb-1 flex justify-between text-xs text-ink-2">
            <span>
              Day {p.daysElapsed} of {p.daysTotal}
            </span>
            <span className="text-muted">{p.state === "active" ? `${p.daysTotal - p.daysElapsed} days to go` : p.state === "upcoming" ? "Not started" : "Done"}</span>
          </div>
          <Progress value={(p.daysElapsed / p.daysTotal) * 100} tone="brand" label="Days elapsed" />
        </div>
        <div className="flex items-start justify-between gap-3 rounded-xl bg-surface-2 px-3 py-2.5">
          <div className="min-w-0">
            <p className="text-xs text-muted">Estimated saved</p>
            <p className="text-xs text-muted">{basis}</p>
          </div>
          <Money value={p.estimatedSaved} className="shrink-0 text-lg font-semibold text-good" />
        </div>
      </div>

      {p.state !== "upcoming" && (
        <button type="button" onClick={() => setOpen((v) => !v)} className="mt-3 flex items-center gap-1 text-xs font-medium text-brand" aria-expanded={open}>
          <ChevronDown className={cn("size-3.5 transition-transform", open && "rotate-180")} />
          {open ? "Hide" : "Show"} matching purchases
        </button>
      )}
      {open && (
        <ul className="mt-2 divide-y divide-line text-sm">
          {matches.length === 0 ? (
            <li className="py-2 text-xs text-muted">Nothing spent here during the rule. Nice going!</li>
          ) : (
            matches.map((t) => (
              <li key={t.id} className="flex items-center justify-between gap-2 py-2">
                <span className="min-w-0 truncate">
                  <span className="text-xs text-muted">{fmtDate(t.date)}</span> · {t.description || t.merchant || t.subcategory || t.category}
                </span>
                <Money value={t.amount} className="shrink-0 text-bad" />
              </li>
            ))
          )}
        </ul>
      )}
    </Card>
  );
}


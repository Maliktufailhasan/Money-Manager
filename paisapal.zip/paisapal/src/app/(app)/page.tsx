"use client";
import { Minus, Plus } from "lucide-react";
import { useQuickAdd } from "@/components/AppShell";
import { AlertsInsights, StreakChips } from "@/components/home/AlertsInsights";
import { DashboardCharts } from "@/components/home/DashboardCharts";
import { DashboardEmpty } from "@/components/home/DashboardEmpty";
import { MoneyTiles } from "@/components/home/MoneyTiles";
import { Button, ErrorState, PageHeader, PageSkeleton } from "@/components/ui";
import { useFinance } from "@/lib/client/useFinance";
import { fmtDate, weekdayShort } from "@/lib/finance";

export default function DashboardPage() {
  const { data, error, refresh } = useFinance();
  const quick = useQuickAdd();
  if (!data) return error ? <ErrorState error={error} retry={refresh} /> : <PageSkeleton />;
  if (data.s.totals.tx_count === 0) return <DashboardEmpty name={data.s.profile.name} />;

  const first = data.s.profile.name?.split(" ")[0];
  return (
    <div className="space-y-5">
      <PageHeader
        title={first ? `Hi ${first}` : "Dashboard"}
        subtitle={`${weekdayShort(data.today)}, ${fmtDate(data.today, { year: true })} · here's where your money stands`}
        actions={
          <>
            <Button variant="soft" size="sm" onClick={() => quick.open({ type: "income" })}>
              <Plus className="size-4" /> Income
            </Button>
            <Button size="sm" onClick={() => quick.open({ type: "expense" })}>
              <Minus className="size-4" /> Expense
            </Button>
          </>
        }
      />
      <StreakChips data={data} />
      <MoneyTiles data={data} />
      <AlertsInsights data={data} />
      <DashboardCharts data={data} />
    </div>
  );
}

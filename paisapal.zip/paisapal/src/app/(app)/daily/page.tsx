"use client";
import { CalendarDays, Minus, Plus } from "lucide-react";
import { useState } from "react";
import { useQuickAdd } from "@/components/AppShell";
import { DailyLimitControl } from "@/components/home/DailyLimitControl";
import { PeriodSwitcher, TxActions, TxAmount, txTitle } from "@/components/home/shared";
import { Badge, Button, Card, CardTitle, EmptyState, ErrorState, Money, PageHeader, PageSkeleton, Progress, SourceTag, Stat, cn } from "@/components/ui";
import { categoryColor } from "@/components/charts";
import { useFinance } from "@/lib/client/useFinance";
import { addDays, balanceSeries, fmtDate, formatINR, round2, spentOn, summarize, weekdayShort } from "@/lib/finance";

export default function DailyPage() {
  const { data, error, refresh } = useFinance();
  const quick = useQuickAdd();
  const [picked, setPicked] = useState<string | null>(null);
  if (!data) return error ? <ErrorState error={error} retry={refresh} /> : <PageSkeleton />;

  const { s, today, sts } = data;
  const date = picked && picked <= today ? picked : today;
  const isToday = date === today;
  const beforeWindow = date < s.windowStart;
  const prev = addDays(date, -1);

  // balance at the end of the previous day = money available at the start of this day
  const available = beforeWindow ? null : (balanceSeries(s, prev, prev)[0]?.balance ?? null);
  const day = summarize(s.transactions, date, date);
  const spent = spentOn(s.transactions, date, date);
  const remaining = available === null ? null : round2(available + day.received - spent);
  const limit = s.profile.daily_limit;
  const target = limit ?? (isToday && sts.daily > 0 ? sts.daily : null);
  const over = target !== null ? round2(spent - target) : null;
  const txs = s.transactions
    .filter((t) => t.date === date)
    .sort((a, b) => (a.time ?? "99").localeCompare(b.time ?? "99") || a.created_at.localeCompare(b.created_at));

  return (
    <div className="space-y-4">
      <PageHeader
        title={isToday ? "Today" : "Daily tracker"}
        subtitle={`${weekdayShort(date)}, ${fmtDate(date, { year: true })}`}
        actions={
          <div className="flex flex-wrap items-center gap-2">
            <PeriodSwitcher label={isToday ? "Today" : fmtDate(date)} onPrev={() => setPicked(prev)} onNext={() => setPicked(addDays(date, 1))} nextDisabled={isToday}>
              <label className="relative inline-flex size-8 cursor-pointer items-center justify-center rounded-lg text-ink-2 hover:bg-surface-2" title="Pick a date">
                <CalendarDays className="size-4" />
                <span className="sr-only">Pick a date</span>
                <input type="date" value={date} max={today} onChange={(e) => e.target.value && setPicked(e.target.value)} className="absolute inset-0 cursor-pointer opacity-0" />
              </label>
            </PeriodSwitcher>
            {!isToday && (
              <Button variant="ghost" size="sm" onClick={() => setPicked(null)}>
                Back to today
              </Button>
            )}
          </div>
        }
      />

      {target !== null && (
        <Card className={cn("py-3", over! > 0 ? "border-bad/30 bg-bad-soft" : "border-good/30 bg-good-soft")}>
          <p className={cn("text-sm font-medium", over! > 0 ? "text-bad" : "text-good")}>
            {over! > 0 ? `${formatINR(over)} over ${isToday ? "today's" : "the day's"} target` : `${formatINR(-over!)} left within ${isToday ? "today's" : "the day's"} target`}
          </p>
          <Progress className="mt-2" value={target ? (spent / target) * 100 : 0} tone={over! > 0 ? "bad" : spent / target >= 0.8 ? "warn" : "good"} label="Daily target used" />
        </Card>
      )}

      <div className="grid grid-cols-2 gap-3 sm:gap-4 lg:grid-cols-4">
        <Stat label="Money available" value={available === null ? "—" : <Money value={available} />} sub={available === null ? "Before your history window" : "Balance at the start of the day"} />
        <Stat label={isToday ? "Spent today" : "Spent"} value={<Money value={spent} />} sub={`${day.expenseCount} expense${day.expenseCount === 1 ? "" : "s"}${day.received ? ` · received ${formatINR(day.received)}` : ""}`} />
        <Stat label="Remaining" value={remaining === null ? "—" : <Money value={remaining} />} tone={remaining !== null && remaining < 0 ? "bad" : undefined} sub="Available + received − spent" />
        <Stat
          label="Daily limit"
          value={target === null ? "Not set" : <Money value={target} />}
          sub={limit ? <SourceTag kind="assumption" /> : target !== null ? <span className="inline-flex items-center gap-1">Suggested <SourceTag kind="calculated" /></span> : "Set one below"}
        />
      </div>

      <div className="grid gap-4 lg:grid-cols-[1fr_1.3fr]">
        <div className="space-y-4">
          <Card>
            <CardTitle hint="Expenses by category">Where it went</CardTitle>
            {day.byCategory.length === 0 ? (
              <p className="py-4 text-center text-sm text-muted">No spending recorded{isToday ? " yet today" : " on this day"}.</p>
            ) : (
              <table className="w-full text-sm">
                <tbody>
                  {day.byCategory.map((c) => (
                    <tr key={c.name} className="border-b border-line last:border-0">
                      <td className="py-2">
                        <span className="flex items-center gap-2">
                          <span className="size-2.5 rounded-sm" style={{ background: categoryColor(c.name) }} />
                          {c.name}
                          <span className="text-xs text-muted">×{c.count}</span>
                        </span>
                      </td>
                      <td className="py-2 text-right">
                        <Money value={c.amount} />
                      </td>
                    </tr>
                  ))}
                  <tr className="border-t-2 border-line font-semibold">
                    <td className="py-2">Total</td>
                    <td className="py-2 text-right">
                      <Money value={day.grossSpent} />
                    </td>
                  </tr>
                  {day.refunds > 0 && (
                    <tr className="text-xs text-muted">
                      <td className="pb-1">Refunds received</td>
                      <td className="pb-1 text-right">−{formatINR(day.refunds)}</td>
                    </tr>
                  )}
                </tbody>
              </table>
            )}
          </Card>
          <DailyLimitControl current={limit} suggested={sts.daily} />
        </div>

        <Card>
          <CardTitle
            hint="In the order they happened"
            action={
              <div className="flex gap-1">
                <Button size="sm" variant="soft" onClick={() => quick.open({ type: "income", preset: { type: "income", date } })}>
                  <Plus className="size-3.5" /> Income
                </Button>
                <Button size="sm" onClick={() => quick.open({ type: "expense", preset: { type: "expense", date } })}>
                  <Minus className="size-3.5" /> Expense
                </Button>
              </div>
            }
          >
            Timeline
          </CardTitle>
          {txs.length === 0 ? (
            <EmptyState title={isToday ? "Nothing logged today" : "Nothing logged on this day"}>Tap “Expense” to record what you spent — even small amounts add up.</EmptyState>
          ) : (
            <ol className="relative space-y-1 border-l border-line pl-4">
              {txs.map((t) => (
                <li key={t.id} className="relative py-1.5">
                  <span className={cn("absolute top-3.5 -left-[21px] size-2.5 rounded-full ring-2 ring-surface", t.type === "income" ? "bg-good" : "bg-brand")} />
                  <div className="flex items-start justify-between gap-2">
                    <div className="min-w-0">
                      <p className="truncate text-sm font-medium">{txTitle(t)}</p>
                      <p className="truncate text-xs text-muted">
                        {t.time ? t.time.slice(0, 5) : "No time"} · {t.category}
                        {t.subcategory ? ` · ${t.subcategory}` : ""}
                        {t.payment_method ? ` · ${t.payment_method}` : ""}
                      </p>
                    </div>
                    <TxAmount tx={t} className="text-sm" />
                  </div>
                  <div className="flex items-center justify-between">
                    <span>{t.need_or_want && <Badge tone={t.need_or_want === "want" ? "warn" : "neutral"}>{t.need_or_want}</Badge>}</span>
                    <TxActions tx={t} compact />
                  </div>
                </li>
              ))}
            </ol>
          )}
        </Card>
      </div>
    </div>
  );
}

"use client";
import { ChevronLeft, ChevronRight, Download, Minus, Plus, Search, SlidersHorizontal } from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import useSWR from "swr";
import { useQuickAdd } from "@/components/AppShell";
import { downloadText, fetchAllTransactions, toCsv } from "@/components/home/csv";
import { TxActions, TxAmount, txTitle } from "@/components/home/shared";
import { activeCount, EMPTY_FILTERS, presetRange, TxFilters, type TxFilterState } from "@/components/home/TxFilters";
import { Badge, Button, Card, EmptyState, ErrorState, Input, Money, PageHeader, PageSkeleton, Skeleton, cn, useToast } from "@/components/ui";
import { fetcher } from "@/lib/client/api";
import { expenseCategories, incomeSources } from "@/lib/client/categories";
import { useFinance } from "@/lib/client/useFinance";
import { fmtDate, sum, weekdayShort } from "@/lib/finance";
import type { Transaction } from "@/lib/types";

const PAGE_SIZE = 25;

function useDebounced<T>(value: T, ms: number): T {
  const [v, setV] = useState(value);
  useEffect(() => {
    const id = setTimeout(() => setV(value), ms);
    return () => clearTimeout(id);
  }, [value, ms]);
  return v;
}

interface PageResult {
  rows: Transaction[];
  total: number;
  page: number;
  pageSize: number;
}

export default function TransactionsPage() {
  const { data, error, refresh } = useFinance();
  const quick = useQuickAdd();
  const toast = useToast();
  const [search, setSearch] = useState("");
  const [filters, setFilters] = useState<TxFilterState>(EMPTY_FILTERS);
  const [showFilters, setShowFilters] = useState(false);
  const [pageState, setPageState] = useState({ key: "", page: 1 });
  const [exporting, setExporting] = useState(false);

  const q = useDebounced(search.trim(), 300);
  // text/number filters are debounced too so typing doesn't fire a request per key
  const merchant = useDebounced(filters.merchant.trim(), 300);
  const min = useDebounced(filters.min, 300);
  const max = useDebounced(filters.max, 300);
  const today = data?.today ?? "";

  const params = useMemo(() => {
    const p = new URLSearchParams();
    const range = presetRange(filters.preset, today, { from: filters.from, to: filters.to });
    const entries: [string, string][] = [
      ["q", q],
      ["type", filters.type],
      ["category", filters.category],
      ["payment_method", filters.payment_method],
      ["need_or_want", filters.need_or_want],
      ["essential", filters.essential],
      ["from", range.from],
      ["to", range.to],
      ["min", min],
      ["max", max],
      ["merchant", merchant],
      ["sort", filters.sort],
      ["dir", filters.dir],
    ];
    for (const [k, v] of entries) if (v) p.set(k, v);
    return p;
  }, [q, filters, merchant, min, max, today]);

  const filterKey = params.toString();
  // page resets to 1 whenever the filters change
  const page = pageState.key === filterKey ? pageState.page : 1;
  const setPage = (n: number) => setPageState({ key: filterKey, page: n });
  const swrKey = data ? `/api/data/transactions?${filterKey}${filterKey ? "&" : ""}page=${page}&pageSize=${PAGE_SIZE}` : null;
  const list = useSWR<PageResult>(swrKey, fetcher, { keepPreviousData: true });

  const cats = useMemo(() => (data ? Object.keys(expenseCategories(data.s.categories)) : []), [data]);
  const incomeCats = useMemo(() => (data ? incomeSources(data.s.categories) : []), [data]);

  if (!data) return error ? <ErrorState error={error} retry={refresh} /> : <PageSkeleton />;

  const rows = list.data?.rows ?? [];
  const total = list.data?.total ?? 0;
  const pages = Math.max(1, Math.ceil(total / PAGE_SIZE));
  const pageIncome = sum(rows.filter((r) => r.type === "income").map((r) => r.amount));
  const pageExpense = sum(rows.filter((r) => r.type === "expense").map((r) => r.amount));
  const nActive = activeCount(filters) + (q ? 1 : 0);

  async function exportCsv() {
    setExporting(true);
    try {
      const { rows: all, total: n, capped } = await fetchAllTransactions(params);
      if (!all.length) {
        toast("Nothing to export for these filters.", "info");
        return;
      }
      downloadText(`paisapal-transactions-${data!.today}.csv`, toCsv(all));
      toast(capped ? `Exported the first ${all.length} of ${n} transactions (limit 5000).` : `Exported ${all.length} transaction${all.length === 1 ? "" : "s"}.`, capped ? "warn" : "good");
    } catch (e) {
      toast(e instanceof Error ? e.message : "Export failed", "bad");
    } finally {
      setExporting(false);
    }
  }

  return (
    <div className="space-y-4">
      <PageHeader
        title="Transactions"
        subtitle={data.s.totals.tx_count ? `${data.s.totals.tx_count.toLocaleString("en-IN")} recorded in total` : "Every rupee in and out"}
        actions={
          <>
            <Button variant="secondary" size="sm" onClick={exportCsv} loading={exporting} disabled={!total}>
              {!exporting && <Download className="size-4" />} Export CSV
            </Button>
            <Button variant="soft" size="sm" onClick={() => quick.open({ type: "income" })}>
              <Plus className="size-4" /> Income
            </Button>
            <Button size="sm" onClick={() => quick.open({ type: "expense" })}>
              <Minus className="size-4" /> Expense
            </Button>
          </>
        }
      />

      <Card className="space-y-3">
        <div className="flex gap-2">
          <div className="relative flex-1">
            <Search className="pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-muted" />
            <Input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search description, merchant, notes…" className="pl-9" aria-label="Search transactions" type="search" />
          </div>
          <Button variant={showFilters ? "soft" : "secondary"} onClick={() => setShowFilters((v) => !v)} aria-expanded={showFilters}>
            <SlidersHorizontal className="size-4" />
            <span className="hidden sm:inline">Filters</span>
            {activeCount(filters) > 0 && <Badge tone="brand">{activeCount(filters)}</Badge>}
          </Button>
        </div>
        <TxFilters value={filters} onChange={setFilters} categories={cats} incomeCats={incomeCats} advanced={showFilters} />
      </Card>

      {list.error ? (
        <ErrorState error={list.error as Error} retry={() => list.mutate()} />
      ) : !list.data ? (
        <div className="space-y-2">
          {Array.from({ length: 6 }).map((_, i) => (
            <Skeleton key={i} className="h-14" />
          ))}
        </div>
      ) : total === 0 ? (
        nActive > 0 ? (
          <EmptyState title="No matching transactions">
            Try a different search or{" "}
            <button
              type="button"
              className="text-brand hover:underline"
              onClick={() => {
                setFilters(EMPTY_FILTERS);
                setSearch("");
              }}
            >
              clear all filters
            </button>
            .
          </EmptyState>
        ) : (
          <EmptyState
            title="No transactions yet"
            action={
              <>
                <Button variant="soft" onClick={() => quick.open({ type: "income" })}>
                  <Plus className="size-4" /> Add income
                </Button>
                <Button onClick={() => quick.open({ type: "expense" })}>
                  <Minus className="size-4" /> Add expense
                </Button>
              </>
            }
          >
            Record what you receive and spend — your history will show up here.
          </EmptyState>
        )
      ) : (
        <>
          <div className={cn("flex flex-wrap items-center justify-between gap-2 text-sm transition-opacity", list.isValidating && "opacity-70")}>
            <span className="text-muted">
              {total.toLocaleString("en-IN")} transaction{total === 1 ? "" : "s"}
              {nActive > 0 && " match"}
            </span>
            <span className="flex gap-3 text-xs">
              <span>
                This page: in <Money value={pageIncome} className="font-semibold text-good" />
              </span>
              <span>
                out <Money value={pageExpense} className="font-semibold" />
              </span>
            </span>
          </div>

          <DesktopTable rows={rows} />
          <MobileList rows={rows} />

          {pages > 1 && (
            <div className="flex items-center justify-center gap-3">
              <Button variant="secondary" size="sm" disabled={page <= 1} onClick={() => setPage(page - 1)}>
                <ChevronLeft className="size-4" /> Prev
              </Button>
              <span className="text-sm text-muted tabular">
                Page {page} of {pages}
              </span>
              <Button variant="secondary" size="sm" disabled={page >= pages} onClick={() => setPage(page + 1)}>
                Next <ChevronRight className="size-4" />
              </Button>
            </div>
          )}
        </>
      )}
    </div>
  );
}

function Meta({ t }: { t: Transaction }) {
  return (
    <span className="flex flex-wrap items-center gap-1">
      {t.need_or_want && <Badge tone={t.need_or_want === "want" ? "warn" : "neutral"}>{t.need_or_want}</Badge>}
      {t.recurring && <Badge tone="brand">recurring</Badge>}
      {t.is_demo && <Badge tone="warn">demo</Badge>}
    </span>
  );
}

function DesktopTable({ rows }: { rows: Transaction[] }) {
  return (
    <div className="hidden overflow-hidden rounded-2xl border border-line bg-surface md:block">
      <table className="w-full text-sm">
        <thead className="bg-surface-2 text-left text-xs text-muted">
          <tr>
            <th className="px-4 py-2.5 font-medium">Date</th>
            <th className="px-2 py-2.5 font-medium">Type</th>
            <th className="px-2 py-2.5 font-medium">Category</th>
            <th className="px-2 py-2.5 font-medium">Description / merchant</th>
            <th className="px-2 py-2.5 font-medium">Payment</th>
            <th className="px-2 py-2.5 text-right font-medium">Amount</th>
            <th className="w-28 px-2 py-2.5">
              <span className="sr-only">Actions</span>
            </th>
          </tr>
        </thead>
        <tbody>
          {rows.map((t) => (
            <tr key={t.id} className="border-t border-line hover:bg-surface-2/50">
              <td className="px-4 py-2.5 whitespace-nowrap">
                <div>{fmtDate(t.date, { year: true })}</div>
                {t.time && <div className="text-xs text-muted">{t.time.slice(0, 5)}</div>}
              </td>
              <td className="px-2 py-2.5">
                <Badge tone={t.type === "income" ? "good" : "neutral"}>{t.type === "income" ? "Income" : "Expense"}</Badge>
              </td>
              <td className="px-2 py-2.5">
                <div>{t.category}</div>
                {t.subcategory && <div className="text-xs text-muted">{t.subcategory}</div>}
              </td>
              <td className="max-w-64 px-2 py-2.5">
                <div className="truncate">{t.description || <span className="text-muted">—</span>}</div>
                <div className="flex items-center gap-1 text-xs text-muted">
                  {t.merchant && <span className="truncate">{t.merchant}</span>}
                  <Meta t={t} />
                </div>
              </td>
              <td className="px-2 py-2.5 text-ink-2">{t.payment_method ?? "—"}</td>
              <td className="px-2 py-2.5 text-right">
                <TxAmount tx={t} />
              </td>
              <td className="px-2 py-1">
                <div className="flex justify-end">
                  <TxActions tx={t} compact />
                </div>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function MobileList({ rows }: { rows: Transaction[] }) {
  const groups: { date: string; items: Transaction[] }[] = [];
  for (const t of rows) {
    const last = groups[groups.length - 1];
    if (last && last.date === t.date) last.items.push(t);
    else groups.push({ date: t.date, items: [t] });
  }
  return (
    <div className="space-y-4 md:hidden">
      {groups.map((g) => (
        <section key={g.date + g.items[0].id}>
          <h3 className="mb-1.5 px-1 text-xs font-semibold text-muted">
            {weekdayShort(g.date)}, {fmtDate(g.date, { year: true })}
          </h3>
          <ul className="divide-y divide-line overflow-hidden rounded-2xl border border-line bg-surface">
            {g.items.map((t) => (
              <li key={t.id} className="px-3 py-2.5">
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0">
                    <p className="truncate text-sm font-medium">{txTitle(t)}</p>
                    <p className="truncate text-xs text-muted">
                      {t.category}
                      {t.subcategory ? ` · ${t.subcategory}` : ""}
                      {t.payment_method ? ` · ${t.payment_method}` : ""}
                      {t.time ? ` · ${t.time.slice(0, 5)}` : ""}
                    </p>
                  </div>
                  <TxAmount tx={t} className="text-sm" />
                </div>
                <div className="mt-1 flex items-center justify-between">
                  <Meta t={t} />
                  <TxActions tx={t} compact />
                </div>
              </li>
            ))}
          </ul>
        </section>
      ))}
    </div>
  );
}

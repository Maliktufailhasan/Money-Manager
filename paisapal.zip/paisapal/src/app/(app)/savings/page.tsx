"use client";
import { Info, LifeBuoy, PiggyBank, Plus, Wallet } from "lucide-react";
import Link from "next/link";
import { useMemo } from "react";
import { useQuickAdd } from "@/components/AppShell";
import { useFinance } from "@/lib/client/useFinance";
import { formatINR, formatPct, monthKey, monthlySeries, pct, round2, sum, ym } from "@/lib/finance";
import { BarsChart, COLORS, ChartBox } from "@/components/charts";
import { Badge, Button, Card, CardTitle, Chip, EmptyState, ErrorState, PageHeader, PageSkeleton, Progress, SourceTag, Stat, cn } from "@/components/ui";
import { useGoalModals } from "@/components/plan/useGoalModals";

const EMERGENCY_TARGETS = [5000, 10000, 25000];

export default function SavingsPage() {
  const { data, error, refresh } = useFinance();
  const quickAdd = useQuickAdd();
  const ui = useGoalModals(data?.today ?? "");

  const derived = useMemo(() => {
    if (!data) return null;
    const { s, today } = data;
    const series = monthlySeries(s.transactions, 12, today);
    const firstKey = s.totals.first_date ? monthKey(s.totals.first_date) : null;
    const windowKey = monthKey(s.windowStart);
    const withData = series.filter((p) => firstKey && p.key >= firstKey && p.key >= windowKey);
    const thisKey = monthKey(today);
    const { year } = ym(today);
    const ytd = withData.filter((p) => p.key.startsWith(`${year}-`));
    const complete = withData.filter((p) => p.key < thisKey).slice(-6);
    return {
      series,
      thisMonth: series.find((p) => p.key === thisKey),
      ytd: sum(ytd.map((p) => p.net)),
      ytdPartial: windowKey > `${year}-01`,
      avg6: complete.length ? round2(sum(complete.map((p) => p.net)) / complete.length) : null,
      avgMonths: complete.length,
    };
  }, [data]);

  if (!data || !derived) return error ? <ErrorState error={error} retry={refresh} /> : <PageSkeleton />;
  const { s, balance, position, today } = data;

  const lifetime = round2(s.totals.total_income - s.totals.total_expense);
  const goalSavings = sum(s.goals.map((g) => g.current_amount));
  const emergencyGoals = s.goals.filter((g) => g.is_emergency);
  const emergency = emergencyGoals.find((g) => g.status !== "completed") ?? emergencyGoals[0];
  const emergencySaved = sum(emergencyGoals.map((g) => g.current_amount));
  const unallocated = round2(balance - goalSavings);
  const monthNet = derived.thisMonth?.net ?? 0;
  const monthRate = derived.thisMonth ? pct(derived.thisMonth.net, derived.thisMonth.income) : null;
  const avgMonthly = derived.avg6 ?? position.savingCapacity;
  const noData = s.totals.tx_count === 0;

  const buckets = [...s.goals].sort((a, b) => Number(b.is_emergency) - Number(a.is_emergency) || Number(a.status === "completed") - Number(b.status === "completed"));

  return (
    <div className="space-y-4">
      <PageHeader
        title="Savings"
        subtitle="What you've kept, where it sits, and how it's growing."
        actions={
          <Button onClick={() => ui.newGoal()}>
            <Plus className="size-4" /> New bucket
          </Button>
        }
      />

      {noData ? (
        <EmptyState
          icon={<PiggyBank className="size-8" />}
          title="No savings data yet"
          action={
            <>
              <Button onClick={() => quickAdd.open({ type: "income" })}>Add income</Button>
              <Button variant="secondary" onClick={() => quickAdd.open({ type: "expense" })}>
                Add expense
              </Button>
            </>
          }
        >
          Savings = money received − money spent. Record your income and expenses to see how much you&apos;re keeping.
        </EmptyState>
      ) : (
        <>
          <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
            <Stat label="Total saved (all time)" value={formatINR(lifetime)} tone={lifetime < 0 ? "bad" : "good"} sub="All income − all expenses" icon={<PiggyBank className="size-4" />} />
            <Stat label="This month" value={formatINR(monthNet, { sign: true })} tone={monthNet < 0 ? "bad" : monthNet > 0 ? "good" : undefined} sub={monthRate !== null ? `${formatPct(monthRate, 0)} of income kept` : "No income yet this month"} />
            <Stat label={`This year (${ym(today).year})`} value={formatINR(derived.ytd, { sign: true })} tone={derived.ytd < 0 ? "bad" : undefined} sub={derived.ytdPartial ? "Since the start of your recorded data" : "Sum of monthly savings since Jan"} />
            <Stat
              label="Avg. monthly savings"
              value={formatINR(avgMonthly, { sign: true })}
              tone={avgMonthly < 0 ? "bad" : undefined}
              sub={derived.avg6 !== null ? `Last ${derived.avgMonths} complete month${derived.avgMonths > 1 ? "s" : ""}` : "Estimate — limited history"}
            />
          </div>
          <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
            <Stat label="Savings rate" value={formatPct(position.savingsRate, 0)} sub={position.isEstimate ? "Estimate" : "Average of recent months"} tone={position.savingsRate !== null && position.savingsRate < 0 ? "bad" : undefined} />
            <Stat label="Emergency savings" value={formatINR(emergencySaved)} sub={emergency ? `of ${formatINR(emergency.target_amount)} target` : "No emergency fund yet"} icon={<LifeBuoy className="size-4" />} />
            <Stat label="In goal buckets" value={formatINR(goalSavings)} sub={`${s.goals.length} bucket${s.goals.length === 1 ? "" : "s"}`} />
            <Stat label="Unallocated savings" value={formatINR(unallocated)} tone={unallocated < 0 ? "bad" : undefined} sub="Balance − goal buckets" icon={<Wallet className="size-4" />} />
          </div>

          <Card className="flex gap-3 py-3 text-xs text-ink-2 sm:py-4">
            <Info className="mt-0.5 size-4 shrink-0 text-muted" />
            <div className="space-y-1">
              <p>
                <span className="font-medium text-ink">Total saved</span> is everything you&apos;ve received minus everything you&apos;ve spent since you started recording ({formatINR(s.totals.total_income)} − {formatINR(s.totals.total_expense)}). It equals your balance ({formatINR(balance)}) minus your opening balance ({formatINR(s.profile.opening_balance)}).
              </p>
              <p>
                <span className="font-medium text-ink">Unallocated</span> is balance money not assigned to any goal.
                {unallocated < 0 && ` It's negative because your goal buckets (${formatINR(goalSavings)}) add up to more than your balance — some goal money has been spent, or was counted before you recorded income. Consider withdrawing from a goal or recording missing income.`}
              </p>
            </div>
          </Card>

          <ChartBox
            title="Monthly savings"
            hint="Money received − money spent each month. Bars below zero are months you spent more than you received."
            table={{ columns: ["Month", "Received", "Spent", "Saved"], rows: derived.series.map((p) => [p.label, p.income, p.expense, p.net]) }}
            action={<SourceTag kind="recorded" />}
          >
            <BarsChart data={derived.series.map((p) => ({ label: p.label, net: p.net }))} xKey="label" series={[{ key: "net", label: "Saved", color: COLORS.saved }]} />
          </ChartBox>
        </>
      )}

      <div className="grid gap-4 lg:grid-cols-[minmax(0,0.9fr)_minmax(0,1.1fr)] lg:items-start">
        <EmergencyCard emergency={emergency} onCreate={(t) => ui.newGoal({ name: "Emergency Fund", category: "Emergency Fund", is_emergency: true, target_amount: t })} onAdd={() => emergency && ui.addMoney(emergency)} avgExpense={position.avgMonthlyExpense} />

        <Card>
          <CardTitle
            hint="Each goal is a bucket of money set aside."
            action={
              <Link href="/goals" className="text-xs font-medium text-brand hover:underline">
                Manage goals
              </Link>
            }
          >
            Savings buckets
          </CardTitle>
          {buckets.length === 0 ? (
            <EmptyState title="No buckets yet" action={<Button onClick={() => ui.newGoal()}>+ New bucket</Button>}>
              Split your savings into buckets like Emergency Fund or New Phone.
            </EmptyState>
          ) : (
            <ul className="divide-y divide-line">
              {buckets.map((g) => {
                const p = Math.min(100, pct(g.current_amount, g.target_amount) ?? 0);
                const done = g.status === "completed" || g.current_amount >= g.target_amount;
                return (
                  <li key={g.id} className="flex items-center gap-3 py-3">
                    <div className="min-w-0 flex-1">
                      <div className="mb-1 flex items-center gap-1.5">
                        <span className="truncate text-sm font-medium">{g.name}</span>
                        {g.is_emergency && <Badge tone="brand">Emergency</Badge>}
                        {g.status === "paused" && <Badge>Paused</Badge>}
                        {done && <Badge tone="good">Done</Badge>}
                      </div>
                      <Progress value={p} tone={done ? "good" : "brand"} label={`${g.name} progress`} />
                      <p className="mt-1 text-xs text-muted tabular">
                        {formatINR(g.current_amount)} / {formatINR(g.target_amount)} · {Math.round(p)}%
                      </p>
                    </div>
                    {!done && (
                      <Button size="sm" variant="soft" onClick={() => ui.addMoney(g)} disabled={g.status === "paused"} aria-label={`Add money to ${g.name}`}>
                        <Plus className="size-3.5" /> Add
                      </Button>
                    )}
                  </li>
                );
              })}
            </ul>
          )}
          {buckets.length > 0 && (
            <Button variant="ghost" size="sm" className="mt-2" onClick={() => ui.newGoal()}>
              <Plus className="size-3.5" /> New bucket
            </Button>
          )}
        </Card>
      </div>
      {ui.modals}
    </div>
  );
}

function EmergencyCard({ emergency, onCreate, onAdd, avgExpense }: { emergency?: { name: string; current_amount: number; target_amount: number; status: string }; onCreate: (target?: number) => void; onAdd: () => void; avgExpense: number }) {
  if (!emergency) {
    return (
      <Card>
        <CardTitle hint="A safety net for surprises — a medical bill, a broken phone, a late allowance.">
          <span className="inline-flex items-center gap-1.5">
            <LifeBuoy className="size-4 text-brand" /> Emergency fund
          </span>
        </CardTitle>
        <p className="mb-3 text-sm text-ink-2">You don&apos;t have an emergency fund yet. Pick a starting target:</p>
        <div className="flex flex-wrap gap-2">
          {EMERGENCY_TARGETS.map((t) => (
            <Chip key={t} onClick={() => onCreate(t)}>
              {formatINR(t)}
            </Chip>
          ))}
          <Chip onClick={() => onCreate()}>Custom</Chip>
        </div>
        {avgExpense > 0 && <p className="mt-3 text-xs text-muted">Tip: aim for 1–3 months of expenses — about {formatINR(avgExpense)}–{formatINR(avgExpense * 3)} for you.</p>}
      </Card>
    );
  }
  const p = Math.min(100, pct(emergency.current_amount, emergency.target_amount) ?? 0);
  const months = avgExpense > 0 ? emergency.current_amount / avgExpense : null;
  return (
    <Card>
      <CardTitle hint={emergency.name}>
        <span className="inline-flex items-center gap-1.5">
          <LifeBuoy className="size-4 text-brand" /> Emergency fund
        </span>
      </CardTitle>
      <p className="text-2xl font-semibold tabular">
        {formatINR(emergency.current_amount)} <span className="text-base font-normal text-muted">/ {formatINR(emergency.target_amount)}</span>
      </p>
      <p className={cn("mb-2 text-sm", p >= 100 ? "text-good" : "text-ink-2")}>{Math.round(p)}% complete</p>
      <Progress value={p} tone={p >= 100 ? "good" : "brand"} label="Emergency fund progress" />
      {months !== null && <p className="mt-2 text-xs text-muted">Covers about {Math.round(months * 10) / 10} months of your usual spending.</p>}
      {p < 100 && emergency.status !== "paused" && (
        <Button size="sm" className="mt-3" onClick={onAdd}>
          <Plus className="size-3.5" /> Add money
        </Button>
      )}
    </Card>
  );
}

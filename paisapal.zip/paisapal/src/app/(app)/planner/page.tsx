"use client";
import { useSearchParams } from "next/navigation";
import { Suspense, useState } from "react";
import { useFinance } from "@/lib/client/useFinance";
import { ErrorState, PageHeader, PageSkeleton, Segmented } from "@/components/ui";
import { AffordCalc } from "@/components/plan/AffordCalc";
import { ScenarioSim } from "@/components/plan/ScenarioSim";
import { WhatIfPanel } from "@/components/plan/WhatIfPanel";
import { ZeroPlanner, type ZeroInitial } from "@/components/plan/ZeroPlanner";

type Tab = "afford" | "zero" | "scenarios" | "whatif";
const TABS: Tab[] = ["afford", "zero", "scenarios", "whatif"];

export default function PlannerPage() {
  return (
    <Suspense fallback={<PageSkeleton />}>
      <Planner />
    </Suspense>
  );
}

/** Reads the query string; remounts the planner when it changes (e.g. "Plan this goal"). */
function Planner() {
  const params = useSearchParams();
  const initial = {
    item: params.get("item") ?? undefined,
    price: params.get("price") ?? undefined,
    months: params.get("months") ?? undefined,
    start: params.get("start") ?? undefined,
  };
  const tabParam = params.get("tab") as Tab | null;
  const initialTab: Tab = tabParam && TABS.includes(tabParam) ? tabParam : initial.item || initial.price ? "zero" : "afford";
  return <PlannerBody key={params.toString()} initial={initial} initialTab={initialTab} />;
}

function PlannerBody({ initial, initialTab }: { initial: ZeroInitial; initialTab: Tab }) {
  const { data, error, refresh } = useFinance();
  const [tab, setTab] = useState<Tab>(initialTab);

  if (!data) return error ? <ErrorState error={error} retry={refresh} /> : <PageSkeleton />;
  const { s, position, today, balance } = data;

  return (
    <div className="space-y-4">
      <PageHeader title="Planner" subtitle="Figure out if — and when — you can afford the things you want." />
      <div className="-mx-4 overflow-x-auto px-4 pb-1 sm:mx-0 sm:px-0">
        <Segmented<Tab>
          value={tab}
          onChange={setTab}
          className="whitespace-nowrap"
          options={[
            { value: "afford", label: "Can I afford it?" },
            { value: "zero", label: "Start from ₹0" },
            { value: "scenarios", label: "Scenarios" },
            { value: "whatif", label: "What if?" },
          ]}
        />
      </div>
      {/* panels stay mounted so inputs survive tab switches */}
      <div hidden={tab !== "afford"}>
        <AffordCalc s={s} position={position} today={today} balance={balance} />
      </div>
      <div hidden={tab !== "zero"}>
        <ZeroPlanner today={today} initial={initial} />
      </div>
      <div hidden={tab !== "scenarios"}>
        <ScenarioSim s={s} position={position} today={today} />
      </div>
      <div hidden={tab !== "whatif"}>
        <WhatIfPanel s={s} position={position} today={today} />
      </div>
    </div>
  );
}

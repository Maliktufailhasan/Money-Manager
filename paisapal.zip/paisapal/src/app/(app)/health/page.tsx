"use client";
import { CheckCircle2, CircleHelp, MinusCircle, XCircle } from "lucide-react";
import Link from "next/link";
import { useMemo } from "react";
import { PctLineChart, fmtPct } from "@/components/analysis/PctLineChart";
import { SERIES } from "@/components/charts";
import { Badge, Button, Card, EmptyState, ErrorState, PageHeader, PageSkeleton, Progress, SourceTag, cn } from "@/components/ui";
import { useQuickAdd } from "@/components/AppShell";
import { healthIndicators, healthTrend, type HealthIndicator } from "@/lib/finance";
import { useFinance, type FinanceData } from "@/lib/client/useFinance";

const STATUS = {
  good: { label: "Healthy", icon: CheckCircle2, tone: "good", bar: "good" },
  ok: { label: "Okay", icon: MinusCircle, tone: "warn", bar: "warn" },
  poor: { label: "Needs work", icon: XCircle, tone: "bad", bar: "bad" },
  unknown: { label: "Not enough data", icon: CircleHelp, tone: "neutral", bar: "brand" },
} as const;

const LINKS: Record<string, string> = {
  savingsRate: "/savings",
  expenseToIncome: "/monthly",
  budgetAdherence: "/budget",
  essentialShare: "/insights",
  goalProgress: "/goals",
  recurringBurden: "/bills",
  emergency: "/goals",
  stability: "/earn",
};

export default function HealthPage() {
  const { data, error, refresh } = useFinance();
  if (!data) return error ? <ErrorState error={error} retry={refresh} /> : <PageSkeleton />;
  return <Health data={data} />;
}

function Health({ data }: { data: FinanceData }) {
  const { s, today } = data;
  const quick = useQuickAdd();
  const indicators = useMemo(() => healthIndicators(s, today), [s, today]);
  const trend = useMemo(() => healthTrend(s, today, 6), [s, today]);

  if (s.totals.tx_count === 0) {
    return (
      <>
        <PageHeader title="Financial health" subtitle="Measurable indicators based on your recorded money." />
        <EmptyState title="No data yet" action={<Button onClick={() => quick.open({ type: "income" })}>Add money received</Button>}>
          Record your income and expenses for a few weeks to see your savings rate, budget adherence and more.
        </EmptyState>
      </>
    );
  }

  const known = indicators.filter((i) => i.status !== "unknown");
  const good = known.filter((i) => i.status === "good").length;
  const rows = trend.map((m) => ({ ...m }));

  return (
    <>
      <PageHeader
        title="Financial health"
        subtitle="No mystery score — just measurable indicators from your recorded data."
        actions={<SourceTag kind="calculated" />}
      />

      <Card className="mb-4">
        <p className="text-sm text-ink-2">
          {known.length ? (
            <>
              <span className="font-semibold text-ink">{good} of {known.length}</span> measurable indicators are in a healthy range.
              {indicators.length - known.length > 0 && <span className="text-muted"> {indicators.length - known.length} need more data.</span>}
            </>
          ) : (
            "Keep recording for a full month to unlock these indicators."
          )}
        </p>
        <p className="mt-1 text-xs text-muted">Averages use up to the last 3 months. {data.position.basis}</p>
      </Card>

      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        {indicators.map((i) => (
          <IndicatorCard key={i.key} ind={i} href={LINKS[i.key]} />
        ))}
      </div>

      <h2 className="mt-8 mb-3 text-base font-semibold">Trends over the last 6 months</h2>
      {trend.length < 2 && <p className="mb-3 text-sm text-muted">Trends become meaningful after two or more months of records.</p>}
      <div className="grid gap-4 lg:grid-cols-2">
        <PctLineChart title="Savings rate" hint="Share of money received that you kept." data={rows} xKey="label" yKey="savingsRate" label="Savings rate" color={SERIES[2]} target={20} />
        <PctLineChart title="Expense-to-income" hint="Spending as a share of money received. Lower is better." data={rows} xKey="label" yKey="expenseToIncome" label="Expense-to-income" color={SERIES[1]} target={80} />
        <PctLineChart title="Budget adherence" hint="Budget categories kept within limit." data={rows} xKey="label" yKey="budgetAdherence" label="Budget adherence" color={SERIES[0]} target={85} />
        <PctLineChart title="Needs share of spending" hint="Needs as a share of classified spending." data={rows} xKey="label" yKey="essentialShare" label="Needs share" color={SERIES[3]} target={65} />
        <PctLineChart title="Recurring expense burden" hint="Recorded recurring spending as a share of income. Lower is better." data={rows} xKey="label" yKey="recurringBurden" label="Recurring burden" color={SERIES[4]} target={35} />
      </div>
    </>
  );
}

function IndicatorCard({ ind, href }: { ind: HealthIndicator; href?: string }) {
  const st = STATUS[ind.status];
  const Icon = st.icon;
  return (
    <Card className="flex flex-col gap-2">
      <div className="flex items-start justify-between gap-2">
        <h3 className="text-sm font-medium text-ink-2">{ind.label}</h3>
        <Badge tone={st.tone}>
          <Icon className="size-3.5" aria-hidden /> {st.label}
        </Badge>
      </div>
      <div className={cn("text-2xl font-semibold tabular", ind.status === "good" && "text-good", ind.status === "ok" && "text-warn", ind.status === "poor" && "text-bad")}>{fmtPct(ind.value)}</div>
      {ind.value !== null && <Progress value={ind.value} tone={st.bar} label={ind.label} />}
      <p className="text-xs text-muted">
        Target: <span className="font-medium text-ink-2">{ind.target}</span>
      </p>
      <p className="text-xs text-ink-2">{ind.explain}</p>
      {href && (
        <Link href={href} className="mt-auto text-xs font-medium text-brand hover:underline">
          Improve this →
        </Link>
      )}
    </Card>
  );
}

"use client";
import { Plus } from "lucide-react";
import { useMemo, useState } from "react";
import { useQuickAdd } from "@/components/AppShell";
import { PeriodSwitcher, TxActions } from "@/components/home/shared";
import { Badge, Button, Card, CardTitle, ErrorState, Money, PageHeader, PageSkeleton, cn } from "@/components/ui";
import { useFinance } from "@/lib/client/useFinance";
import { addDays, addMonths, calendarEvents, fmtDate, fmtMonth, formatINR, monthEnd, monthStart, round2, weekStart, weekdayShort, ym, type CalendarEvent } from "@/lib/finance";

const WEEKDAYS = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];

const MARKERS: { type: CalendarEvent["type"]; label: string; dot: string; tone: "warn" | "brand" | "bad" | "good" }[] = [
  { type: "bill", label: "Bill", dot: "bg-warn", tone: "warn" },
  { type: "subscription", label: "Subscription", dot: "bg-brand", tone: "brand" },
  { type: "goal_deadline", label: "Goal deadline", dot: "bg-bad", tone: "bad" },
  { type: "saving", label: "Saved to goal", dot: "bg-good", tone: "good" },
];

interface DayInfo {
  income: number;
  expense: number;
  events: CalendarEvent[];
}

export default function CalendarPage() {
  const { data, error, refresh } = useFinance();
  const quick = useQuickAdd();
  const [month, setMonth] = useState<string | null>(null);
  const [selected, setSelected] = useState<string | null>(null);

  const view = month ?? (data ? monthStart(data.today) : "");
  const grid = useMemo(() => {
    if (!data) return null;
    const from = weekStart(view);
    const lastWeek = weekStart(monthEnd(view));
    const to = addDays(lastWeek, 6);
    const days: string[] = [];
    for (let x = from; x <= to; x = addDays(x, 1)) days.push(x);
    const byDay = new Map<string, DayInfo>();
    for (const e of calendarEvents(data.s, from, to, data.today)) {
      const cur = byDay.get(e.date) ?? { income: 0, expense: 0, events: [] };
      if (e.type === "income") cur.income = round2(cur.income + (e.amount ?? 0));
      if (e.type === "expense") cur.expense = round2(cur.expense + (e.amount ?? 0));
      cur.events.push(e);
      byDay.set(e.date, cur);
    }
    return { days, byDay };
  }, [data, view]);

  if (!data || !grid) return error ? <ErrorState error={error} retry={refresh} /> : <PageSkeleton />;

  const { s, today } = data;
  const { year, month: m } = ym(view);
  const sel = selected ?? (monthStart(today) === view ? today : view);
  const selInfo = grid.byDay.get(sel);
  const inMonth = (dd: string) => dd.slice(0, 7) === view.slice(0, 7);
  const monthIn = [...grid.byDay.entries()].filter(([dd]) => inMonth(dd));
  const monthIncome = round2(monthIn.reduce((a, [, v]) => a + v.income, 0));
  const monthExpense = round2(monthIn.reduce((a, [, v]) => a + v.expense, 0));
  const beforeWindow = view === monthStart(s.windowStart) && s.windowStart > view;

  function go(n: number) {
    setMonth(addMonths(view, n));
    setSelected(null);
  }

  return (
    <div className="space-y-4">
      <PageHeader
        title="Calendar"
        subtitle="Income, spending, bills and goal dates at a glance"
        actions={
          <div className="flex items-center gap-2">
            <PeriodSwitcher label={fmtMonth(year, m, false)} onPrev={() => go(-1)} onNext={() => go(1)} prevDisabled={view <= monthStart(s.windowStart)} />
            {view !== monthStart(today) && (
              <Button variant="ghost" size="sm" onClick={() => { setMonth(null); setSelected(null); }}>
                Today
              </Button>
            )}
          </div>
        }
      />

      {beforeWindow && <p className="rounded-xl bg-surface-2 px-3 py-2 text-xs text-ink-2">Transactions before {fmtDate(s.windowStart, { year: true })} aren&apos;t shown on the calendar.</p>}

      <div className="grid gap-4 lg:grid-cols-[1fr_340px]">
        <Card className="p-2 sm:p-4">
          <div className="mb-2 flex flex-wrap items-center justify-between gap-2 px-1 text-xs">
            <span className="flex gap-3">
              <span>
                In <Money value={monthIncome} className="font-semibold text-good" />
              </span>
              <span>
                Out <Money value={monthExpense} className="font-semibold" />
              </span>
            </span>
            <span className="flex flex-wrap gap-x-3 gap-y-1 text-muted">
              {MARKERS.map((mk) => (
                <span key={mk.type} className="flex items-center gap-1">
                  <span className={cn("size-2 rounded-full", mk.dot)} />
                  {mk.label}
                </span>
              ))}
            </span>
          </div>
          <div className="grid grid-cols-7 gap-px overflow-hidden rounded-xl border border-line bg-line" aria-label={fmtMonth(year, m)}>
            {WEEKDAYS.map((w) => (
              <div key={w} className="bg-surface-2 py-1.5 text-center text-[11px] font-medium text-muted">
                {w}
              </div>
            ))}
            {grid.days.map((dd) => {
              const info = grid.byDay.get(dd);
              const isSel = dd === sel;
              const types = new Set(info?.events.map((e) => e.type));
              return (
                <button
                  key={dd}
                  type="button"
                  aria-pressed={isSel}
                  aria-label={`${fmtDate(dd)}${info?.expense ? `, spent ${formatINR(info.expense)}` : ""}${info?.income ? `, received ${formatINR(info.income)}` : ""}`}
                  onClick={() => setSelected(dd)}
                  className={cn(
                    "flex min-h-14 flex-col items-stretch gap-0.5 p-1 text-left transition-colors sm:min-h-20 sm:p-1.5",
                    inMonth(dd) ? "bg-surface" : "bg-surface-2/60 text-muted",
                    isSel ? "ring-2 ring-brand ring-inset" : "hover:bg-surface-2",
                  )}
                >
                  <span className={cn("flex size-5 items-center justify-center rounded-full text-[11px] sm:text-xs", dd === today && "bg-brand font-semibold text-brand-ink")}>{Number(dd.slice(8))}</span>
                  {info?.income ? <span className="tabular truncate text-[10px] leading-tight text-good sm:text-[11px]">+{compactINR(info.income)}</span> : null}
                  {info?.expense ? <span className="tabular truncate text-[10px] leading-tight text-ink-2 sm:text-[11px]">−{compactINR(info.expense)}</span> : null}
                  <span className="mt-auto flex gap-0.5">
                    {MARKERS.filter((mk) => types.has(mk.type)).map((mk) => (
                      <span key={mk.type} className={cn("size-1.5 rounded-full", mk.dot)} />
                    ))}
                  </span>
                </button>
              );
            })}
          </div>
        </Card>

        <Card className="h-fit lg:sticky lg:top-6">
          <CardTitle hint={selInfo ? `In ${formatINR(selInfo.income)} · Out ${formatINR(selInfo.expense)}` : "Nothing on this day"}>
            {weekdayShort(sel)}, {fmtDate(sel, { year: true })}
          </CardTitle>
          {selInfo?.events.length ? (
            <ul className="divide-y divide-line">
              {selInfo.events.map((e) => {
                const tx = e.type === "income" || e.type === "expense" ? s.transactions.find((t) => t.id === e.refId) : undefined;
                const mk = MARKERS.find((x) => x.type === e.type);
                return (
                  <li key={e.id} className="flex items-center justify-between gap-2 py-2">
                    <div className="min-w-0">
                      <p className="truncate text-sm">{e.title}</p>
                      <div className="mt-0.5 flex items-center gap-1">
                        {mk ? <Badge tone={mk.tone}>{mk.label}</Badge> : <Badge tone={e.type === "income" ? "good" : "neutral"}>{e.type === "income" ? "Income" : "Expense"}</Badge>}
                        {e.date > today && (e.type === "bill" || e.type === "subscription") && <Badge>scheduled</Badge>}
                      </div>
                    </div>
                    <div className="flex shrink-0 flex-col items-end">
                      {e.amount !== null && <span className={cn("tabular text-sm font-semibold", e.type === "income" && "text-good")}>{e.type === "income" ? "+" : e.type === "expense" ? "−" : ""}{formatINR(Math.abs(e.amount))}</span>}
                      {tx && <TxActions tx={tx} compact />}
                    </div>
                  </li>
                );
              })}
            </ul>
          ) : (
            <p className="py-4 text-center text-sm text-muted">No transactions or events.</p>
          )}
          <Button className="mt-3 w-full" variant="soft" onClick={() => quick.open({ type: "expense", preset: { type: "expense", date: sel } })} disabled={sel > today}>
            <Plus className="size-4" /> Add expense on this date
          </Button>
          {sel > today && <p className="mt-1 text-center text-xs text-muted">Future dates are for planned payments — add a bill instead.</p>}
        </Card>
      </div>
    </div>
  );
}

function compactINR(n: number): string {
  if (n >= 100000) return `₹${(n / 100000).toFixed(1)}L`;
  if (n >= 10000) return `₹${Math.round(n / 1000)}k`;
  if (n >= 1000) return `₹${(n / 1000).toFixed(1)}k`;
  return `₹${Math.round(n)}`;
}

"use client";
import { AlertTriangle, Info, ThumbsUp } from "lucide-react";
import { useMemo } from "react";
import { AiSummary } from "@/components/analysis/AiSummary";
import { NeedWant } from "@/components/analysis/NeedWant";
import { StreaksCard } from "@/components/analysis/StreaksCard";
import { WasteCards } from "@/components/analysis/WasteCards";
import { useQuickAdd } from "@/components/AppShell";
import { Donut, RankBars, SERIES } from "@/components/charts";
import { Button, Card, CardTitle, EmptyState, ErrorState, PageHeader, PageSkeleton, SourceTag, cn } from "@/components/ui";
import { detectWaste, generateInsights, monthStart, summarize, type Insight } from "@/lib/finance";
import { useFinance, type FinanceData } from "@/lib/client/useFinance";
import { PAYMENT_METHODS } from "@/lib/constants";

export default function InsightsPage() {
  const { data, error, refresh } = useFinance();
  if (!data) return error ? <ErrorState error={error} retry={refresh} /> : <PageSkeleton />;
  return <Insights data={data} />;
}

const TONE = {
  positive: { icon: ThumbsUp, cls: "bg-good-soft text-good", label: "Good news" },
  warning: { icon: AlertTriangle, cls: "bg-warn-soft text-warn", label: "Watch out" },
  info: { icon: Info, cls: "bg-brand-soft text-brand", label: "Note" },
} as const;

const methodColor = (name: string) => {
  const i = PAYMENT_METHODS.indexOf(name);
  return i >= 0 ? SERIES[i % SERIES.length] : "var(--muted)";
};

function Insights({ data }: { data: FinanceData }) {
  const { s, today, position } = data;
  const quick = useQuickAdd();
  const month = useMemo(() => summarize(s.transactions, monthStart(today), today), [s.transactions, today]);
  const waste = useMemo(() => detectWaste(s.transactions, s.subscriptions, today, position.avgMonthlyIncome), [s.transactions, s.subscriptions, today, position.avgMonthlyIncome]);
  const insights = useMemo(() => generateInsights(s, today, position), [s, today, position]);
  const gamification = s.profile.preferences?.gamification !== false;

  if (s.totals.tx_count === 0) {
    return (
      <>
        <PageHeader title="Insights" subtitle="Patterns, habits and ideas from your own spending." />
        <EmptyState title="Nothing to analyse yet" action={<Button onClick={() => quick.open({ type: "expense" })}>Add expense</Button>}>
          Record a few expenses and money received — insights appear as soon as there is data.
        </EmptyState>
      </>
    );
  }

  return (
    <>
      <PageHeader title="Insights" subtitle="Patterns, habits and ideas from your own spending." />
      <div className="space-y-4">
        <WasteCards findings={waste} />

        <Card>
          <CardTitle hint="Calculated from your records. Each line says how it was worked out.">Spending insights</CardTitle>
          {insights.length === 0 ? (
            <p className="py-4 text-sm text-muted">Not enough recent activity for insights yet.</p>
          ) : (
            <ul className="space-y-2">
              {insights.map((i) => (
                <InsightRow key={i.id} insight={i} />
              ))}
            </ul>
          )}
          <AiSummary />
        </Card>

        <NeedWant txs={s.transactions} month={month} today={today} />

        <div className="grid gap-4 lg:grid-cols-2">
          <Card>
            <CardTitle hint="How you paid for this month's expenses." action={<SourceTag kind="recorded" />}>
              Spending by payment method
            </CardTitle>
            {month.byPaymentMethod.length === 0 ? (
              <p className="py-6 text-center text-sm text-muted">No expenses this month yet.</p>
            ) : month.byPaymentMethod.length <= 4 ? (
              <Donut data={month.byPaymentMethod.map((m) => ({ name: m.name, value: m.amount }))} colorFor={methodColor} height={150} />
            ) : (
              <RankBars items={month.byPaymentMethod.map((m) => ({ name: m.name, value: m.amount, sub: `${m.count}×` }))} colorFor={methodColor} />
            )}
          </Card>
          {gamification && <StreaksCard s={s} today={today} />}
        </div>
      </div>
    </>
  );
}

function InsightRow({ insight }: { insight: Insight }) {
  const t = TONE[insight.tone];
  const Icon = t.icon;
  return (
    <li className="flex items-start gap-3 rounded-xl border border-line p-3">
      <span className={cn("flex size-7 shrink-0 items-center justify-center rounded-lg", t.cls)} title={t.label}>
        <Icon className="size-4" aria-label={t.label} />
      </span>
      <p className="min-w-0 flex-1 text-sm">{insight.text}</p>
      <span className="shrink-0">
        <SourceTag kind={insight.basis} />
      </span>
    </li>
  );
}

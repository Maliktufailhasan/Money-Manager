"use client";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { useState } from "react";
import { useFinance } from "@/lib/client/useFinance";
import { addMonths, budgetReport, fmtMonth, monthStart, ym } from "@/lib/finance";
import { Badge, ErrorState, IconButton, PageHeader, PageSkeleton } from "@/components/ui";
import { BudgetActual } from "@/components/plan/BudgetActual";
import { BudgetEditor } from "@/components/plan/BudgetEditor";

const MIN_OFFSET = -12;
const MAX_OFFSET = 1;

export default function BudgetPage() {
  const { data, error, refresh } = useFinance();
  const [offset, setOffset] = useState(0);
  if (!data) return error ? <ErrorState error={error} retry={refresh} /> : <PageSkeleton />;

  const { s, today, position } = data;
  const anchor = addMonths(monthStart(today), offset);
  const { year, month } = ym(anchor);
  const report = offset === 0 ? data.budget : budgetReport(s.budgets, s.transactions, year, month, today);
  const label = fmtMonth(year, month);

  return (
    <div className="space-y-4">
      <PageHeader title="Budget" subtitle="Plan how much goes where, then see how you're doing." />

      <div className="flex items-center justify-between gap-2 rounded-2xl border border-line bg-surface px-2 py-1.5">
        <IconButton label="Previous month" onClick={() => setOffset((o) => Math.max(MIN_OFFSET, o - 1))} disabled={offset <= MIN_OFFSET} className="disabled:opacity-30">
          <ChevronLeft className="size-5" />
        </IconButton>
        <div className="flex flex-col items-center text-center">
          <span className="font-semibold">{label}</span>
          <span className="text-xs">
            {offset === 0 ? <Badge tone="brand">This month</Badge> : offset > 0 ? <Badge tone="good">Planning ahead</Badge> : <Badge>Past month</Badge>}
          </span>
        </div>
        <IconButton label="Next month" onClick={() => setOffset((o) => Math.min(MAX_OFFSET, o + 1))} disabled={offset >= MAX_OFFSET} className="disabled:opacity-30">
          <ChevronRight className="size-5" />
        </IconButton>
      </div>

      <div className="grid gap-4 lg:grid-cols-[minmax(0,1fr)_minmax(0,1.1fr)] lg:items-start">
        <BudgetEditor key={`${year}-${month}`} s={s} position={position} today={today} year={year} month={month} />
        <BudgetActual report={report} isCurrent={offset === 0} isFuture={offset > 0} monthLabel={label} />
      </div>
    </div>
  );
}

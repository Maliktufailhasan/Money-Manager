"use client";
import { MessageSquarePlus } from "lucide-react";
import { useState } from "react";
import { Chat } from "@/components/analysis/Chat";
import { Button, ErrorState, PageHeader, PageSkeleton } from "@/components/ui";
import { useFinance } from "@/lib/client/useFinance";

export default function AssistantPage() {
  const { data, error, refresh } = useFinance();
  const [reset, setReset] = useState(0);
  if (!data) return error ? <ErrorState error={error} retry={refresh} /> : <PageSkeleton />;
  const n = data.s.totals.tx_count;

  return (
    <>
      <PageHeader
        title="AI Assistant"
        subtitle={n ? `Answers are based on your ${n.toLocaleString("en-IN")} recorded transactions.` : "Add some transactions so answers can use your real numbers."}
        actions={
          <Button variant="secondary" size="sm" onClick={() => setReset((r) => r + 1)}>
            <MessageSquarePlus className="size-4" aria-hidden /> New chat
          </Button>
        }
      />
      <Chat resetSignal={reset} />
    </>
  );
}

"use client";
import { Briefcase, Clock, Pencil, Plus, Target, Trash2 } from "lucide-react";
import { useMemo, useState } from "react";
import { useQuickAdd } from "@/components/AppShell";
import { BarsChart, ChartBox, COLORS, RankBars, SERIES } from "@/components/charts";
import { EarningSourceModal, STATUS_LABEL, incomeCategoryFor } from "@/components/manage/EarningSourceModal";
import { Figure, RowMenu, errMsg, toNum } from "@/components/manage/shared";
import {
  Badge, Button, Card, CardTitle, Chip, EmptyState, ErrorState, Money, MoneyInput, PageHeader, PageSkeleton, SourceTag, cn, confirmAction, useToast,
} from "@/components/ui";
import { db, updateProfile } from "@/lib/client/api";
import { useFinance, type FinanceData } from "@/lib/client/useFinance";
import { addMonths, fmtMonth, fmtMonthShort, isReceived, monthEnd, monthKey, monthStart, round2, summarize, sum, ym } from "@/lib/finance";
import type { EarningSource } from "@/lib/types";

const WEEKS_PER_MONTH = 4.35;

export default function EarnPage() {
  const { data, error, refresh } = useFinance();
  if (!data) return error ? <ErrorState error={error} retry={() => refresh()} /> : <PageSkeleton />;
  return <Earn data={data} />;
}

function Earn({ data }: { data: FinanceData }) {
  const { s, today } = data;
  const quick = useQuickAdd();
  const toast = useToast();
  const [modal, setModal] = useState<{ source: EarningSource | null; n: number } | null>(null);

  const from = monthStart(today);
  const to = monthEnd(today);
  const { year, month } = ym(today);

  const calc = useMemo(() => {
    const monthIncome = s.transactions.filter((t) => isReceived(t) && t.date >= from && t.date <= to);
    const actualBy = new Map<string, number>();
    for (const t of monthIncome) if (t.earning_source_id) actualBy.set(t.earning_source_id, (actualBy.get(t.earning_source_id) ?? 0) + t.amount);
    const actual = sum([...actualBy.values()]);
    const potential = sum(s.earningSources.filter((e) => e.status === "active").map((e) => e.expected_income));
    const ideaPotential = sum(s.earningSources.filter((e) => e.status === "idea").map((e) => e.expected_income));
    const bySource = summarize(s.transactions, from, to).bySource;
    return { actualBy, actual, potential, ideaPotential, bySource };
  }, [s, from, to]);

  const history = useMemo(() => {
    const ids = s.earningSources.map((e) => e.id);
    const rows: Record<string, string | number>[] = [];
    for (let m = 5; m >= 0; m--) {
      const a = addMonths(from, -m);
      const row: Record<string, string | number> = { key: monthKey(a), label: fmtMonthShort(monthKey(a)) };
      for (const id of ids) row[`s_${id}`] = 0;
      for (const t of s.transactions) {
        if (!isReceived(t) || !t.earning_source_id || t.date < a || t.date > monthEnd(a)) continue;
        const k = `s_${t.earning_source_id}`;
        if (k in row) row[k] = round2(Number(row[k]) + t.amount);
      }
      rows.push(row);
    }
    const withIncome = s.earningSources.filter((e) => rows.some((r) => Number(r[`s_${e.id}`]) > 0));
    const series = withIncome.map((e, i) => ({ key: `s_${e.id}`, label: e.source, color: SERIES[i % SERIES.length] }));
    return { rows, series };
  }, [s, from]);

  const target = s.profile.preferences.side_hustle_target ?? null;
  const sources = [...s.earningSources].sort((a, b) => order(a.status) - order(b.status));

  async function remove(e: EarningSource) {
    if (!confirmAction(`Delete "${e.source}"? Income you've already logged stays in your transactions.`)) return;
    try {
      await db.remove("earning-sources", e.id);
      toast("Income source deleted");
    } catch (err) {
      toast(errMsg(err), "bad");
    }
  }

  function logIncome(e: EarningSource) {
    quick.open({ type: "income", preset: { type: "income", category: incomeCategoryFor(e.type), earning_source_id: e.id, income_type: "Earned", description: e.source } });
  }

  const add = () => setModal({ source: null, n: Date.now() });

  return (
    <div className="space-y-4">
      <PageHeader
        title="Earn money"
        subtitle="Track side hustles — what you hope to earn vs what actually came in."
        actions={
          <Button onClick={add}>
            <Plus className="size-4" /> Add income source
          </Button>
        }
      />

      <div className="grid gap-4 sm:grid-cols-2">
        <Card>
          <div className="flex items-center justify-between gap-2">
            <p className="text-xs font-medium text-muted">Actual income · {fmtMonth(year, month)}</p>
            <SourceTag kind="recorded" />
          </div>
          <p className="mt-1.5 text-2xl font-semibold tracking-tight text-good">
            <Money value={calc.actual} />
          </p>
          <p className="mt-0.5 text-xs text-muted">Money received this month that you linked to an income source.</p>
        </Card>
        <Card>
          <div className="flex items-center justify-between gap-2">
            <p className="text-xs font-medium text-muted">Potential income / month</p>
            <SourceTag kind="assumption" />
          </div>
          <p className="mt-1.5 text-2xl font-semibold tracking-tight text-ink-2">
            <Money value={calc.potential} />
          </p>
          <p className="mt-0.5 text-xs text-muted">
            Your own estimates for active sources — not guaranteed.
            {calc.ideaPotential > 0 && (
              <>
                {" "}
                Ideas could add <Money value={calc.ideaPotential} /> more.
              </>
            )}
          </p>
        </Card>
      </div>

      <GoalCard target={target} actual={calc.actual} potential={calc.potential} />

      <Card>
        <CardTitle hint={`Expected vs actual for ${fmtMonth(year, month)}`}>Your income sources</CardTitle>
        {sources.length === 0 ? (
          <EmptyState
            icon={<Briefcase className="size-8" />}
            title="No income sources yet"
            action={
              <Button onClick={add}>
                <Plus className="size-4" /> Add your first one
              </Button>
            }
          >
            Add a side hustle you&apos;re doing or thinking about — tutoring, freelancing, content creation — and log what you earn from it.
          </EmptyState>
        ) : (
          <SourceTable sources={sources} actualBy={calc.actualBy} onLog={logIncome} onEdit={(e) => setModal({ source: e, n: Date.now() })} onDelete={remove} />
        )}
      </Card>

      <div className="grid gap-4 lg:grid-cols-2">
        <ChartBox
          title="Side income history"
          hint="Last 6 months, income linked to each source"
          table={{ columns: ["Month", ...history.series.map((x) => x.label)], rows: history.rows.map((r) => [String(r.label), ...history.series.map((x) => Number(r[x.key]))]) }}
        >
          {history.series.length ? (
            <BarsChart data={history.rows} xKey="label" series={history.series} stacked />
          ) : (
            <p className="py-10 text-center text-sm text-muted">Log income against a source to see your history here.</p>
          )}
        </ChartBox>
        <Card>
          <CardTitle hint="All money received this month, grouped by income source category">Income by category this month</CardTitle>
          {calc.bySource.length ? (
            <RankBars items={calc.bySource.map((b) => ({ name: b.name, value: b.amount, sub: `${b.count}×` }))} colorFor={() => COLORS.income} />
          ) : (
            <EmptyState title="No income recorded this month" action={<Button variant="soft" size="sm" onClick={() => quick.open({ type: "income" })}>Add money received</Button>} />
          )}
        </Card>
      </div>

      {modal && <EarningSourceModal key={modal.n} open onClose={() => setModal(null)} source={modal.source} today={today} />}
    </div>
  );
}

function order(st: EarningSource["status"]) {
  return { active: 0, idea: 1, paused: 2, stopped: 3 }[st];
}

function GoalCard({ target, actual, potential }: { target: number | null; actual: number; potential: number }) {
  const toast = useToast();
  const [editing, setEditing] = useState(false);
  const [val, setVal] = useState(target ? String(target) : "");
  const [saving, setSaving] = useState(false);

  async function save(v: number | null) {
    if (v === null || v <= 0) return toast("Enter a goal above ₹0", "warn");
    setSaving(true);
    try {
      await updateProfile({ preferences: { side_hustle_target: v } });
      setEditing(false);
      toast("Side-hustle goal saved");
    } catch (e) {
      toast(errMsg(e), "bad");
    } finally {
      setSaving(false);
    }
  }

  const editor = (
    <div className="mt-3 space-y-2">
      <div className="flex gap-2">
        <div className="flex-1">
          <MoneyInput value={val} onChange={setVal} placeholder="Monthly goal" aria-label="Monthly side-hustle goal" />
        </div>
        <Button onClick={() => save(toNum(val))} loading={saving}>
          Save
        </Button>
        {target !== null && (
          <Button variant="ghost" onClick={() => setEditing(false)}>
            Cancel
          </Button>
        )}
      </div>
      <div className="flex flex-wrap gap-2">
        {[2000, 5000, 10000].map((n) => (
          <Chip key={n} active={val === String(n)} onClick={() => setVal(String(n))}>
            ₹{n.toLocaleString("en-IN")}
          </Chip>
        ))}
      </div>
    </div>
  );

  if (target === null || editing) {
    return (
      <Card>
        <CardTitle hint="How much do you want to earn on the side each month?">
          <span className="flex items-center gap-1.5">
            <Target className="size-4 text-brand" /> Side-hustle goal
          </span>
        </CardTitle>
        {editor}
      </Card>
    );
  }

  const actualPct = Math.min(100, (actual / target) * 100);
  const potentialPct = Math.min(100, (potential / target) * 100);
  const left = Math.max(0, target - actual);
  return (
    <Card>
      <div className="flex items-start justify-between gap-2">
        <div>
          <p className="flex items-center gap-1.5 text-sm font-semibold">
            <Target className="size-4 text-brand" /> Goal: Earn <Money value={target} />
            /month
          </p>
          <p className="mt-0.5 text-xs text-muted">Progress counts only income you actually received.</p>
        </div>
        <Button variant="ghost" size="sm" onClick={() => setEditing(true)}>
          <Pencil className="size-3.5" /> Edit
        </Button>
      </div>
      <div className="relative mt-4">
        <div className="h-3 w-full overflow-hidden rounded-full bg-surface-2" role="progressbar" aria-label="Actual income vs goal" aria-valuenow={Math.round(actualPct)} aria-valuemin={0} aria-valuemax={100}>
          <div className={cn("h-full rounded-full transition-[width] duration-500", actual >= target ? "bg-good" : "bg-brand")} style={{ width: `${actualPct}%` }} />
        </div>
        {potential > 0 && (
          <div className="absolute -top-1 h-5 border-l-2 border-dashed border-muted" style={{ left: `calc(${potentialPct}% - 1px)` }} title={`Potential: ₹${Math.round(potential).toLocaleString("en-IN")}`} aria-hidden />
        )}
      </div>
      <div className="mt-3 flex flex-wrap gap-x-6 gap-y-2">
        <Figure label="Earned so far">
          <Money value={actual} className="text-good" />
        </Figure>
        <Figure label={actual >= target ? "Goal reached!" : "Still to go"}>
          <Money value={left} />
        </Figure>
        <Figure label="Potential (estimate)" hint={<span className="flex items-center gap-1"><span className="inline-block h-3 border-l-2 border-dashed border-muted" /> marker on the bar</span>}>
          <Money value={potential} className="text-ink-2" />
        </Figure>
      </div>
    </Card>
  );
}

function SourceTable({
  sources, actualBy, onLog, onEdit, onDelete,
}: {
  sources: EarningSource[];
  actualBy: Map<string, number>;
  onLog: (e: EarningSource) => void;
  onEdit: (e: EarningSource) => void;
  onDelete: (e: EarningSource) => void;
}) {
  const totalExpected = sum(sources.filter((e) => e.status === "active").map((e) => e.expected_income));
  const totalActual = sum(sources.map((e) => actualBy.get(e.id) ?? 0));
  return (
    <div>
      <ul className="divide-y divide-line">
        {sources.map((e) => {
          const actual = actualBy.get(e.id) ?? 0;
          const perHour = e.status === "active" && e.hours > 0 ? actual / (e.hours * WEEKS_PER_MONTH) : null;
          const tone = e.status === "active" ? "good" : e.status === "idea" ? "brand" : "neutral";
          return (
            <li key={e.id} className="py-3 first:pt-0">
              <div className="flex items-start gap-3">
                <div className="min-w-0 flex-1">
                  <div className="flex flex-wrap items-center gap-1.5">
                    <span className="truncate font-medium">{e.source}</span>
                    <Badge tone={tone}>{STATUS_LABEL[e.status]}</Badge>
                  </div>
                  <p className="mt-0.5 text-xs text-muted">
                    {e.type}
                    {e.hours > 0 && (
                      <>
                        {" · "}
                        <Clock className="inline size-3" /> {e.hours} h/week
                      </>
                    )}
                  </p>
                </div>
                <div className="flex shrink-0 items-center gap-1">
                  <Button size="sm" variant="soft" onClick={() => onLog(e)}>
                    <Plus className="size-3.5" /> Log income
                  </Button>
                  <RowMenu
                    items={[
                      { label: "Edit", icon: <Pencil className="size-3.5" />, onClick: () => onEdit(e) },
                      { label: "Delete", icon: <Trash2 className="size-3.5" />, onClick: () => onDelete(e), danger: true },
                    ]}
                  />
                </div>
              </div>
                  <div className="mt-2 grid grid-cols-3 gap-2 text-sm">
                    <div>
                      <div className="text-[11px] text-muted">Expected</div>
                      <Money value={e.expected_income} className="text-ink-2" />
                    </div>
                    <div>
                      <div className="text-[11px] text-muted">Actual</div>
                      <Money value={actual} className={actual > 0 ? "font-medium text-good" : "text-muted"} />
                    </div>
                    <div>
                      <div className="text-[11px] text-muted">₹ / hour</div>
                      {perHour !== null ? <span className="tabular">₹{perHour.toFixed(0)}</span> : <span className="text-muted">—</span>}
                    </div>
                  </div>
            </li>
          );
        })}
      </ul>
      <div className="mt-1 grid grid-cols-3 gap-2 rounded-xl bg-surface-2 px-3 py-2.5 text-sm">
        <div className="font-medium">Total</div>
        <div>
          <div className="text-[11px] text-muted">Expected (active)</div>
          <Money value={totalExpected} />
        </div>
        <div>
          <div className="text-[11px] text-muted">Actual</div>
          <Money value={totalActual} className="font-semibold text-good" />
        </div>
      </div>
      <p className="mt-2 text-xs text-muted">₹/hour = actual this month ÷ (hours per week × {WEEKS_PER_MONTH} weeks). Shown for active sources only.</p>
    </div>
  );
}

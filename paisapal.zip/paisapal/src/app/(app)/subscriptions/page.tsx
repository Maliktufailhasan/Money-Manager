"use client";
import { CalendarClock, Check, CreditCard, Pencil, Plus, SkipForward, Trash2 } from "lucide-react";
import { useMemo, useState } from "react";
import { CYCLE_LABEL, SubscriptionModal } from "@/components/manage/SubscriptionModal";
import { DueBadge, Figure, RowMenu, errMsg } from "@/components/manage/shared";
import {
  Badge, Button, Card, CardTitle, EmptyState, ErrorState, Money, PageHeader, PageSkeleton, SourceTag, Toggle, cn, confirmAction, useToast,
} from "@/components/ui";
import { db, payItem } from "@/lib/client/api";
import { useFinance, type FinanceData } from "@/lib/client/useFinance";
import { addDays, addMonths, fmtDate, subscriptionMonthlyCost, sum, totalDue, upcomingPayments } from "@/lib/finance";
import type { Subscription } from "@/lib/types";

export default function SubscriptionsPage() {
  const { data, error, refresh } = useFinance();
  if (!data) return error ? <ErrorState error={error} retry={() => refresh()} /> : <PageSkeleton />;
  return <Subscriptions data={data} />;
}

function renewLabel(days: number) {
  if (days < 0) return "overdue";
  if (days === 0) return "renews today";
  if (days === 1) return "renews tomorrow";
  return `renews in ${days} days`;
}

function Subscriptions({ data }: { data: FinanceData }) {
  const { s, today } = data;
  const toast = useToast();
  const [modal, setModal] = useState<{ sub: Subscription | null; n: number } | null>(null);
  const [busy, setBusy] = useState<string | null>(null);

  const monthly = sum(s.subscriptions.map(subscriptionMonthlyCost));
  const activeCount = s.subscriptions.filter((x) => x.status === "active").length;

  const nextDates = useMemo(() => {
    const horizon = addMonths(today, 13);
    const m = new Map<string, { date: string; daysAway: number }>();
    for (const sub of s.subscriptions) {
      const first = upcomingPayments({ subscriptions: [sub], reminders: [] }, today, horizon)[0];
      if (first) m.set(sub.id, { date: first.date, daysAway: first.daysAway });
    }
    return m;
  }, [s.subscriptions, today]);

  const upcoming = useMemo(() => upcomingPayments({ subscriptions: s.subscriptions, reminders: [] }, today, addDays(today, 30)), [s.subscriptions, today]);

  const sorted = [...s.subscriptions].sort((a, b) => (a.status === b.status ? (nextDates.get(a.id)?.date ?? a.next_payment_date).localeCompare(nextDates.get(b.id)?.date ?? b.next_payment_date) : a.status === "active" ? -1 : 1));

  async function run(key: string, fn: () => Promise<unknown>, ok: string) {
    setBusy(key);
    try {
      await fn();
      toast(ok);
    } catch (e) {
      toast(errMsg(e), "bad");
    } finally {
      setBusy(null);
    }
  }

  const add = () => setModal({ sub: null, n: Date.now() });

  return (
    <div className="space-y-4">
      <PageHeader
        title="Subscriptions"
        subtitle="Every app and plan that charges you on repeat, in one place."
        actions={
          <Button onClick={add}>
            <Plus className="size-4" /> Add subscription
          </Button>
        }
      />

      {s.subscriptions.length === 0 ? (
        <EmptyState
          icon={<CreditCard className="size-8" />}
          title="No subscriptions tracked"
          action={
            <Button onClick={add}>
              <Plus className="size-4" /> Add one
            </Button>
          }
        >
          Add Netflix, Spotify, your mobile plan or cloud storage to see what they really cost you per year.
        </EmptyState>
      ) : (
        <>
          <Card>
            <div className="flex flex-wrap items-end justify-between gap-4">
              <p className="text-base sm:text-lg">
                Monthly Subscriptions: <Money value={monthly} className="font-semibold" /> <span className="text-muted">·</span> Annual Cost: <Money value={monthly * 12} className="font-semibold text-bad" />
              </p>
              <SourceTag kind="calculated" />
            </div>
            <div className="mt-3 flex flex-wrap gap-x-6 gap-y-2">
              <Figure label="Active">{activeCount}</Figure>
              <Figure label="Due in next 30 days">
                <Money value={totalDue(upcoming)} />
              </Figure>
            </div>
            <p className="mt-2 text-xs text-muted">Active subscriptions only. Weekly, quarterly and yearly plans are converted to a monthly equivalent.</p>
          </Card>

          <div className="grid gap-4 lg:grid-cols-[1fr_320px]">
            <Card>
              <CardTitle>All subscriptions</CardTitle>
              <ul className="divide-y divide-line">
                {sorted.map((sub) => {
                  const nd = nextDates.get(sub.id);
                  const active = sub.status === "active";
                  const soon = nd && nd.daysAway <= sub.remind_days_before;
                  return (
                    <li key={sub.id} className={cn("py-3 first:pt-0", !active && "opacity-60")}>
                      <div className="flex items-start gap-3">
                        <div className="min-w-0 flex-1">
                          <div className="flex flex-wrap items-center gap-1.5">
                            <span className="truncate font-medium">{sub.name}</span>
                            {active && nd && soon && <Badge tone={nd.daysAway < 0 ? "bad" : "warn"}>{renewLabel(nd.daysAway)}</Badge>}
                            {!active && <Badge>Inactive</Badge>}
                          </div>
                          <p className="mt-0.5 text-xs text-muted">
                            <Money value={sub.amount} className="text-ink" /> / {CYCLE_LABEL[sub.billing_cycle].toLowerCase()} · {sub.category}
                            {active && nd && (
                              <>
                                {" · "}next {fmtDate(nd.date)}
                                {!soon && ` (in ${nd.daysAway} days)`}
                              </>
                            )}
                          </p>
                        </div>
                        <div className="flex shrink-0 items-center gap-1">
                          <div className="hidden sm:block">
                            <Toggle checked={active} onChange={(v) => run(`t-${sub.id}`, () => db.update("subscriptions", sub.id, { status: v ? "active" : "inactive" }), v ? "Subscription activated" : "Marked inactive")} label="Active" />
                          </div>
                          {active && (
                            <Button size="sm" variant="soft" loading={busy === `p-${sub.id}`} onClick={() => run(`p-${sub.id}`, () => payItem("subscription", sub.id), `Paid ${sub.name} — expense recorded`)}>
                              <Check className="size-3.5" /> Paid
                            </Button>
                          )}
                          <RowMenu
                            items={[
                              ...(active ? [{ label: "Skip this payment", icon: <SkipForward className="size-3.5" />, onClick: () => run(`s-${sub.id}`, () => payItem("subscription", sub.id, "skip"), "Skipped — moved to the next date") }] : []),
                              { label: active ? "Mark inactive" : "Mark active", icon: <CreditCard className="size-3.5" />, onClick: () => run(`t-${sub.id}`, () => db.update("subscriptions", sub.id, { status: active ? "inactive" : "active" }), active ? "Marked inactive" : "Subscription activated") },
                              { label: "Edit", icon: <Pencil className="size-3.5" />, onClick: () => setModal({ sub, n: Date.now() }) },
                              {
                                label: "Delete",
                                icon: <Trash2 className="size-3.5" />,
                                danger: true,
                                onClick: () => confirmAction(`Delete ${sub.name}? Past payments stay in your transactions.`) && run(`d-${sub.id}`, () => db.remove("subscriptions", sub.id), "Subscription deleted"),
                              },
                            ]}
                          />
                        </div>
                      </div>
                    </li>
                  );
                })}
              </ul>
            </Card>

            <Card>
              <CardTitle hint="Next 30 days">
                <span className="flex items-center gap-1.5">
                  <CalendarClock className="size-4 text-brand" /> Upcoming renewals
                </span>
              </CardTitle>
              {upcoming.length === 0 ? (
                <p className="py-6 text-center text-sm text-muted">Nothing renews in the next 30 days.</p>
              ) : (
                <ul className="space-y-2">
                  {upcoming.map((u) => (
                    <li key={u.key} className="flex items-center justify-between gap-2 text-sm">
                      <span className="min-w-0">
                        <span className="block truncate">{u.title}</span>
                        <span className="text-xs text-muted">{fmtDate(u.date)}</span>
                      </span>
                      <span className="flex shrink-0 flex-col items-end gap-0.5">
                        <Money value={u.amount} className="font-medium" />
                        <DueBadge daysAway={u.daysAway} />
                      </span>
                    </li>
                  ))}
                </ul>
              )}
            </Card>
          </div>
        </>
      )}

      {modal && <SubscriptionModal key={modal.n} open onClose={() => setModal(null)} sub={modal.sub} today={today} custom={s.categories} />}
    </div>
  );
}

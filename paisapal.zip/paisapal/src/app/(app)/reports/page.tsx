"use client";
import { useState } from "react";
import { MonthlyReportView } from "@/components/analysis/MonthlyReportView";
import { WeeklyReviewView } from "@/components/analysis/WeeklyReviewView";
import { useQuickAdd } from "@/components/AppShell";
import { Button, EmptyState, ErrorState, PageHeader, PageSkeleton, Segmented } from "@/components/ui";
import { useFinance } from "@/lib/client/useFinance";

export default function ReportsPage() {
  const { data, error, refresh } = useFinance();
  const quick = useQuickAdd();
  const [tab, setTab] = useState<"weekly" | "monthly">("weekly");
  if (!data) return error ? <ErrorState error={error} retry={refresh} /> : <PageSkeleton />;

  return (
    <>
      <PageHeader
        title="Reports"
        subtitle="Weekly reviews and monthly reports from your recorded money."
        actions={
          <Segmented
            value={tab}
            onChange={setTab}
            options={[
              { value: "weekly", label: "Weekly" },
              { value: "monthly", label: "Monthly" },
            ]}
          />
        }
      />
      {data.s.totals.tx_count === 0 ? (
        <EmptyState title="No reports yet" action={<Button onClick={() => quick.open({ type: "expense" })}>Add expense</Button>}>
          Reports are built from your transactions. Add a few to see your first weekly review.
        </EmptyState>
      ) : tab === "weekly" ? (
        <WeeklyReviewView s={data.s} today={data.today} />
      ) : (
        <MonthlyReportView s={data.s} today={data.today} />
      )}
    </>
  );
}

"use client";
import { Plus, Target } from "lucide-react";
import { useMemo, useState } from "react";
import { useFinance } from "@/lib/client/useFinance";
import { formatINR, goalMetrics, goalsMonthlyCommitment, sum, type GoalMetrics } from "@/lib/finance";
import { Button, EmptyState, ErrorState, PageHeader, PageSkeleton, Segmented, Stat } from "@/components/ui";
import { GoalCard } from "@/components/plan/GoalCard";
import { useGoalModals } from "@/components/plan/useGoalModals";

type Filter = "active" | "completed" | "all";
const PRIO = { high: 0, medium: 1, low: 2 } as const;

export default function GoalsPage() {
  const { data, error, refresh } = useFinance();
  const [filter, setFilter] = useState<Filter>("active");
  const today = data?.today ?? "";
  const ui = useGoalModals(today);

  const metrics = useMemo<GoalMetrics[]>(() => {
    if (!data) return [];
    const { s, position } = data;
    return s.goals.map((g) => {
      const free = Math.max(0, position.savingCapacity - goalsMonthlyCommitment(s.goals, data.today, g.id));
      return goalMetrics(g, s.contributions, data.today, free);
    });
  }, [data]);

  if (!data) return error ? <ErrorState error={error} retry={refresh} /> : <PageSkeleton />;
  const { s, position } = data;

  const isDone = (m: GoalMetrics) => m.status === "completed";
  const shown = metrics
    .filter((m) => (filter === "all" ? true : filter === "completed" ? isDone(m) : !isDone(m)))
    .sort((a, b) => Number(a.goal.status === "paused") - Number(b.goal.status === "paused") || PRIO[a.goal.priority] - PRIO[b.goal.priority] || (a.goal.target_date ?? "9999").localeCompare(b.goal.target_date ?? "9999"));

  const active = metrics.filter((m) => !isDone(m));
  const saved = sum(s.goals.map((g) => g.current_amount));
  const target = sum(active.map((m) => m.goal.target_amount));
  const needed = goalsMonthlyCommitment(s.goals, today);

  return (
    <div className="space-y-4">
      <PageHeader
        title="Goals"
        subtitle="Save up for the things that matter — one bucket at a time."
        actions={
          <Button onClick={() => ui.newGoal()}>
            <Plus className="size-4" /> New goal
          </Button>
        }
      />

      {s.goals.length === 0 ? (
        <EmptyState
          icon={<Target className="size-8" />}
          title="No goals yet"
          action={
            <>
              <Button onClick={() => ui.newGoal({ category: "Phone", name: "New Phone" })}>Save for a phone</Button>
              <Button variant="secondary" onClick={() => ui.newGoal({ category: "Emergency Fund", name: "Emergency Fund", is_emergency: true })}>
                Start an emergency fund
              </Button>
              <Button variant="ghost" onClick={() => ui.newGoal()}>
                Custom goal
              </Button>
            </>
          }
        >
          Create a goal with a price and a date — we&apos;ll work out how much to save each month, week and day.
        </EmptyState>
      ) : (
        <>
          <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
            <Stat label="Saved in goals" value={formatINR(saved)} sub="All goal buckets" />
            <Stat label="Active goals" value={active.length} sub={`${metrics.length - active.length} completed`} />
            <Stat label="Still to save" value={formatINR(sum(active.map((m) => m.remaining)))} sub={`of ${formatINR(target)} active targets`} />
            <Stat
              label="Needed per month"
              value={formatINR(needed)}
              tone={needed > position.savingCapacity ? "warn" : undefined}
              sub={needed > position.savingCapacity ? `More than you save (~${formatINR(Math.max(0, position.savingCapacity))}/mo)` : `You save ~${formatINR(Math.max(0, position.savingCapacity))}/mo`}
            />
          </div>

          <Segmented<Filter>
            value={filter}
            onChange={setFilter}
            options={[
              { value: "active", label: `Active (${active.length})` },
              { value: "completed", label: `Completed (${metrics.length - active.length})` },
              { value: "all", label: "All" },
            ]}
          />

          {shown.length === 0 ? (
            <EmptyState title={filter === "completed" ? "No completed goals yet" : "No active goals"}>{filter === "completed" ? "Finished goals will show up here. Keep going!" : "All your goals are done 🎉 Time for a new one?"}</EmptyState>
          ) : (
            <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
              {shown.map((m) => (
                <GoalCard key={m.goal.id} m={m} contributions={s.contributions} onAdd={() => ui.addMoney(m.goal)} onWithdraw={() => ui.withdraw(m.goal)} onEdit={() => ui.editGoal(m.goal)} />
              ))}
            </div>
          )}
        </>
      )}
      {ui.modals}
    </div>
  );
}

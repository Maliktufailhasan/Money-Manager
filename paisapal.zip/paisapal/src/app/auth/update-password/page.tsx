"use client";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { Button, Field, Input } from "@/components/ui";
import { supabaseBrowser } from "@/lib/supabase/client";

export default function UpdatePasswordPage() {
  const router = useRouter();
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  return (
    <div className="flex min-h-dvh items-center justify-center px-4">
      <form
        className="w-full max-w-sm space-y-4 rounded-3xl border border-line bg-surface p-6"
        onSubmit={async (e) => {
          e.preventDefault();
          if (password.length < 8) return setError("Use at least 8 characters.");
          setLoading(true);
          const { error } = await supabaseBrowser().auth.updateUser({ password });
          setLoading(false);
          if (error) setError(error.message);
          else router.replace("/");
        }}
      >
        <h1 className="text-lg font-semibold">Choose a new password</h1>
        <Field label="New password">{(id) => <Input id={id} type="password" minLength={8} value={password} onChange={(e) => setPassword(e.target.value)} autoComplete="new-password" required />}</Field>
        {error && <p className="text-sm text-bad">{error}</p>}
        <Button type="submit" className="w-full" loading={loading}>
          Update password
        </Button>
      </form>
    </div>
  );
}
